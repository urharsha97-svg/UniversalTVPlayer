# Universal TV Player V11.3 — Ready Build Package

This package is intentionally a Gradle project, not a nested source archive.

Build with Gradle 8.11.1 + Java 17:
  gradle :app:clean :app:assembleDebug

GitHub Actions installs Gradle 8.11.1, so the Gradle wrapper JAR is not required for CI.
The project includes gradle/wrapper/gradle-wrapper.properties for the pinned Gradle distribution.
