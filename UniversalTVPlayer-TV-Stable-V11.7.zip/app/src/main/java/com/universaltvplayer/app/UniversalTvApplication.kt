package com.universaltvplayer.app

import android.app.Application

class UniversalTvApplication : Application() {
    val playerController: PlayerController by lazy(LazyThreadSafetyMode.SYNCHRONIZED) {
        PlayerController(applicationContext)
    }
}
