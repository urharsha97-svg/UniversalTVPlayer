package com.universaltvplayer

import android.content.Intent
import android.database.Cursor
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.media3.common.C
import androidx.media3.common.Format
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.Tracks
import androidx.media3.datasource.DefaultDataSource
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import io.github.anilbeesetti.nextlib.media3ext.ffdecoder.NextRenderersFactory
import java.util.Locale

class MainActivity : ComponentActivity() {
    private enum class Engine(val title: String) {
        UNIVERSAL("Universal Engine"),
        MEDIA3("Media3 Engine"),
        FFMPEG("FFmpeg Engine")
    }

    private var engine = Engine.UNIVERSAL
    private var player: ExoPlayer? = null
    private var playerView: PlayerView? = null
    private var currentUri: Uri? = null
    private var currentTitle: String = ""
    private var lastBackMs = 0L

    private val prefs by lazy { getSharedPreferences("universal_player", MODE_PRIVATE) }

    private val openFile = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            try {
                contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            } catch (_: SecurityException) { }
            playUri(uri)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        showHome()
    }

    private fun showHome() {
        releasePlayer()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setBackgroundColor(Color.BLACK)
            setPadding(48, 36, 48, 36)
        }
        addTitle(root, "Universal TV Player", "V14 • Universal Playback Engine")
        addButton(root, "OPEN VIDEO / AUDIO FILE") { openFile.launch(arrayOf("video/*", "audio/*", "application/octet-stream")) }
        addButton(root, "PLAY URL") { showUrlDialog() }
        addButton(root, "HISTORY") { showHistory() }
        addButton(root, "ENGINE CENTER") { showEngineCenter() }
        addButton(root, "EXIT") { finish() }
        setContentView(root)
        root.getChildAt(1)?.requestFocus()
    }

    private fun showEngineCenter() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.BLACK)
            setPadding(48, 36, 48, 36)
        }
        addTitle(root, "ENGINE CENTER", "Manual engine selection • no automatic player switching")
        addButton(root, "UNIVERSAL ENGINE${if (engine == Engine.UNIVERSAL) "  ✓" else ""}") {
            engine = Engine.UNIVERSAL
            toast("Universal Engine selected")
            showEngineCenter()
        }
        addButton(root, "MEDIA3 ENGINE${if (engine == Engine.MEDIA3) "  ✓" else ""}") {
            engine = Engine.MEDIA3
            toast("Media3 Engine selected")
            showEngineCenter()
        }
        addButton(root, "FFMPEG ENGINE${if (engine == Engine.FFMPEG) "  ✓" else ""}") {
            engine = Engine.FFMPEG
            toast("FFmpeg Engine selected")
            showEngineCenter()
        }
        addButton(root, "FILE DETAILS") { showFileDetails(currentUri ?: Uri.EMPTY) }
        addButton(root, "BACK TO HOME") { showHome() }
        setContentView(root)
        root.getChildAt(1)?.requestFocus()
    }

    private fun showUrlDialog() {
        val input = EditText(this).apply {
            hint = "https://example.com/video.mp4"
            setSingleLine(true)
            setTextColor(Color.WHITE)
            setHintTextColor(Color.GRAY)
            isFocusable = true
        }
        val box = LinearLayout(this).apply {
            setPadding(32, 0, 32, 0)
            addView(input, LinearLayout.LayoutParams(-1, -2))
        }
        android.app.AlertDialog.Builder(this)
            .setTitle("Play URL")
            .setView(box)
            .setNegativeButton("CANCEL", null)
            .setPositiveButton("PLAY") { _, _ ->
                val value = input.text.toString().trim()
                if (value.startsWith("http://") || value.startsWith("https://") || value.startsWith("rtsp://")) {
                    playUri(Uri.parse(value))
                } else {
                    toast("Enter a valid HTTP/HTTPS/RTSP URL")
                }
            }
            .show()
    }

    private fun playUri(uri: Uri) {
        currentUri = uri
        currentTitle = queryDisplayName(uri) ?: uri.lastPathSegment ?: uri.toString()
        saveHistory(uri, currentTitle)
        releasePlayer()

        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.BLACK)
        }
        val bar = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            setPadding(12, 8, 12, 8)
            setBackgroundColor(Color.rgb(18, 18, 18))
        }
        val label = TextView(this).apply {
            text = "${engine.title}  •  $currentTitle"
            textSize = 14f
            setTextColor(Color.WHITE)
            ellipsize = android.text.TextUtils.TruncateAt.END
            maxLines = 1
        }
        val engineButton = Button(this).apply {
            text = "ENGINE"
            setOnClickListener { showEngineCenter() }
        }
        val detailsButton = Button(this).apply {
            text = "DETAILS"
            setOnClickListener { showFileDetails(uri) }
        }
        bar.addView(label, LinearLayout.LayoutParams(0, -2, 1f))
        bar.addView(detailsButton, LinearLayout.LayoutParams(-2, -2))
        bar.addView(engineButton, LinearLayout.LayoutParams(-2, -2))

        val view = PlayerView(this).apply {
            setBackgroundColor(Color.BLACK)
            useController = true
            controllerShowTimeoutMs = 3500
            keepScreenOn = true
            setShowBuffering(PlayerView.SHOW_BUFFERING_WHEN_PLAYING)
            layoutParams = LinearLayout.LayoutParams(-1, 0, 1f)
        }
        playerView = view
        container.addView(bar)
        container.addView(view)
        setContentView(container)

        val exo = buildPlayer()
        player = exo
        view.player = exo
        exo.addListener(object : Player.Listener {
            override fun onPlayerError(error: PlaybackException) {
                toast("Playback error: ${error.errorCodeName}")
            }

            override fun onTracksChanged(tracks: androidx.media3.common.Tracks) {
                // Keep details live as soon as Media3 has discovered the source tracks.
            }
        })
        exo.setMediaItem(MediaItem.fromUri(uri))
        exo.prepare()
        exo.playWhenReady = true
        exo.play()
    }

    private fun buildPlayer(): ExoPlayer {
        val loadControl = DefaultLoadControl.Builder()
            .setBufferDurationsMs(
                30_000,
                180_000,
                2_500,
                5_000
            )
            .setPrioritizeTimeOverSizeThresholds(false)
            .build()

        val httpFactory = DefaultHttpDataSource.Factory()
            .setConnectTimeoutMs(20_000)
            .setReadTimeoutMs(30_000)
            .setAllowCrossProtocolRedirects(true)
            .setUserAgent("UniversalTVPlayer/1.4")
            .setDefaultRequestProperties(authorizedHeaders())
        val dataSourceFactory = DefaultDataSource.Factory(this, httpFactory)
        val mediaSourceFactory = DefaultMediaSourceFactory(dataSourceFactory)

        val builder = ExoPlayer.Builder(this)
            .setLoadControl(loadControl)
            .setMediaSourceFactory(mediaSourceFactory)

        when (engine) {
            Engine.UNIVERSAL -> {
                val renderers = NextRenderersFactory(this)
                    .setExtensionRendererMode(DefaultRenderersFactory.EXTENSION_RENDERER_MODE_ON)
                builder.setRenderersFactory(renderers)
            }
            Engine.MEDIA3 -> {
                val renderers = DefaultRenderersFactory(this)
                    .setExtensionRendererMode(DefaultRenderersFactory.EXTENSION_RENDERER_MODE_OFF)
                builder.setRenderersFactory(renderers)
            }
            Engine.FFMPEG -> {
                val renderers = NextRenderersFactory(this)
                    .setExtensionRendererMode(DefaultRenderersFactory.EXTENSION_RENDERER_MODE_PREFER)
                builder.setRenderersFactory(renderers)
            }
        }
        return builder.build()
    }


    private fun authorizedHeaders(): Map<String, String> {
        val headers = mutableMapOf<String, String>()
        prefs.getString("authorization_header", null)?.takeIf { it.isNotBlank() }?.let {
            headers["Authorization"] = it
        }
        prefs.getString("cookie_header", null)?.takeIf { it.isNotBlank() }?.let {
            headers["Cookie"] = it
        }
        return headers
    }

    private fun showFileDetails(uri: Uri) {
        val p = player
        val lines = mutableListOf<String>()
        lines += "ENGINE: ${engine.title}"
        lines += "NAME: ${currentTitle.ifBlank { queryDisplayName(uri) ?: "Unknown" }}"
        lines += "URI: ${if (uri == Uri.EMPTY) "No active source" else uri}"
        lines += "SIZE: ${querySize(uri)}"

        if (p != null) {
            lines += "DURATION: ${formatDuration(p.duration)}"
            lines += "POSITION: ${formatDuration(p.currentPosition)}"
            lines += "BUFFERED: ${formatDuration(p.bufferedPosition)}"
            lines += "VIDEO RENDERED FRAMES: ${p.videoFormat?.let { p.videoSize.width.toString() + "x" + p.videoSize.height } ?: "unknown"}"
            appendTrackDetails(lines, p.currentTracks.groups)
        } else {
            lines += "STATUS: No player currently active"
            lines += "Open a file/URL, then press DETAILS after tracks are detected."
        }

        val scroll = ScrollView(this).apply {
            setBackgroundColor(Color.BLACK)
            addView(TextView(this@MainActivity).apply {
                text = lines.joinToString("\n\n")
                textSize = 15f
                setTextColor(Color.WHITE)
                setPadding(32, 24, 32, 24)
            })
        }
        android.app.AlertDialog.Builder(this)
            .setTitle("FILE / STREAM DETAILS")
            .setView(scroll)
            .setPositiveButton("CLOSE", null)
            .show()
    }

    private fun appendTrackDetails(lines: MutableList<String>, groups: List<Tracks.Group>) {
        var videoIndex = 0
        var audioIndex = 0
        var textIndex = 0
        for (group in groups) {
            val firstSupportedTrack = (0 until group.length).firstOrNull { group.isSupported(it) }
                ?: continue
            val format = group.getTrackFormat(firstSupportedTrack)
            when (group.type) {
                C.TRACK_TYPE_VIDEO -> {
                    videoIndex++
                    lines += "VIDEO #$videoIndex\n" + formatDetails(format)
                }
                C.TRACK_TYPE_AUDIO -> {
                    audioIndex++
                    lines += "AUDIO #$audioIndex\n" + formatDetails(format)
                }
                C.TRACK_TYPE_TEXT -> {
                    textIndex++
                    lines += "SUBTITLE #$textIndex\n" + formatDetails(format)
                }
            }
        }
        if (videoIndex == 0) lines += "VIDEO: none detected"
        if (audioIndex == 0) lines += "AUDIO: none detected"
        if (textIndex == 0) lines += "SUBTITLES: none detected"
    }

    private fun formatDetails(f: Format): String = buildString {
        appendLine("codec: ${f.sampleMimeType ?: "unknown"}")
        appendLine("codecs: ${f.codecs ?: "unknown"}")
        appendLine("bitrate: ${if (f.bitrate > 0) formatBitrate(f.bitrate) else "unknown"}")
        if (f.width > 0 || f.height > 0) appendLine("resolution: ${f.width}x${f.height}")
        if (f.frameRate > 0f) appendLine("FPS: ${String.format(Locale.US, "%.3f", f.frameRate)}")
        if (f.channelCount > 0) appendLine("channels: ${f.channelCount}")
        if (f.sampleRate > 0) appendLine("sample rate: ${f.sampleRate} Hz")
        if (!f.language.isNullOrBlank()) appendLine("language: ${f.language}")
        if (!f.label.isNullOrBlank()) appendLine("label: ${f.label}")
        f.colorInfo?.let { appendLine("HDR/color: transfer=${it.colorTransfer}, space=${it.colorSpace}, range=${it.colorRange}") }
        appendLine("selection flags: ${f.selectionFlags}")
        appendLine("role flags: ${f.roleFlags}")
    }

    private fun showHistory() {
        val history = loadHistory()
        if (history.isEmpty()) {
            android.app.AlertDialog.Builder(this)
                .setTitle("HISTORY")
                .setMessage("No playback history yet.")
                .setPositiveButton("CLOSE", null)
                .show()
            return
        }
        val labels = history.map { "${it.second}\n${it.first}" }.toTypedArray()
        android.app.AlertDialog.Builder(this)
            .setTitle("HISTORY")
            .setItems(labels) { _, which ->
                playUri(Uri.parse(history[which].first))
            }
            .setNegativeButton("CLOSE", null)
            .setNeutralButton("CLEAR") { _, _ ->
                prefs.edit().remove("history").apply()
                toast("History cleared")
            }
            .show()
    }

    private fun saveHistory(uri: Uri, title: String) {
        val existing = loadHistory().filterNot { it.first == uri.toString() }.toMutableList()
        existing.add(0, uri.toString() to title)
        val trimmed = existing.take(30)
        prefs.edit().putStringSet("history", trimmed.map { "${it.first}\t${it.second}" }.toSet()).apply()
        prefs.edit().putString("history_order", trimmed.joinToString("\n") { "${it.first}\t${it.second}" }).apply()
    }

    private fun loadHistory(): List<Pair<String, String>> {
        val raw = prefs.getString("history_order", "") ?: ""
        if (raw.isBlank()) return emptyList()
        return raw.lines().mapNotNull {
            val tab = it.indexOf('\t')
            if (tab <= 0) null else it.substring(0, tab) to it.substring(tab + 1)
        }
    }

    private fun queryDisplayName(uri: Uri): String? {
        if (uri == Uri.EMPTY) return null
        var cursor: Cursor? = null
        return try {
            cursor = contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)
            if (cursor?.moveToFirst() == true) cursor.getString(0) else null
        } catch (_: Exception) { null } finally { cursor?.close() }
    }

    private fun querySize(uri: Uri): String {
        if (uri == Uri.EMPTY) return "unknown"
        var cursor: Cursor? = null
        return try {
            cursor = contentResolver.query(uri, arrayOf(OpenableColumns.SIZE), null, null, null)
            if (cursor?.moveToFirst() == true) {
                val size = cursor.getLong(0)
                if (size >= 0) formatBytes(size) else "unknown"
            } else "remote/unknown"
        } catch (_: Exception) { "remote/unknown" } finally { cursor?.close() }
    }

    private fun formatBytes(value: Long): String {
        if (value < 1024) return "$value B"
        val kb = value / 1024.0
        if (kb < 1024) return String.format(Locale.US, "%.2f KiB", kb)
        val mb = kb / 1024.0
        if (mb < 1024) return String.format(Locale.US, "%.2f MiB", mb)
        return String.format(Locale.US, "%.2f GiB", mb / 1024.0)
    }

    private fun formatBitrate(value: Int): String = if (value >= 1_000_000) {
        String.format(Locale.US, "%.2f Mbps", value / 1_000_000.0)
    } else {
        String.format(Locale.US, "%.0f kbps", value / 1000.0)
    }

    private fun formatDuration(ms: Long): String {
        if (ms == C.TIME_UNSET || ms < 0) return "unknown"
        val total = ms / 1000
        val h = total / 3600
        val m = (total % 3600) / 60
        val s = total % 60
        return if (h > 0) String.format(Locale.US, "%d:%02d:%02d", h, m, s)
        else String.format(Locale.US, "%02d:%02d", m, s)
    }

    private fun addTitle(root: LinearLayout, title: String, subtitle: String) {
        val t = TextView(this).apply {
            text = title
            textSize = 30f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
        }
        val s = TextView(this).apply {
            text = subtitle
            textSize = 15f
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
        }
        root.addView(t, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = 8 })
        root.addView(s, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = 22 })
    }

    private fun addButton(root: LinearLayout, text: String, action: () -> Unit) {
        val button = Button(this).apply {
            this.text = text
            isFocusable = true
            isFocusableInTouchMode = true
            setOnClickListener { action() }
        }
        root.addView(button, LinearLayout.LayoutParams(-2, -2).apply { bottomMargin = 10 })
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent): Boolean {
        if (keyCode == KeyEvent.KEYCODE_BACK && player != null) {
            val now = System.currentTimeMillis()
            if (now - lastBackMs <= 1600) {
                lastBackMs = 0L
                showHome()
            } else {
                lastBackMs = now
                toast("Press BACK again to return to Home")
            }
            return true
        }
        return super.onKeyDown(keyCode, event)
    }

    private fun releasePlayer() {
        playerView?.player = null
        playerView = null
        player?.release()
        player = null
    }

    override fun onDestroy() {
        releasePlayer()
        super.onDestroy()
    }

    private fun toast(message: String) = Toast.makeText(this, message, Toast.LENGTH_LONG).show()
}
