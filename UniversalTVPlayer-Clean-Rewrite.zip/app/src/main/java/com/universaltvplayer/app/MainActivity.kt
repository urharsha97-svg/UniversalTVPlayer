package com.universaltvplayer.app

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.KeyEvent
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.focusable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.wrapContentHeight
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.input.key.KeyEventType
import androidx.compose.ui.input.key.key
import androidx.compose.ui.input.key.onPreviewKeyEvent
import androidx.compose.ui.input.key.type
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.C
import androidx.media3.common.Tracks
import androidx.media3.ui.PlayerView
import kotlinx.coroutines.delay
import java.util.Locale

class MainActivity : ComponentActivity() {
    private lateinit var controller: PlayerController

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        controller = (application as UniversalTvApplication).player

        setContent {
            MaterialTheme(colorScheme = darkColorScheme()) {
                AppRoot(controller)
            }
        }

        handleIntent(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIntent(intent)
    }

    private fun handleIntent(intent: Intent?) {
        val uri = intent?.data ?: intent?.getParcelableExtra(Intent.EXTRA_STREAM, Uri::class.java)
        if (uri != null) {
            try { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}
            controller.play(uri)
        }
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        if (keyCode == KeyEvent.KEYCODE_MEDIA_SKIP_FORWARD) {
            controller.seekBy(30_000)
            return true
        }
        if (keyCode == KeyEvent.KEYCODE_MEDIA_SKIP_BACKWARD) {
            controller.seekBy(-30_000)
            return true
        }
        return super.onKeyDown(keyCode, event)
    }
}

@Composable
private fun AppRoot(controller: PlayerController) {
    var playing by remember { mutableStateOf(false) }
    var showPlayer by remember { mutableStateOf(controller.player.isPlaying || controller.player.currentMediaItem != null) }

    LaunchedEffect(controller.player) {
        while (true) {
            playing = controller.player.isPlaying
            if (controller.player.currentMediaItem != null) showPlayer = true
            delay(300)
        }
    }

    if (showPlayer && controller.player.currentMediaItem != null) {
        PlayerScreen(
            controller = controller,
            playing = playing,
            onExit = {
                controller.player.pause()
                controller.player.clearMediaItems()
                showPlayer = false
            }
        )
    } else {
        HubScreen(
            onOpenUri = {
                controller.play(it)
                showPlayer = true
            }
        )
    }
}

@Composable
private fun HubScreen(onOpenUri: (Uri) -> Unit) {
    val context = LocalContext.current
    var url by remember { mutableStateOf("") }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        uri?.let(onOpenUri)
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.linearGradient(
                    listOf(Color(0xFF05060A), Color(0xFF101429), Color(0xFF06070A))
                )
            )
            .padding(horizontal = 34.dp, vertical = 26.dp)
    ) {
        Column(Modifier.fillMaxSize()) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text("UNIVERSAL", fontSize = 13.sp, color = Color(0xFF9EA9C9), letterSpacing = 3.sp)
                    Text("TV PLAYER", fontSize = 30.sp, color = Color.White)
                    Text("Premium media hub", fontSize = 13.sp, color = Color(0xFF77809A))
                }
                Surface(
                    color = Color.White.copy(alpha = .06f),
                    shape = RoundedCornerShape(18.dp),
                    border = BorderStroke(1.dp, Color.White.copy(alpha = .10f))
                ) {
                    Text("MEDIA3 • HARDWARE FIRST", Modifier.padding(horizontal = 16.dp, vertical = 10.dp),
                        color = Color(0xFFD9E0FF), fontSize = 12.sp)
                }
            }

            Spacer(Modifier.height(26.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(18.dp)) {
                HubCard("OPEN VIDEO", "Local files • USB • network shares", Modifier.weight(1f)) {
                    picker.launch(arrayOf("video/*", "audio/*", "application/x-matroska"))
                }
                HubCard("OPEN URL", "HTTP • HTTPS • HLS • DASH • RTSP", Modifier.weight(1f)) {}
                HubCard("SETTINGS", "Network headers • playback behavior", Modifier.weight(1f)) {}
            }

            Spacer(Modifier.height(22.dp))
            Surface(
                modifier = Modifier.fillMaxWidth().wrapContentHeight(),
                shape = RoundedCornerShape(22.dp),
                color = Color.White.copy(alpha = .055f),
                border = BorderStroke(1.dp, Color.White.copy(alpha = .08f))
            ) {
                Column(Modifier.padding(22.dp)) {
                    Text("Network source", color = Color.White, fontSize = 18.sp)
                    Spacer(Modifier.height(10.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        BasicTextField(
                            value = url,
                            onValueChange = { url = it },
                            modifier = Modifier
                                .weight(1f)
                                .background(Color.Black.copy(alpha = .28f), RoundedCornerShape(14.dp))
                                .padding(horizontal = 16.dp, vertical = 13.dp),
                            textStyle = TextStyle(color = Color.White, fontSize = 15.sp),
                            singleLine = true,
                            decorationBox = { inner ->
                                if (url.isEmpty()) Text("Paste an authorized media URL…", color = Color(0xFF6E768B))
                                inner()
                            }
                        )
                        Spacer(Modifier.width(12.dp))
                        Button(
                            onClick = { url.trim().takeIf { it.startsWith("http://") || it.startsWith("https://") }?.let { onOpenUri(Uri.parse(it)) } },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF8FA2FF), contentColor = Color.Black)
                        ) { Text("PLAY") }
                    }
                    Spacer(Modifier.height(8.dp))
                    Text("Custom User-Agent / Referer are supported for streams you are authorized to access. The player does not bypass DRM, authentication, link locks, or access controls.",
                        color = Color(0xFF747D92), fontSize = 11.sp)
                }
            }

            Spacer(Modifier.height(24.dp))
            Text("Designed for TV first", color = Color.White, fontSize = 18.sp)
            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                FeaturePill("D-PAD SCRUB")
                FeaturePill("MULTI-AUDIO")
                FeaturePill("SRT / ASS")
                FeaturePill("HDR PASSTHROUGH")
                FeaturePill("256 MB DISK CACHE")
            }
        }
    }
}

@Composable
private fun HubCard(title: String, subtitle: String, modifier: Modifier, onClick: () -> Unit) {
    var focused by remember { mutableStateOf(false) }
    val scale by animateFloatAsState(if (focused) 1.03f else 1f, tween(120), label = "scale")
    Box(
        modifier = modifier
            .height(142.dp)
            .clip(RoundedCornerShape(22.dp))
            .background(
                Brush.linearGradient(
                    listOf(Color(0xFF171C31), Color(0xFF0E111C))
                )
            )
            .border(1.dp, if (focused) Color(0xFF8FA2FF) else Color.White.copy(alpha = .08f), RoundedCornerShape(22.dp))
            .onPreviewKeyEvent {
                if (it.type == KeyEventType.KeyDown && it.key == Key.Enter) { onClick(); true } else false
            }
            .focusable()
            .clickable { onClick() }
            .alpha(scale)
    ) {
        Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.Bottom) {
            Text(title, color = Color.White, fontSize = 18.sp)
            Spacer(Modifier.height(6.dp))
            Text(subtitle, color = Color(0xFF8790A8), fontSize = 12.sp)
        }
    }
}

@Composable
private fun FeaturePill(text: String) {
    Surface(
        color = Color.White.copy(alpha = .055f),
        shape = RoundedCornerShape(50),
        border = BorderStroke(1.dp, Color.White.copy(alpha = .08f))
    ) { Text(text, Modifier.padding(horizontal = 12.dp, vertical = 7.dp), color = Color(0xFFB5BDD2), fontSize = 10.sp) }
}

@Composable
private fun PlayerScreen(controller: PlayerController, playing: Boolean, onExit: () -> Unit) {
    var controlsVisible by remember { mutableStateOf(true) }
    var trackDialog by remember { mutableStateOf<TrackDialog?>(null) }
    var subtitlePicker by remember { mutableStateOf(false) }
    var position by remember { mutableLongStateOf(controller.player.currentPosition) }
    var duration by remember { mutableLongStateOf(controller.player.duration) }
    val context = LocalContext.current

    val subtitleLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        uri?.let { controller.addExternalSubtitle(it) }
    }

    LaunchedEffect(controlsVisible, playing) {
        if (controlsVisible && playing) {
            delay(3500)
            controlsVisible = false
        }
    }
    LaunchedEffect(Unit) {
        while (true) {
            position = controller.player.currentPosition
            duration = controller.player.duration
            delay(200)
        }
    }

    BackHandler {
        if (controlsVisible) controlsVisible = false else onExit()
    }

    Box(
        Modifier
            .fillMaxSize()
            .background(Color.Black)
            .onPreviewKeyEvent { event ->
                if (event.type != KeyEventType.KeyDown) return@onPreviewKeyEvent false
                when (event.key) {
                    Key.DirectionLeft -> { controller.seekBy(-10_000); controlsVisible = true; true }
                    Key.DirectionRight -> { controller.seekBy(10_000); controlsVisible = true; true }
                    Key.MediaPlayPause, Key.Enter -> { controller.player.playWhenReady = !controller.player.playWhenReady; controlsVisible = true; true }
                    Key.Back -> { if (controlsVisible) controlsVisible = false else onExit(); true }
                    else -> false
                }
            }
    ) {
        AndroidView(
            modifier = Modifier.fillMaxSize(),
            factory = { ctx ->
                PlayerView(ctx).apply {
                    player = controller.player
                    useController = false
                    setShowBuffering(PlayerView.SHOW_BUFFERING_WHEN_PLAYING)
                    keepScreenOn = true
                }
            },
            update = { it.player = controller.player }
        )

        if (controlsVisible) {
            Box(
                Modifier.fillMaxSize().background(
                    Brush.verticalGradient(
                        0f to Color.Black.copy(alpha = .55f),
                        .22f to Color.Transparent,
                        .68f to Color.Transparent,
                        1f to Color.Black.copy(alpha = .84f)
                    )
                )
            )
            Column(Modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.SpaceBetween) {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(controller.player.currentMediaItem?.mediaMetadata?.title?.toString()
                            ?: controller.player.currentMediaItem?.localConfiguration?.uri?.lastPathSegment
                            ?: "Playing", color = Color.White, fontSize = 20.sp)
                        Text("Universal Player • Media3", color = Color(0xFF9EA7BD), fontSize = 12.sp)
                    }
                    Surface(color = Color.Black.copy(alpha = .38f), shape = RoundedCornerShape(50),
                        border = BorderStroke(1.dp, Color.White.copy(alpha = .12f))) {
                        Text(if (playing) "PLAYING" else "PAUSED", Modifier.padding(horizontal = 13.dp, vertical = 7.dp),
                            color = Color.White, fontSize = 10.sp)
                    }
                }

                Column {
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Text(formatTime(position), color = Color.White, fontSize = 12.sp)
                        Spacer(Modifier.width(10.dp))
                        Slider(
                            value = if (duration > 0) position.toFloat() / duration else 0f,
                            onValueChange = { controller.seekToFraction(it) },
                            modifier = Modifier.weight(1f),
                            thumb = { Surface(Modifier.size(14.dp), color = Color.White, shape = RoundedCornerShape(50)) {} }
                        )
                        Spacer(Modifier.width(10.dp))
                        Text(formatTime(duration), color = Color(0xFFCDD2DE), fontSize = 12.sp)
                    }
                    Spacer(Modifier.height(6.dp))
                    Row(
                        Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        PlayerButton("−30") { controller.seekBy(-30_000) }
                        PlayerButton("−10") { controller.seekBy(-10_000) }
                        PlayerButton(if (playing) "PAUSE" else "PLAY") {
                            controller.player.playWhenReady = !controller.player.playWhenReady
                        }
                        PlayerButton("+10") { controller.seekBy(10_000) }
                        PlayerButton("+30") { controller.seekBy(30_000) }
                        PlayerButton("AUDIO") { trackDialog = TrackDialog.Audio }
                        PlayerButton("SUB") { trackDialog = TrackDialog.Text }
                        PlayerButton("ADD SRT/ASS") { subtitleLauncher.launch(arrayOf("text/*", "application/x-subrip", "text/x-ssa")) }
                        PlayerButton("INFO") { trackDialog = TrackDialog.Info }
                        PlayerButton("EXIT") { onExit() }
                    }
                }
            }
        }
    }

    if (trackDialog != null) {
        TrackDialogView(
            controller = controller,
            kind = trackDialog!!,
            onDismiss = { trackDialog = null }
        )
    }
}

private enum class TrackDialog { Audio, Text, Info }

@Composable
private fun TrackDialogView(controller: PlayerController, kind: TrackDialog, onDismiss: () -> Unit) {
    val groups = controller.player.currentTracks.groups.filter {
        when (kind) {
            TrackDialog.Audio -> it.type == C.TRACK_TYPE_AUDIO
            TrackDialog.Text -> it.type == C.TRACK_TYPE_TEXT
            TrackDialog.Info -> true
        }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                when (kind) {
                    TrackDialog.Audio -> "Audio tracks"
                    TrackDialog.Text -> "Subtitles"
                    TrackDialog.Info -> "Playback info"
                }
            )
        },
        text = {
            if (kind == TrackDialog.Info) {
                Column {
                    Text("Engine: Media3 / ExoPlayer")
                    Text("Format: ${controller.player.videoFormat?.sampleMimeType ?: "unknown"}")
                    Text("Resolution: ${controller.player.videoFormat?.width ?: 0} × ${controller.player.videoFormat?.height ?: 0}")
                    Text("Audio: ${controller.player.audioFormat?.sampleMimeType ?: "unknown"}")
                    Text("Buffer: ${controller.player.bufferedPercentage}%")
                    controller.lastError?.let { Text("Error: $it") }
                }
            } else if (groups.isEmpty()) {
                Text("No ${if (kind == TrackDialog.Audio) "audio" else "subtitle"} tracks detected.")
            } else {
                Column {
                    groups.forEachIndexed { groupIndex, group ->
                        for (i in 0 until group.length) {
                            val f = group.getTrackFormat(i)
                            val label = listOfNotNull(
                                f.language?.let { Locale.forLanguageTag(it).getDisplayLanguage(Locale.getDefault()) },
                                f.label,
                                f.sampleMimeType,
                                f.channelCount.takeIf { it > 0 }?.let { "${it}ch" }
                            ).distinct().joinToString(" • ").ifBlank { "Track ${i + 1}" }
                            TextButton(onClick = {
                                controller.selectTrack(group, i)
                                onDismiss()
                            }) { Text(label, color = Color.White) }
                        }
                    }
                    if (kind == TrackDialog.Text) {
                        TextButton(onClick = { controller.disableTextTracks(); onDismiss() }) {
                            Text("Turn subtitles off")
                        }
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("CLOSE") } }
    )
}

@Composable
private fun PlayerButton(label: String, onClick: () -> Unit) {
    Surface(
        modifier = Modifier.clip(RoundedCornerShape(12.dp)).clickable { onClick() },
        color = Color.White.copy(alpha = .10f),
        border = BorderStroke(1.dp, Color.White.copy(alpha = .10f)),
        shape = RoundedCornerShape(12.dp)
    ) {
        Text(label, Modifier.padding(horizontal = 13.dp, vertical = 9.dp), color = Color.White, fontSize = 11.sp)
    }
}

private fun formatTime(ms: Long): String {
    if (ms < 0) return "00:00"
    val total = ms / 1000
    val h = total / 3600
    val m = (total % 3600) / 60
    val s = total % 60
    return if (h > 0) "%d:%02d:%02d".format(h, m, s) else "%02d:%02d".format(m, s)
}
