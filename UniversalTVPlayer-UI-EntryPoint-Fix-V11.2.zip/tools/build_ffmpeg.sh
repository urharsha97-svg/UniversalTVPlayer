#!/usr/bin/env bash
set -euo pipefail

# Builds the official AndroidX Media3 FFmpeg decoder extension for this project.
# Native FFmpeg is intentionally not checked into the repo. The script follows
# the AndroidX Media3 decoder_ffmpeg workflow and produces the AAR consumed by app/.
#
# Prerequisites: git, Java 17, Android SDK, Android NDK/CMake, bash.
# See: https://github.com/androidx/media/tree/release/libraries/decoder_ffmpeg

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
WORK="${ROOT}/.native/media3"
TAG="1.11.0"

mkdir -p "${ROOT}/.native"
if [[ ! -d "${WORK}/.git" ]]; then
  git clone --depth 1 --branch "${TAG}" https://github.com/androidx/media.git "${WORK}"
fi

cd "${WORK}"

# The AndroidX README for decoder_ffmpeg requires building FFmpeg native
# libraries before the Gradle AAR task. Run its script when available.
FFMPEG_README="libraries/decoder_ffmpeg/README.md"
if [[ -f "${FFMPEG_README}" ]]; then
  echo "Read ${FFMPEG_README} for the exact NDK/FFmpeg prerequisites for your host."
fi

./gradlew :libraries:decoder_ffmpeg:assembleRelease

AAR="$(find "${WORK}/libraries/decoder_ffmpeg/build/outputs/aar" -maxdepth 1 -type f -name '*release*.aar' -print -quit)"
if [[ -z "${AAR}" ]]; then
  echo "ERROR: decoder_ffmpeg AAR was not produced."
  echo "Build the native FFmpeg libraries described by ${FFMPEG_README}, then rerun."
  exit 2
fi

mkdir -p "${ROOT}/app/libs"
cp "${AAR}" "${ROOT}/app/libs/lib-decoder-ffmpeg-release.aar"
echo "Installed: ${ROOT}/app/libs/lib-decoder-ffmpeg-release.aar"
