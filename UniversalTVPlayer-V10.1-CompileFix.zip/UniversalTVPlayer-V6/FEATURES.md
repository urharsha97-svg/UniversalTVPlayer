# Universal TV Player V10.1

- Original premium TV-first glass UI with optional AMOLED true-black mode.
- Soft ambient edge-light animation during playback.
- Large visual seek bar + remote LEFT/RIGHT skip + 5/10/30 second controls.
- Easy AUDIO and SUB track dialogs on Media3.
- First BACK hides controls; second BACK returns home.
- Media3 ExoPlayer 1.11.0 is primary; LibVLC 3.7.5 remains a compatibility fallback.
- Media3 HLS/DASH/RTSP/progressive playback with OkHttp, redirect following, retry-on-network-failure and persistent 32–256 MB disk cache.
- Optional User-Agent and Referer headers for servers where the user is authorized to access the stream. These settings do not bypass DRM/authentication/access controls.
- Stereo downmix preference limits audio selection to 2-channel tracks when enabled; final downmix/dialogue processing remains device/decoder dependent.
- HDR playback is device/decoder dependent. HDR10/HDR10+/HLG/Dolby Vision support is not guaranteed on every Android TV.
- HDR→SDR tone mapping is exposed as a compatibility preference, but real-time conversion depends on Android/device decoder support. Media3's current platform APIs document device-dependent HDR/tone-map support.
- Media3 Compose Material3 + Leanback UI modules are included for future TV UI integration.
- A true libmpv C++ JNI backend is not falsely claimed as bundled: libmpv Android binaries require a native build per ABI/device. The current stable build therefore uses Media3 + LibVLC without shipping a non-working native stub.
- Universal APK is enabled for easier installation across supported ARM TV architectures, at the cost of a larger APK.
