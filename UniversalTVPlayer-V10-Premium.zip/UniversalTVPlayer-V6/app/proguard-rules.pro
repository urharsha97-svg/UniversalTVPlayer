# LibVLC/Media3 use reflection and native libraries internally.
# Keep app classes and native entry points safe for release shrinking.
-keep class org.videolan.** { *; }
-keep class androidx.media3.** { *; }
