# Universal TV Player — Clean Rewrite

A fresh Android TV + mobile video player built around **AndroidX Media3 / ExoPlayer**. No LibVLC, no experimental V4–V10 code, and no legacy layout tree.

## Architecture

```text
UniversalTVPlayer
├── app
│   ├── MainActivity.kt              # intent entry + dual UI
│   ├── PlayerController.kt          # one ExoPlayer, cache, network policy
│   ├── UniversalTvApplication.kt
│   └── res/
├── tools/
│   └── build_ffmpeg.sh              # optional official Media3 FFmpeg AAR build
└── .github/workflows/build.yml
```

### Outer hub
- Original premium TV-first dashboard.
- AMOLED/dark visual language, glass cards and D-pad-friendly focus targets.
- Local document picker plus network URL entry.
- No Just Player UI copied into the hub.

### Inner player
The playback overlay deliberately follows the **clean, lightweight interaction pattern** the user asked for while using original visuals and controls:
- Large, unobtrusive title and status.
- Single seek line with direct touch/mouse scrubbing.
- D-pad Left/Right = ±10 seconds.
- Media Skip Forward/Backward keys = ±30 seconds.
- ±5/10/30 style buttons are available on-screen.
- First Back hides controls; second Back exits to the hub.
- Audio track and subtitle dialogs switch tracks without intentionally pausing playback.
- External `.srt`, `.ass/.ssa`, and `.vtt` can be added while playing.
- `INFO` exposes current decoder/format/buffer information.

## Intent / "Choose Video Player"
`AndroidManifest.xml` registers the activity for `VIEW` with `http`, `https`, `content`, and `file` schemes plus video/audio MIME types. The application and activity both use `@string/app_name`, and a real launcher icon is supplied.

On some OEM file managers, the chooser is cached. After installing a new build, restart the file manager/device if the old app list remains.

## Media engine
Media3 1.11.0 is the only playback engine. Hardware MediaCodec is preferred by ExoPlayer where supported. HLS, DASH, SmoothStreaming and RTSP modules are included.

### HDR
HDR10/HDR10+/HLG and Dolby Vision playback is **passthrough/device dependent**. Media3 can identify and route supported HDR formats, but an Android app cannot force a TV chipset to decode a profile it does not expose.

HDR→SDR tone mapping is an Android/Media3 capability on supported API levels and decoder paths; this clean rewrite keeps playback in passthrough mode rather than pretending every TV has software tone mapping.

## FFmpeg
AndroidX Media3's FFmpeg extension is a **native decoder extension** and is not distributed as a normal Maven runtime artifact. Android's documentation requires the native library to be built before it can be bundled.

Run:

```bash
./tools/build_ffmpeg.sh
./gradlew :app:assembleDebug
```

The script clones the official AndroidX Media3 `1.11.0` source and builds `decoder_ffmpeg`. If native FFmpeg prerequisites are missing, the base player still compiles; install the required NDK/CMake/FFmpeg prerequisites and rerun the script to add the software decoder AAR.

The extension is loaded reflectively by Media3 when present. It is therefore optional at compile time and does not contaminate the core player with another playback engine.

**Important:** FFmpeg support does not magically guarantee every requested codec. The actual decoder set depends on the FFmpeg build configuration and device output path. Dolby Atmos/TrueHD/DTS/DTS-HD/DTS:X passthrough also depends on the Android audio stack, HDMI/eARC receiver, and device firmware.

## Network / buffering
- OkHttp-backed Media3 DataSource.
- Redirect following and retry on transient failures.
- User-Agent + Referer injection for **streams the user is authorized to access**.
- 256 MB persistent LRU disk cache.
- 128 MB target buffer budget and 10–60 second load-control window.
- Seek uses Media3's sync-point seeking and ExoPlayer automatically discards obsolete buffered media after a seek.

This project intentionally does **not** implement link-lock/DRM/authentication bypasses or fake "unlimited 256 MB RAM" claims. A single HTTP response is not safely turned into a multi-threaded downloader without knowing the server's range semantics; HLS/DASH already provide segmented parallel fetching, and the cache prevents repeated network downloads.

## Build
Requires Java 17 and Android SDK 36.

```bash
./gradlew :app:assembleDebug
```

GitHub Actions recursively builds the project and uploads the APK.

## License
Application code is original. AndroidX Media3 and its FFmpeg extension remain under their respective licenses. If you bundle FFmpeg, keep the required FFmpeg/AndroidX notices and source-offer obligations for the exact configuration you ship.
