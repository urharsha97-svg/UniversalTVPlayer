# Universal TV Player V4

V4 uses LibVLC as the broad-format playback engine and Media3 for modern HLS/DASH support.

The player UI exposes the requested video/audio containers, codecs, HDR/color labels, resolutions, frame rates, subtitles, 3D/VR, audio layouts, source/rip tags and mastering tags. Actual playback/output is hardware-dependent: Android TV SoC decoder support, connected display, HDMI capabilities and available LibVLC decoder paths determine what can be decoded or passed through. No Android app can force a TV to decode unsupported 16K/240fps/VVC/Dolby formats.

The included GitHub Actions workflow extracts the ZIP and builds the nested Android project. It prefers the `*Fixed*.zip` upload so an older V4 ZIP is not accidentally selected.
