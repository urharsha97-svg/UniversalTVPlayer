# Universal TV Player V4

Universal TV Player V4 keeps the V3 TV-first workflow but upgrades playback to **LibVLC 3.7.5** for a substantially broader media stack than Android's platform decoder alone.

## Build

- Java 17 / Temurin
- Gradle 8.10.2
- Android Gradle Plugin 8.7.3
- Kotlin 2.0.21
- minSdk 23 / targetSdk 35
- Version 0.4.0 / versionCode 4

## Playback engine

LibVLC is used as the primary decoder/demuxer. This is intended to cover a very broad range of containers, codecs, audio formats, subtitles and network streams including MKV, MP4, AVI, MOV, WebM, MPEG-TS/M2TS, FLV, WMV/ASF, HLS, DASH and RTSP where supported by the VLC engine and the device.

The V4 UI also detects common filename/URL capability tags and briefly shows them for about 1.2 seconds when playback starts. INFO keeps the same details visible.

## Important hardware limitation

No Android app can guarantee Dolby Vision, HDR10+, HDR10+ Adaptive, Dolby Vision IQ, 10/12-bit 4:2:2/4:4:4, 8K/16K, 120/144/240 fps or a specific color gamut on every TV. Actual output is constrained by the TV's Android build, GPU/decoder, firmware, HDMI/display pipeline and the media itself. V4 enables the broadest practical software playback path but does not manufacture unsupported hardware capabilities.
