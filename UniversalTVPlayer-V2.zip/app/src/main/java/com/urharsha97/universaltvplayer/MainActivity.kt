package com.urharsha97.universaltvplayer

import android.app.Activity
import android.os.Bundle
import android.view.View
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.focusable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.C
import androidx.media3.common.Format
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.common.Tracks
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView

@UnstableApi
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.decorView.systemUiVisibility =
            View.SYSTEM_UI_FLAG_FULLSCREEN or
            View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY

        setContent {
            MaterialTheme {
                UniversalTVPlayerApp()
            }
        }
    }
}

@UnstableApi
@Composable
private fun UniversalTVPlayerApp() {
    val context = LocalContext.current
    val activity = context as? Activity
    val player = remember {
        ExoPlayer.Builder(context)
            .setHandleAudioBecomingNoisy(true)
            .build()
    }

    var url by remember { mutableStateOf("") }
    var playing by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf("Ready") }
    var mediaInfo by remember { mutableStateOf("No stream loaded") }
    var speed by remember { mutableFloatStateOf(1f) }
    var showInfo by remember { mutableStateOf(false) }

    val inputFocus = remember { FocusRequester() }

    DisposableEffect(player) {
        val listener = object : Player.Listener {
            override fun onPlaybackStateChanged(state: Int) {
                status = when (state) {
                    Player.STATE_BUFFERING -> "Buffering…"
                    Player.STATE_READY -> if (player.playWhenReady) "Playing" else "Ready"
                    Player.STATE_ENDED -> "Ended"
                    else -> "Idle"
                }
            }

            override fun onIsPlayingChanged(isPlaying: Boolean) {
                playing = isPlaying
            }

            override fun onTracksChanged(tracks: Tracks) {
                val video = tracks.groups
                    .firstOrNull { it.type == C.TRACK_TYPE_VIDEO && it.length > 0 }
                val audio = tracks.groups
                    .firstOrNull { it.type == C.TRACK_TYPE_AUDIO && it.length > 0 }

                val vf: Format? = video?.getTrackFormat(0)
                val af: Format? = audio?.getTrackFormat(0)

                mediaInfo = buildString {
                    append("Video: ")
                    append(vf?.sampleMimeType ?: "unknown")
                    if (vf?.width != null && vf.height != null) {
                        append(" • ${vf.width}×${vf.height}")
                    }
                    if (vf?.frameRate != null && vf.frameRate > 0) {
                        append(" • ${"%.2f".format(vf.frameRate)} FPS")
                    }
                    append("\nAudio: ")
                    append(af?.sampleMimeType ?: "unknown")
                    if (af?.channelCount != null && af.channelCount > 0) {
                        append(" • ${af.channelCount} ch")
                    }
                    if (af?.sampleRate != null && af.sampleRate > 0) {
                        append(" • ${af.sampleRate} Hz")
                    }
                    append("\nTracks: ${tracks.groups.size}")
                }
            }
        }
        player.addListener(listener)
        onDispose {
            player.removeListener(listener)
            player.release()
        }
    }

    fun loadUrl() {
        val clean = url.trim()
        if (clean.isEmpty()) {
            status = "Enter a URL"
            return
        }
        try {
            player.setMediaItem(MediaItem.fromUri(clean))
            player.prepare()
            player.playWhenReady = true
            status = "Loading…"
        } catch (e: Exception) {
            status = "Invalid URL"
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF080808))
    ) {
        if (playing || player.playbackState == Player.STATE_BUFFERING || player.mediaItemCount > 0) {
            AndroidView(
                modifier = Modifier.fillMaxSize(),
                factory = { ctx ->
                    PlayerView(ctx).apply {
                        this.player = player
                        useController = true
                        controllerShowTimeoutMs = 3500
                        setShowBuffering(PlayerView.SHOW_BUFFERING_ALWAYS)
                        setKeepContentOnPlayerReset(true)
                    }
                },
                update = { it.player = player }
            )

            Row(
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .padding(24.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Button(
                    onClick = { showInfo = !showInfo },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xCC202020))
                ) {
                    Text("INFO")
                }
                Button(
                    onClick = {
                        player.pause()
                        player.clearMediaItems()
                        status = "Ready"
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xCC202020))
                ) {
                    Text("STOP")
                }
            }

            if (showInfo) {
                Column(
                    modifier = Modifier
                        .align(Alignment.BottomStart)
                        .padding(28.dp)
                        .background(Color(0xEE151515), RoundedCornerShape(14.dp))
                        .padding(18.dp)
                ) {
                    Text("Stream information", color = Color.White, fontSize = 20.sp)
                    Spacer(Modifier.height(8.dp))
                    Text(mediaInfo, color = Color.LightGray, fontSize = 15.sp)
                    Spacer(Modifier.height(8.dp))
                    Text("Status: $status", color = Color.LightGray, fontSize = 15.sp)
                }
            }
        } else {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 64.dp),
                verticalArrangement = Arrangement.Center
            ) {
                Text("Universal TV Player", color = Color.White, fontSize = 38.sp)
                Spacer(Modifier.height(10.dp))
                Text(
                    "TV-first streaming player • Media3 engine",
                    color = Color.Gray,
                    fontSize = 18.sp
                )
                Spacer(Modifier.height(28.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    BasicTextField(
                        value = url,
                        onValueChange = { url = it },
                        singleLine = true,
                        modifier = Modifier
                            .weight(1f)
                            .height(62.dp)
                            .background(Color(0xFF202020), RoundedCornerShape(10.dp))
                            .border(2.dp, Color(0xFF444444), RoundedCornerShape(10.dp))
                            .padding(horizontal = 18.dp, vertical = 19.dp)
                            .focusRequester(inputFocus)
                            .focusable(),
                        textStyle = TextStyle(color = Color.White, fontSize = 18.sp),
                        decorationBox = { inner ->
                            if (url.isEmpty()) {
                                Text(
                                    "Paste video/audio URL (.m3u8, .mpd, MP4, etc.)",
                                    color = Color.Gray,
                                    fontSize = 18.sp
                                )
                            }
                            inner()
                        }
                    )
                    Spacer(Modifier.width(16.dp))
                    Button(
                        onClick = { loadUrl() },
                        modifier = Modifier.height(62.dp)
                    ) {
                        Text("PLAY", fontSize = 18.sp)
                    }
                }

                Spacer(Modifier.height(22.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    Button(onClick = {
                        speed = when (speed) {
                            1f -> 1.25f
                            1.25f -> 1.5f
                            1.5f -> 2f
                            else -> 1f
                        }
                        player.setPlaybackSpeed(speed)
                    }) {
                        Text("Speed ${speed}x")
                    }
                    Button(onClick = { showInfo = !showInfo }) {
                        Text("Stream Info")
                    }
                }

                Spacer(Modifier.height(14.dp))
                Text(
                    "HLS • DASH • progressive streams • audio/video tracks • buffering status",
                    color = Color.Gray,
                    fontSize = 15.sp
                )
                Text(
                    "HDR and codec playback depend on the TV's Android decoder/display capabilities.",
                    color = Color.Gray,
                    fontSize = 14.sp
                )

                LaunchedEffect(Unit) {
                    inputFocus.requestFocus()
                }
            }
        }
    }
}
