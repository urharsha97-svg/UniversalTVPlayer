# V11.7 TV Runtime Stability Audit

Based on V11.3 source. This package adds defensive Android TV startup/rendering protections.

## Applied
- Android TV hardware declarations: touchscreen optional and Leanback optional.
- Main application/activity use the platform `Theme.Material.NoActionBar` to avoid a custom-theme dependency at Activity creation.
- `UniversalTvApplication` remains lazy; PlayerController/ExoPlayer are created only when needed.
- SurfaceView is connected to ExoPlayer from `SurfaceHolder.Callback.surfaceCreated` and detached from `surfaceDestroyed`.
- Compose lifecycle observer detaches the video surface on `ON_STOP` and disposal.
- Media3 `DefaultRenderersFactory` uses `EXTENSION_RENDERER_MODE_PREFER` when constructible; renderer-factory setup falls back to the standard ExoPlayer renderer path on failure.
- `MainActivity.onCreate()` protects initial `setContent {}` and installs an uncaught-exception logger. If initial Compose setup throws synchronously, a minimal fallback Error Screen is attempted.
- `onDestroy()` releases the controller's ExoPlayer instance.
- Version bumped to 1.1.6 / versionCode 117.

## Important limitation
A native decoder or vendor hardware decoder can still crash inside native/vendor code after playback starts. Kotlin try/catch cannot intercept a process-level native SIGSEGV/abort. This package therefore keeps decoder initialization conservative and isolates extension-renderer setup, but a device-specific native crash still requires the device's logcat tombstone/stack trace.
