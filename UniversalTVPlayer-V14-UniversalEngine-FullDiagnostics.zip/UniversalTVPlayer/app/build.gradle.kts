plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.universaltvplayer"
    compileSdk = 36

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }

    defaultConfig {
        applicationId = "com.universaltvplayer"
        minSdk = 23
        targetSdk = 35
        versionCode = 140
        versionName = "1.4.0"
    }
}

dependencies {
    implementation("androidx.activity:activity-ktx:1.10.1")

    // Existing Media3 engine — retained.
    implementation("androidx.media3:media3-exoplayer:1.11.0")
    implementation("androidx.media3:media3-ui:1.11.0")
    implementation("androidx.media3:media3-exoplayer-rtsp:1.11.0")

    // Streaming modules for direct HLS/DASH/SmoothStreaming sources.
    implementation("androidx.media3:media3-exoplayer-hls:1.11.0")
    implementation("androidx.media3:media3-exoplayer-dash:1.11.0")
    implementation("androidx.media3:media3-exoplayer-smoothstreaming:1.11.0")

    // FFmpeg software decoder extension for Media3 1.11.0.
    // Universal Engine uses it as a decoder extension; FFmpeg Engine gives it priority.
    implementation("io.github.anilbeesetti:nextlib-media3ext:1.11.0-0.15.0")
}
