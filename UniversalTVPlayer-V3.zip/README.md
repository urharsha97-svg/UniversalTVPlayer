# Universal TV Player V3

Clean TV-first player foundation with Media3/ExoPlayer.

Features in this V3 foundation:
- Direct HTTP/HTTPS URL playback
- HLS and DASH modules
- TV/D-pad friendly interface
- Play/pause, seek, speed, stop
- Stream information
- Video/audio MIME, resolution, FPS, bitrate, channels and sample rate
- Zoom control foundation
- HDR/Dolby Vision handled according to Android TV hardware/display support

Important: no Android player can guarantee every codec/container/HDR format on every device. Hardware decoder and display capabilities remain the final limitation.
