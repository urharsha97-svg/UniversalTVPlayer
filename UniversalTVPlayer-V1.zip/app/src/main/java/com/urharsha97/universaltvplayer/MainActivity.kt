package com.urharsha97.universaltvplayer

import android.os.Bundle
import android.view.View
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.focusable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.media3.common.MediaItem
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import androidx.compose.ui.viewinterop.AndroidView

@UnstableApi
class MainActivity : ComponentActivity() {
    private var player: ExoPlayer? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        window.decorView.systemUiVisibility = (
            View.SYSTEM_UI_FLAG_FULLSCREEN or
            View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
        )

        setContent {
            MaterialTheme {
                UniversalTVPlayerApp(
                    onPlay = { url ->
                        playUrl(url)
                    }
                )
            }
        }
    }

    private fun playUrl(url: String) {
        if (url.isBlank()) return
        val exo = player ?: ExoPlayer.Builder(this).build().also { player = it }
        exo.setMediaItem(MediaItem.fromUri(url.trim()))
        exo.prepare()
        exo.playWhenReady = true
    }

    override fun onStop() {
        super.onStop()
        player?.release()
        player = null
    }
}

@Composable
private fun UniversalTVPlayerApp(onPlay: (String) -> Unit) {
    var url by remember { mutableStateOf("") }
    var showPlayer by remember { mutableStateOf(false) }
    val focusRequester = remember { FocusRequester() }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF090909))
    ) {
        if (showPlayer) {
            AndroidView(
                modifier = Modifier.fillMaxSize(),
                factory = { context ->
                    PlayerView(context).apply {
                        useController = true
                        setShowBuffering(PlayerView.SHOW_BUFFERING_WHEN_PLAYING)
                    }
                }
            )

            Button(
                onClick = { showPlayer = false },
                modifier = Modifier
                    .align(Alignment.TopStart)
                    .padding(28.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xAA222222))
            ) {
                Text("Back")
            }
        } else {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 64.dp, vertical = 48.dp),
                verticalArrangement = Arrangement.Center
            ) {
                Text(
                    text = "Universal TV Player",
                    color = Color.White,
                    fontSize = 34.sp
                )
                Spacer(Modifier.height(16.dp))
                Text(
                    text = "Paste a direct video/audio stream URL",
                    color = Color.LightGray,
                    fontSize = 18.sp
                )
                Spacer(Modifier.height(24.dp))

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    BasicTextField(
                        value = url,
                        onValueChange = { url = it },
                        modifier = Modifier
                            .weight(1f)
                            .height(58.dp)
                            .background(Color(0xFF222222))
                            .padding(horizontal = 18.dp, vertical = 17.dp)
                            .focusRequester(focusRequester)
                            .focusable(),
                        textStyle = TextStyle(
                            color = Color.White,
                            fontSize = 18.sp
                        ),
                        singleLine = true,
                        decorationBox = { inner ->
                            if (url.isEmpty()) {
                                Text(
                                    "https://example.com/video.m3u8",
                                    color = Color.Gray,
                                    fontSize = 18.sp
                                )
                            }
                            inner()
                        }
                    )

                    Spacer(Modifier.width(16.dp))

                    Button(
                        onClick = {
                            onPlay(url)
                            showPlayer = true
                        },
                        modifier = Modifier.height(58.dp)
                    ) {
                        Text("PLAY", fontSize = 18.sp)
                    }
                }

                Spacer(Modifier.height(28.dp))
                Text(
                    text = "Supports Media3 playback: progressive HTTP, HLS and DASH.\nCodec/HDR support depends on the TV's available decoders and display.",
                    color = Color.Gray,
                    fontSize = 15.sp
                )
            }

            LaunchedEffect(Unit) {
                focusRequester.requestFocus()
            }
        }
    }
}
