# Universal TV Player V9

Professional Android TV media player build. Designed for Android 11+ TVs with a VLC-style fullscreen playback experience.

GitHub Actions scans ZIP files anywhere in the repository, selects the newest valid Android project ZIP, builds debug APKs and uploads all APK outputs.

For installation on a TV when architecture is unknown, use the `universal` APK artifact.
