# Universal TV Player V10.2

Premium Android TV player with an original glass-style interface, Media3-first playback and LibVLC fallback.

## Included
- Glassmorphism TV controls + optional AMOLED true-black mode.
- Ambient edge-light animation during playback.
- Large seek bar, D-pad LEFT/RIGHT seeking, 5/10/30 second controls.
- AUDIO / SUB dialogs for Media3 tracks.
- First BACK hides controls; second BACK returns to Home.
- Media3 ExoPlayer 1.11.0 primary engine.
- LibVLC 3.7.5 compatibility fallback and Android MediaPlayer fallback.
- HLS, DASH, RTSP and progressive playback.
- OkHttp network stack with User-Agent / optional Referer, redirect following, retries and persistent 32–256 MB disk cache.
- Resume history, local file picker, speed control, decoder/performance settings.
- Media3 Compose Material3 and Leanback dependencies included for TV-first extension work.
- Universal APK enabled for easier installation across supported ARM TV architectures.

## Important compatibility note
HDR10, HDR10+, HLG, Dolby Vision profiles, H.266/VVC, ProRes, DTS-family audio, TrueHD, Atmos and other advanced formats are hardware/firmware/decoder dependent. The app cannot force a TV decoder to support a format it does not expose.

The network header controls are intended for streams the user is authorized to access. They do not bypass DRM, authentication or access controls.

A true libmpv C++ JNI backend is intentionally not shipped as a fake stub. Building libmpv for Android requires native binaries per ABI/device; the stable V10.2 package therefore uses Media3 + LibVLC without claiming an untested native engine.
