# Universal TV Player V11.8 — Native Safety Patch

## Startup isolation
The launcher Activity renders the Compose Hub without accessing `PlayerController`, `ExoPlayer`, MediaCodec, FFmpeg, or a video output surface. The player controller is constructed only after an explicit media selection or an explicit media VIEW intent.

## Renderer policy
Media3 `DefaultRenderersFactory` is configured with `EXTENSION_RENDERER_MODE_OFF` for the initial player. This avoids FFmpeg/extension probing during player creation. Standard Media3 renderers are used first.

## Video output
Playback uses `TextureView`. ExoPlayer receives the TextureView only from `SurfaceTextureListener.onSurfaceTextureAvailable()`, and the output is detached when the texture is destroyed.

## Crash logging
`CrashLogger` writes uncaught exceptions and guarded media initialization errors to:
`context.filesDir/crash.log`

ADB:
```bash
adb logcat *:E
```
For a clean capture:
```bash
adb logcat -c
adb logcat *:E
```
Then launch the app and reproduce the crash.
