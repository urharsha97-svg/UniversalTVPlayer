# Universal TV Player — UI Rewrite 11

## UI architecture
- Fresh Jetpack Compose outer hub with adaptive card grid, AMOLED background, glass header and D-pad focus glow.
- Fresh inner playback surface using Android `SurfaceView` directly. No `PlayerView`, `PlayerControlView`, or ExoPlayer default controller is used.
- Custom bottom playback bar with thin seek control, time display, seek shortcuts, Audio, Subtitle, Aspect and Settings actions.
- Audio/subtitle actions open a custom Compose bottom sheet while playback continues.
- Back state machine: first Back hides controls; second Back exits playback.
- D-pad Left/Right performs immediate 5-second seeks; Fast Forward/Rewind and media skip keys provide 10/30-second jumps.

## Resolver integration
- Activity label is explicitly `Universal TV Player`.
- Explicit VIEW filters cover `video/*` and `audio/*` with `http`, `https`, `file`, and `content` schemes.
- Launcher and Leanback entries use the custom application icon.

## Playback
- Media3 ExoPlayer only; LibVLC is absent.
- Direct SurfaceView rendering avoids the default Media3 UI layer entirely.
- Existing Media3 network/cache/FFmpeg architecture is retained separately from the UI.
