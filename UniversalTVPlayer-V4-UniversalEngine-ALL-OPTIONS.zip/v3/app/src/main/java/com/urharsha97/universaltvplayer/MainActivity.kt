package com.urharsha97.universaltvplayer

import android.app.Activity
import android.net.Uri
import android.os.Bundle
import android.view.View
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.focusable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import org.videolan.libvlc.LibVLC
import org.videolan.libvlc.Media
import org.videolan.libvlc.MediaPlayer
import org.videolan.libvlc.util.VLCVideoLayout

private data class CapabilityCategory(val title: String, val items: List<String>)

private val capabilityCategories = listOf(
    CapabilityCategory("Video Containers & Formats", listOf("MKV (Matroska)","MP4","AVI","MOV","WebM","TS / M2TS","FLV","WMV")),
    CapabilityCategory("Dynamic Range & Color Formats", listOf("SDR (Standard Dynamic Range)","HDR (High Dynamic Range)","HDR10","HDR10+","HDR10+ Adaptive","Dolby Vision (DoVi / DV)","Dolby Vision IQ","HLG (Hybrid Log-Gamma)","Advanced HDR by Technicolor","DisplayHDR (400, 600, 1000)","Rec. 709","Rec. 2020","DCI-P3","sRGB","Adobe RGB","4:4:4","4:2:2","4:2:0")),
    CapabilityCategory("Resolutions & Quality", listOf("SD (Standard Definition - 480p)","HD (High Definition - 720p)","FHD (Full HD - 1080p)","QHD / 2K (Quad HD - 1440p)","UHD / 4K (Ultra HD - 2160p)","5K","8K","16K")),
    CapabilityCategory("Video Codecs & Compression", listOf("H.264 / AVC / x264","H.265 / HEVC / x265","H.266 / VVC","VP8","VP9","AV1","MPEG-2","MPEG-4","Apple ProRes","DNxHD / DNxHR","VC-1","Xvid","DivX","10-bit / 12-bit")),
    CapabilityCategory("Movie Sources & Rips (Tags)", listOf("REMUX","WEB-DL","WEBRip","BluRay / BDRip / BRRip","HDRip","HDTV","DVDRip","VODRip","DVDScr / SCR","WP (Workprint)","TC (Telecine)","TS (Telesync)","HDCAM / CAM","R5","Line")),
    CapabilityCategory("Movie Versions & Cuts", listOf("THEATRICAL","DIRECTOR'S CUT (DC)","EXTENDED","UNRATED","REMASTERED","OPEN MATTE","PROPER","REPACK","IMAX Enhanced")),
    CapabilityCategory("Audio Formats & Codecs", listOf("Dolby Atmos","Dolby TrueHD","DDP / E-AC3 (Dolby Digital Plus)","AC3 (Dolby Digital 5.1)","DTS:X","DTS-HD MA (Master Audio)","DTS","AAC (2.0 / 5.1)","FLAC","Dual Audio / Multi-Audio")),
    CapabilityCategory("Frame Rates & Motion", listOf("24fps","30fps","60fps","120fps / 144fps / 240fps","HFR (High Frame Rate)","VFR (Variable Frame Rate)")),
    CapabilityCategory("Subtitles & Languages", listOf("ESub (Embedded Subtitles)","HC-SUB (Hardcoded Subtitles)","CC (Closed Captions)","Dubbed","Subbed")),
    CapabilityCategory("3D, VR & Broadcast", listOf("3D SBS (Side-by-Side)","3D OU (Over-Under)","VR 180","VR 360","Spatial Video","NTSC","PAL","SECAM")),
    CapabilityCategory("Audio Containers & File Formats", listOf("MP3 (MPEG-1 Audio Layer III)","AAC (Advanced Audio Coding)","FLAC (Free Lossless Audio Codec)","WAV (Waveform Audio File Format)","ALAC (Apple Lossless Audio Codec)","OGG (Ogg Vorbis)","Opus","M4A","WMA (Windows Media Audio)","AIFF (Audio Interchange File Format)","APE (Monkey's Audio)","DSD (Direct Stream Digital)","PCM (Pulse Code Modulation)","AC3 / Dolby Digital","E-AC3 / Dolby Digital Plus","DTS (Digital Theater Systems)","TrueHD","MP2","AMR","MIDI")),
    CapabilityCategory("Audio Channels & Layouts", listOf("Mono (1.0)","Stereo (2.0)","2.1 (Stereo + Subwoofer)","5.1 Surround (5 Speakers + 1 Subwoofer)","7.1 Surround (7 Speakers + 1 Subwoofer)","Dolby Atmos / Spatial Audio (Object-based)","DTS:X","Binaural Audio")),
    CapabilityCategory("Audio Rips, Sources & Quality Tags", listOf("WEB-DL / WEBRip (Audio ripped from streaming platforms)","FLAC 24-bit / Hi-Res Audio","Lossless","Vinyl Rip / LP Rip","CDDA / CD Rip","Lossy","320kbps / 256kbps / 128kbps (Bitrates)","CBR (Constant Bitrate)","VBR (Variable Bitrate)","Mastered for iTunes (MFiT)","Spatial Audio / Dolby Atmos Mix")),
    CapabilityCategory("Audio Mastering & Processing Tags", listOf("Remastered","Hi-Res (High-Resolution Audio)","Spatial","Binaural","Lossless","Uncompressed"))
)

private fun detectedTags(text: String): List<String> {
    val s = text.uppercase()
    val pairs = listOf(
        "HDR10+ ADAPTIVE" to "HDR10+ Adaptive", "HDR10+" to "HDR10+", "DOLBY VISION IQ" to "Dolby Vision IQ", "DOLBY VISION" to "Dolby Vision (DoVi / DV)",
        "REMUX" to "REMUX", "WEB-DL" to "WEB-DL", "WEBDL" to "WEB-DL", "WEBRIP" to "WEBRip", "BLURAY" to "BluRay / BDRip / BRRip", "BDRIP" to "BluRay / BDRip / BRRip", "BRRIP" to "BluRay / BDRip / BRRip", "HDRIP" to "HDRip", "HDTV" to "HDTV", "DVDRIP" to "DVDRip", "VODRIP" to "VODRip", "DVDSCR" to "DVDScr / SCR", "WORKPRINT" to "WP (Workprint)", "TELECINE" to "TC (Telecine)", "TELESYNC" to "TS (Telesync)", "HDCAM" to "HDCAM / CAM", "CAM" to "HDCAM / CAM",
        "DIRECTOR'S CUT" to "DIRECTOR'S CUT (DC)", "DIRECTORS CUT" to "DIRECTOR'S CUT (DC)", "EXTENDED" to "EXTENDED", "UNRATED" to "UNRATED", "REMASTERED" to "REMASTERED", "OPEN MATTE" to "OPEN MATTE", "PROPER" to "PROPER", "REPACK" to "REPACK", "IMAX" to "IMAX Enhanced",
        "ATMOS" to "Dolby Atmos", "TRUEHD" to "Dolby TrueHD", "E-AC3" to "DDP / E-AC3 (Dolby Digital Plus)", "EAC3" to "DDP / E-AC3 (Dolby Digital Plus)", "AC3" to "AC3 (Dolby Digital 5.1)", "DTS:X" to "DTS:X", "DTS-HD" to "DTS-HD MA (Master Audio)", "DTS" to "DTS", "AAC" to "AAC (2.0 / 5.1)", "FLAC" to "FLAC", "DUAL AUDIO" to "Dual Audio / Multi-Audio", "MULTI-AUDIO" to "Dual Audio / Multi-Audio",
        "120FPS" to "120fps / 144fps / 240fps", "144FPS" to "120fps / 144fps / 240fps", "240FPS" to "120fps / 144fps / 240fps", "60FPS" to "60fps", "30FPS" to "30fps", "24FPS" to "24fps", "HFR" to "HFR (High Frame Rate)", "VFR" to "VFR (Variable Frame Rate)", "ESUB" to "ESub (Embedded Subtitles)", "HC-SUB" to "HC-SUB (Hardcoded Subtitles)", "DUBBED" to "Dubbed", "SUBBED" to "Subbed", "3D SBS" to "3D SBS (Side-by-Side)", "3D OU" to "3D OU (Over-Under)", "VR180" to "VR 180", "VR360" to "VR 360", "8K" to "8K", "5K" to "5K", "2160P" to "UHD / 4K (Ultra HD - 2160p)", "1440P" to "QHD / 2K (Quad HD - 1440p)", "1080P" to "FHD (Full HD - 1080p)", "720P" to "HD (High Definition - 720p)", "480P" to "SD (Standard Definition - 480p)", "HEVC" to "H.265 / HEVC / x265", "H265" to "H.265 / HEVC / x265", "H264" to "H.264 / AVC / x264", "AV1" to "AV1", "VP9" to "VP9", "VP8" to "VP8", "XVID" to "Xvid", "DIVX" to "DivX", "PRORES" to "Apple ProRes"
    )
    return pairs.filter { s.contains(it.first) }.map { it.second }.distinct()
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
        setContent { MaterialTheme { UniversalTVPlayerApp() } }
    }
}

@Composable
private fun UniversalTVPlayerApp() {
    val context = LocalContext.current
    val activity = context as? Activity
    val libVlc = remember { LibVLC(context, arrayListOf("--http-reconnect", "--network-caching=1000", "--audio-time-stretch")) }
    val mediaPlayer = remember { MediaPlayer(libVlc) }
    var url by remember { mutableStateOf("") }
    var status by remember { mutableStateOf("Ready") }
    var playing by remember { mutableStateOf(false) }
    var showInfo by remember { mutableStateOf(false) }
    var showCapabilities by remember { mutableStateOf(false) }
    var speed by remember { mutableFloatStateOf(1f) }
    var info by remember { mutableStateOf("No media loaded") }
    var videoLayout by remember { mutableStateOf<VLCVideoLayout?>(null) }
    val focus = remember { FocusRequester() }

    DisposableEffect(mediaPlayer) {
        val listener = MediaPlayer.EventListener { event ->
            when (event.type) {
                MediaPlayer.Event.Opening -> status = "Opening…"
                MediaPlayer.Event.Buffering -> status = "Buffering… ${event.buffering.toInt()}%"
                MediaPlayer.Event.Playing -> { status = "Playing"; playing = true }
                MediaPlayer.Event.Paused -> { status = "Paused"; playing = false }
                MediaPlayer.Event.Stopped -> { status = "Stopped"; playing = false }
                MediaPlayer.Event.EndReached -> { status = "Ended"; playing = false }
                MediaPlayer.Event.EncounteredError -> { status = "Playback error"; playing = false }
            }
        }
        mediaPlayer.setEventListener(listener)
        onDispose {
            try { mediaPlayer.stop(); mediaPlayer.detachViews(); mediaPlayer.release() } catch (_: Exception) {}
            libVlc.release()
        }
    }

    fun play() {
        val clean = url.trim()
        if (clean.isEmpty()) { status = "Enter a URL"; return }
        try {
            mediaPlayer.stop()
            val media = Media(libVlc, Uri.parse(clean))
            media.setHWDecoderEnabled(true, false)
            media.addOption(":network-caching=1000")
            media.addOption(":http-reconnect")
            mediaPlayer.setMedia(media)
            media.release()
            mediaPlayer.play()
            val tags = detectedTags(clean)
            info = buildString {
                append("Engine: LibVLC / VLC 3.7\n")
                append("URL: ").append(clean).append("\n")
                if (tags.isNotEmpty()) append("Detected tags: ").append(tags.joinToString(", ")).append("\n")
                append("Hardware decoder: requested\n")
                append("Engine is designed for broad container/codec/stream support; final HDR/bit-depth/resolution output still depends on the Android TV SoC/display.")
            }
        } catch (e: Exception) {
            status = "Load error: ${e.message ?: "unknown"}"
        }
    }

    Box(Modifier.fillMaxSize().background(Color(0xFF080808))) {
        if (playing || mediaPlayer.isPlaying || videoLayout != null) {
            AndroidView(
                modifier = Modifier.fillMaxSize(),
                factory = { ctx -> VLCVideoLayout(ctx).also { layout -> videoLayout = layout; mediaPlayer.attachViews(layout, null, true, false); if (!mediaPlayer.isPlaying) mediaPlayer.play() } },
                update = { videoLayout = it }
            )
            Row(Modifier.align(Alignment.TopEnd).padding(24.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Button(onClick = { showInfo = !showInfo }, colors = ButtonDefaults.buttonColors(containerColor = Color(0xCC202020))) { Text("INFO") }
                Button(onClick = { showCapabilities = true }, colors = ButtonDefaults.buttonColors(containerColor = Color(0xCC202020))) { Text("V4 SUPPORT") }
                Button(onClick = { mediaPlayer.pause() }, colors = ButtonDefaults.buttonColors(containerColor = Color(0xCC202020))) { Text("PAUSE") }
                Button(onClick = { mediaPlayer.stop(); playing = false; status = "Ready" }, colors = ButtonDefaults.buttonColors(containerColor = Color(0xCC202020))) { Text("STOP") }
            }
            if (showInfo) InfoPanel(info, status, Modifier.align(Alignment.BottomStart))
        } else {
            Column(Modifier.fillMaxSize().padding(horizontal = 64.dp), verticalArrangement = Arrangement.Center) {
                Text("Universal TV Player V4", color = Color.White, fontSize = 38.sp)
                Text("Broad-format engine: LibVLC + Android hardware decoding", color = Color.Gray, fontSize = 18.sp)
                Spacer(Modifier.height(28.dp))
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    BasicTextField(value = url, onValueChange = { url = it }, singleLine = true,
                        modifier = Modifier.weight(1f).height(62.dp).background(Color(0xFF202020), RoundedCornerShape(10.dp)).border(2.dp, Color(0xFF444444), RoundedCornerShape(10.dp)).padding(horizontal = 18.dp, vertical = 19.dp).focusRequester(focus).focusable(),
                        textStyle = TextStyle(color = Color.White, fontSize = 18.sp), decorationBox = { inner ->
                            if (url.isEmpty()) Text("Paste video/audio URL or local media URI", color = Color.Gray, fontSize = 18.sp); inner()
                        })
                    Spacer(Modifier.width(16.dp)); Button(onClick = { play() }, Modifier.height(62.dp)) { Text("PLAY", fontSize = 18.sp) }
                }
                Spacer(Modifier.height(22.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    Button(onClick = { speed = when (speed) { 1f -> 1.25f; 1.25f -> 1.5f; 1.5f -> 2f; else -> 1f }; mediaPlayer.rate = speed }) { Text("Speed ${speed}x") }
                    Button(onClick = { showInfo = !showInfo }) { Text("Stream Info") }
                    Button(onClick = { showCapabilities = true }) { Text("V4 Support List") }
                }
                Spacer(Modifier.height(14.dp))
                Text("MKV • MP4 • AVI • MOV • WebM • TS/M2TS • FLV • WMV • HLS • DASH • RTSP and more", color = Color.Gray, fontSize = 15.sp)
                Text("V4 uses LibVLC as the broad-format playback engine and requests hardware decoding. HDR/DV/8K/10-bit/12-bit/pass-through are ultimately limited by the Android TV chipset, decoder and display.", color = Color.Gray, fontSize = 14.sp)
                LaunchedEffect(Unit) { focus.requestFocus() }
            }
        }
        if (showCapabilities) CapabilityPanel { showCapabilities = false }
    }
}

@Composable private fun InfoPanel(info: String, status: String, modifier: Modifier = Modifier) {
    Column(modifier.padding(28.dp).background(Color(0xEE151515), RoundedCornerShape(14.dp)).padding(18.dp)) {
        Text("Stream information", color = Color.White, fontSize = 20.sp)
        Spacer(Modifier.height(8.dp)); Text(info, color = Color.LightGray, fontSize = 15.sp)
        Spacer(Modifier.height(8.dp)); Text("Status: $status", color = Color.LightGray, fontSize = 15.sp)
    }
}

@Composable private fun CapabilityPanel(onClose: () -> Unit) {
    Box(Modifier.fillMaxSize().background(Color(0xF5080808)).padding(30.dp)) {
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(end = 8.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Text("Universal TV Player V4 — Full Capability Catalogue", color = Color.White, fontSize = 26.sp)
                Button(onClick = onClose) { Text("CLOSE") }
            }
            Spacer(Modifier.height(14.dp))
            Text("Playback engine: LibVLC. These are the requested capabilities the engine targets; actual output is constrained by the device decoder, Android version and connected display.", color = Color.LightGray, fontSize = 14.sp)
            capabilityCategories.forEach { category ->
                Text(category.title, color = Color.White, fontSize = 20.sp, modifier = Modifier.padding(top = 18.dp, bottom = 8.dp))
                category.items.forEach { Text("✓ $it", color = Color.LightGray, fontSize = 14.sp, modifier = Modifier.padding(vertical = 2.dp)) }
            }
            Spacer(Modifier.height(30.dp)); Button(onClick = onClose) { Text("DONE") }
        }
    }
}
