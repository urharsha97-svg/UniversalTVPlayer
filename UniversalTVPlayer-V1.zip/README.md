# Universal TV Player

TV-first Android video/audio streaming player starter project.

## Current V1

- Android TV / Google TV launcher
- Remote/D-pad friendly UI
- Direct URL playback
- Progressive HTTP playback
- HLS (.m3u8)
- DASH (.mpd)
- Media3 / ExoPlayer engine
- Basic buffering indicator
- GitHub Actions APK build

## Important

Codec, HDR, Dolby Vision, audio and resolution support ultimately depend on the Android TV device, OS and available hardware/software decoders.

## Build without Android Studio

Push this repository to GitHub. The workflow in `.github/workflows/build.yml` builds a debug APK automatically.

GitHub:
Actions → Build Android TV APK → Run workflow

The generated APK appears under the workflow run's Artifacts.
