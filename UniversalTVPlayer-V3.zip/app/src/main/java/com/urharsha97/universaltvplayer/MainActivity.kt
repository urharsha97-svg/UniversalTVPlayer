package com.urharsha97.universaltvplayer

import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { UniversalTVPlayerV3() }
    }
}

@Composable
fun UniversalTVPlayerV3() {
    val context = LocalContext.current
    var url by remember { mutableStateOf("") }
    var playing by remember { mutableStateOf(false) }
    var buffering by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var speed by remember { mutableFloatStateOf(1f) }
    var showInfo by remember { mutableStateOf(false) }
    var zoom by remember { mutableFloatStateOf(1f) }

    val player = remember {
        ExoPlayer.Builder(context)
            .setSeekBackIncrementMs(10_000)
            .setSeekForwardIncrementMs(10_000)
            .build()
    }

    DisposableEffect(player) {
        val listener = object : Player.Listener {
            override fun onIsPlayingChanged(isPlaying: Boolean) { playing = isPlaying }
            override fun onPlaybackStateChanged(state: Int) {
                buffering = state == Player.STATE_BUFFERING
            }
            override fun onPlayerError(e: PlaybackException) {
                error = e.errorCodeName
            }
        }
        player.addListener(listener)
        onDispose { player.removeListener(listener); player.release() }
    }

    fun playUrl() {
        val clean = url.trim()
        if (clean.isEmpty()) return
        error = null
        val item = MediaItem.Builder().setUri(Uri.parse(clean)).build()
        player.setMediaItem(item)
        player.prepare()
        player.playWhenReady = true
    }

    Surface(Modifier.fillMaxSize(), color = Color.Black) {
        Column(Modifier.fillMaxSize()) {
            Box(Modifier.weight(1f).fillMaxWidth().background(Color.Black)) {
                AndroidView(
                    modifier = Modifier.fillMaxSize(),
                    factory = { PlayerView(it).apply {
                        useController = true
                        player = this@run { player }
                        keepScreenOn = true
                    }},
                    update = { it.player = player }
                )
                if (buffering) {
                    CircularProgressIndicator(
                        modifier = Modifier.align(Alignment.Center),
                        color = Color.White
                    )
                }
                if (showInfo) {
                    InfoPanel(player, onClose = { showInfo = false })
                }
            }

            Column(
                Modifier.fillMaxWidth()
                    .background(Color(0xFF101010))
                    .padding(14.dp)
                    .verticalScroll(rememberScrollState())
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        "UNIVERSAL TV PLAYER  •  V3",
                        color = Color.White,
                        style = MaterialTheme.typography.titleMedium
                    )
                    Spacer(Modifier.weight(1f))
                    TextButton(onClick = { showInfo = true }) { Text("INFO") }
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    OutlinedTextField(
                        value = url,
                        onValueChange = { url = it },
                        modifier = Modifier.weight(1f),
                        singleLine = true,
                        label = { Text("Video / audio URL") }
                    )
                    Spacer(Modifier.width(10.dp))
                    Button(onClick = { playUrl() }) { Text("PLAY") }
                }

                if (error != null) {
                    Text("Playback error: $error", color = Color.White, modifier = Modifier.padding(top = 8.dp))
                }

                Row(
                    Modifier.fillMaxWidth().padding(top = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    TextButton(onClick = { player.seekBack() }) { Text("−10s") }
                    TextButton(onClick = {
                        if (playing) player.pause() else player.play()
                    }) { Text(if (playing) "PAUSE" else "PLAY") }
                    TextButton(onClick = { player.seekForward() }) { Text("+10s") }
                    TextButton(onClick = {
                        speed = when (speed) {
                            1f -> 1.25f
                            1.25f -> 1.5f
                            1.5f -> 2f
                            else -> 1f
                        }
                        player.setPlaybackSpeed(speed)
                    }) { Text("${speed}x") }
                    TextButton(onClick = {
                        zoom = if (zoom >= 1.5f) 1f else zoom + 0.25f
                    }) { Text("ZOOM ${zoom}x") }
                    TextButton(onClick = {
                        player.stop()
                        player.clearMediaItems()
                    }) { Text("STOP") }
                }
            }
        }
    }
}

@Composable
private fun InfoPanel(player: ExoPlayer, onClose: () -> Unit) {
    val format = player.videoFormat
    val audio = player.audioFormat
    Box(
        Modifier.fillMaxSize().background(Color(0xEE000000)).padding(30.dp)
    ) {
        Column(Modifier.fillMaxWidth().verticalScroll(rememberScrollState())) {
            Text("STREAM INFO", color = Color.White, style = MaterialTheme.typography.headlineSmall)
            Spacer(Modifier.height(16.dp))
            Text("Video: ${format?.sampleMimeType ?: "Unknown"}", color = Color.White)
            Text("Resolution: ${format?.width ?: 0} × ${format?.height ?: 0}", color = Color.White)
            Text("FPS: ${format?.frameRate ?: 0f}", color = Color.White)
            Text("Bitrate: ${format?.bitrate ?: 0} bps", color = Color.White)
            Text("Audio: ${audio?.sampleMimeType ?: "Unknown"}", color = Color.White)
            Text("Channels: ${audio?.channelCount ?: 0}", color = Color.White)
            Text("Sample rate: ${audio?.sampleRate ?: 0} Hz", color = Color.White)
            Spacer(Modifier.height(20.dp))
            Text("HDR / Dolby Vision support depends on the Android TV device and display pipeline.", color = Color.White)
            Spacer(Modifier.height(12.dp))
            Button(onClick = onClose) { Text("CLOSE") }
        }
    }
}
