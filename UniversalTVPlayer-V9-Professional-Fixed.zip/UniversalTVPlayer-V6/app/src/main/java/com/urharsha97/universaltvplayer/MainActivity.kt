package com.urharsha97.universaltvplayer

import android.content.Context
import android.content.Intent
import android.media.AudioManager
import android.media.MediaPlayer as AndroidMediaPlayer
import android.net.Uri
import android.os.Bundle
import android.view.SurfaceHolder
import android.view.SurfaceView
import android.view.View
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.focusable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.key.KeyEventType
import androidx.compose.ui.input.key.onPreviewKeyEvent
import androidx.compose.ui.input.key.type
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import org.json.JSONArray
import org.json.JSONObject
import org.videolan.libvlc.LibVLC
import org.videolan.libvlc.Media
import org.videolan.libvlc.MediaPlayer
import java.util.Locale

private enum class Engine(val label: String, val description: String) {
    LIBVLC("LibVLC", "Best overall format and stream compatibility"),
    MEDIA3("Media3", "Modern Android streaming engine"),
    ANDROID("System", "Android native fallback")
}

private data class HistoryItem(val title: String, val url: String, val position: Long, val duration: Long, val engine: Engine)
private data class Detected(val container: String, val video: String, val audio: String, val hdr: String, val resolution: String, val tags: List<String>)

private val Bg = Color(0xFF07090D)
private val Panel = Color(0xFF11151C)
private val Panel2 = Color(0xFF171D26)
private val Border = Color(0xFF303A49)
private val Muted = Color(0xFFA8B2C0)
private val Accent = Color(0xFF2F80ED)
private val Focus = Color(0xFFFFC107)

private class Prefs(context: Context) {
    private val p = context.getSharedPreferences("utvp_v9", Context.MODE_PRIVATE)
    var engine: Engine get() = runCatching { Engine.valueOf(p.getString("engine", Engine.LIBVLC.name)!!) }.getOrDefault(Engine.LIBVLC); set(v) { p.edit().putString("engine", v.name).apply() }
    var autoPlay: Boolean get() = p.getBoolean("autoplay", true); set(v) { p.edit().putBoolean("autoplay", v).apply() }
    var rememberPosition: Boolean get() = p.getBoolean("resume", true); set(v) { p.edit().putBoolean("resume", v).apply() }
    var bufferMs: Int get() = p.getInt("buffer", 1500); set(v) { p.edit().putInt("buffer", v).apply() }
    var hwDecoder: String get() = p.getString("hw", "any") ?: "any"; set(v) { p.edit().putString("hw", v).apply() }
    var dropLateFrames: Boolean get() = p.getBoolean("drop_late", true); set(v) { p.edit().putBoolean("drop_late", v).apply() }
    var skipFrames: Boolean get() = p.getBoolean("skip_frames", true); set(v) { p.edit().putBoolean("skip_frames", v).apply() }
    var deinterlace: Boolean get() = p.getBoolean("deinterlace", false); set(v) { p.edit().putBoolean("deinterlace", v).apply() }
    var audioPassthrough: Boolean get() = p.getBoolean("passthrough", false); set(v) { p.edit().putBoolean("passthrough", v).apply() }
    var aspect: String get() = p.getString("aspect", "Fit") ?: "Fit"; set(v) { p.edit().putString("aspect", v).apply() }
    var history: MutableList<HistoryItem>
        get() {
            val out = mutableListOf<HistoryItem>()
            val a = runCatching { JSONArray(p.getString("history", "[]")) }.getOrElse { JSONArray() }
            for (i in 0 until a.length()) {
                val o = a.optJSONObject(i) ?: continue
                val e = runCatching { Engine.valueOf(o.optString("engine", Engine.LIBVLC.name)) }.getOrDefault(Engine.LIBVLC)
                out += HistoryItem(o.optString("title"), o.optString("url"), o.optLong("position"), o.optLong("duration"), e)
            }
            return out
        }
        set(value) {
            val a = JSONArray()
            value.take(30).forEach { h -> a.put(JSONObject().apply { put("title", h.title); put("url", h.url); put("position", h.position); put("duration", h.duration); put("engine", h.engine.name) }) }
            p.edit().putString("history", a.toString()).apply()
        }
}

class MainActivity : ComponentActivity() {
    private val openDocument = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        uri?.let { setResult(RESULT_OK, Intent().setData(it)) }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
        setContent { MaterialTheme { UniversalTVPlayer(openDocument, intent?.data) } }
    }
}

@Composable
private fun UniversalTVPlayer(openDocument: ActivityResultLauncher<Array<String>>, initialUri: Uri?) {
    val context = LocalContext.current
    val prefs = remember { Prefs(context) }
    var engine by remember { mutableStateOf(prefs.engine) }
    var screen by remember { mutableStateOf("home") }
    var url by remember { mutableStateOf("") }
    var playingUrl by remember { mutableStateOf<String?>(null) }
    var title by remember { mutableStateOf("") }
    var playing by remember { mutableStateOf(false) }
    var controls by remember { mutableStateOf(true) }
    var info by remember { mutableStateOf(false) }
    var settings by remember { mutableStateOf(false) }
    var speed by remember { mutableFloatStateOf(1f) }
    var position by remember { mutableLongStateOf(0L) }
    var duration by remember { mutableLongStateOf(0L) }
    var status by remember { mutableStateOf("Ready") }
    var error by remember { mutableStateOf("") }
    var detected by remember { mutableStateOf<Detected?>(null) }
    var history by remember { mutableStateOf(prefs.history) }
    var initialHandled by remember { mutableStateOf(false) }
    var firstBackDone by remember { mutableStateOf(false) }

    val libVlc = remember {
        val opts = arrayListOf("--audio-time-stretch", "--network-caching=${prefs.bufferMs}", "--file-caching=${prefs.bufferMs}", "--avcodec-hw=${prefs.hwDecoder}", "--http-reconnect")
        if (prefs.dropLateFrames) opts += "--drop-late-frames"
        if (prefs.skipFrames) opts += "--skip-frames"
        if (prefs.deinterlace) { opts += "--deinterlace=1"; opts += "--deinterlace-mode=auto" }
        if (prefs.audioPassthrough) opts += "--spdif"
        LibVLC(context, opts)
    }
    val vlcPlayer = remember { MediaPlayer(libVlc) }
    val exoPlayer = remember { ExoPlayer.Builder(context).build() }
    val androidPlayer = remember { AndroidMediaPlayer() }

    fun pos(e: Engine = engine): Long = when (e) {
        Engine.LIBVLC -> runCatching { vlcPlayer.time }.getOrDefault(0L)
        Engine.MEDIA3 -> exoPlayer.currentPosition
        Engine.ANDROID -> runCatching { androidPlayer.currentPosition.toLong() }.getOrDefault(0L)
    }
    fun dur(e: Engine = engine): Long = when (e) {
        Engine.LIBVLC -> runCatching { vlcPlayer.length }.getOrDefault(0L)
        Engine.MEDIA3 -> exoPlayer.duration.takeIf { it > 0 } ?: 0L
        Engine.ANDROID -> runCatching { androidPlayer.duration.toLong() }.getOrDefault(0L)
    }
    fun saveHistory() {
        val u = playingUrl ?: return
        if (u.isBlank()) return
        val p = pos()
        val d = dur()
        if (d > 0 && p >= d - 3000) {
            prefs.history = prefs.history.filterNot { it.url == u }.toMutableList(); history = prefs.history; return
        }
        val list = prefs.history.filterNot { it.url == u }.toMutableList()
        list.add(0, HistoryItem(title.ifBlank { "Media" }, u, p.coerceAtLeast(0), d.coerceAtLeast(0), engine))
        prefs.history = list; history = list
    }
    fun stopAll() {
        saveHistory()
        runCatching { vlcPlayer.stop() }; runCatching { exoPlayer.stop() }; runCatching { androidPlayer.stop() }
        playing = false
    }
    fun startMedia(target: String, resume: Long = 0L, requestedEngine: Engine = engine) {
        val clean = target.trim()
        if (clean.isBlank()) { error = "Enter a URL or open a file."; return }
        stopAll(); error = ""; firstBackDone = false
        engine = requestedEngine; prefs.engine = requestedEngine
        url = clean; playingUrl = clean
        title = clean.substringAfterLast('/').substringBefore('?').ifBlank { "Network Media" }
        detected = detect(clean); status = "Opening…"; position = resume
        when (requestedEngine) {
            Engine.LIBVLC -> runCatching {
                val media = Media(libVlc, Uri.parse(clean))
                media.setHWDecoderEnabled(true, false)
                media.addOption(":network-caching=${prefs.bufferMs}")
                media.addOption(":file-caching=${prefs.bufferMs}")
                media.addOption(":http-reconnect=true")
                media.addOption(":avcodec-hw=${prefs.hwDecoder}")
                if (prefs.dropLateFrames) media.addOption(":drop-late-frames")
                if (prefs.skipFrames) media.addOption(":skip-frames")
                if (prefs.deinterlace) media.addOption(":deinterlace=1")
                if (prefs.audioPassthrough) media.addOption(":spdif")
                vlcPlayer.setMedia(media); media.release()
            }.onFailure { error = it.message ?: "LibVLC could not open this media." }
            Engine.MEDIA3 -> { exoPlayer.setMediaItem(MediaItem.fromUri(Uri.parse(clean))); exoPlayer.prepare(); exoPlayer.seekTo(resume); exoPlayer.setPlaybackSpeed(speed); if (prefs.autoPlay) exoPlayer.play() }
            Engine.ANDROID -> runCatching {
                androidPlayer.reset(); androidPlayer.setAudioStreamType(AudioManager.STREAM_MUSIC); androidPlayer.setDataSource(context, Uri.parse(clean))
                androidPlayer.setOnPreparedListener { mp -> duration = mp.duration.toLong(); if (resume > 0) mp.seekTo(resume.toInt()); if (prefs.autoPlay) mp.start(); playing = prefs.autoPlay; status = if (prefs.autoPlay) "Playing" else "Ready" }
                androidPlayer.setOnCompletionListener { playing = false; status = "Ended"; saveHistory() }
                androidPlayer.setOnErrorListener { _, what, extra -> error = "System player error $what/$extra"; status = "Playback error"; true }
                androidPlayer.prepareAsync()
            }.onFailure { error = it.message ?: "System player could not open this media." }
        }
        screen = "player"; controls = true
    }

    DisposableEffect(Unit) {
        val listener = MediaPlayer.EventListener { event ->
            when (event.type) {
                MediaPlayer.Event.Opening -> status = "Opening…"
                MediaPlayer.Event.Buffering -> status = "Buffering ${event.getBuffering().toInt()}%"
                MediaPlayer.Event.Playing -> { playing = true; status = "Playing" }
                MediaPlayer.Event.Paused -> { playing = false; status = "Paused" }
                MediaPlayer.Event.Stopped -> { playing = false; status = "Stopped" }
                MediaPlayer.Event.EndReached -> { playing = false; status = "Ended"; saveHistory() }
                MediaPlayer.Event.EncounteredError -> { playing = false; status = "Playback error"; error = "LibVLC could not decode/open this media." }
            }
        }
        vlcPlayer.setEventListener(listener)
        onDispose { runCatching { saveHistory() }; runCatching { vlcPlayer.stop(); vlcPlayer.vlcVout.detachViews(); vlcPlayer.release(); libVlc.release() }; runCatching { exoPlayer.release() }; runCatching { androidPlayer.release() } }
    }

    LaunchedEffect(screen, playing, playingUrl) {
        while (screen == "player") {
            position = pos(); duration = dur()
            if (playing) saveHistory()
            kotlinx.coroutines.delay(1000)
        }
    }
    LaunchedEffect(initialUri) {
        if (!initialHandled && initialUri != null) {
            initialHandled = true
            runCatching { context.contentResolver.takePersistableUriPermission(initialUri, Intent.FLAG_GRANT_READ_URI_PERMISSION) }
            startMedia(initialUri.toString())
        }
    }

    if (screen == "player") {
        BackHandler {
            when {
                info -> info = false
                settings -> settings = false
                !firstBackDone -> { firstBackDone = true; controls = false }
                else -> { saveHistory(); stopAll(); screen = "home"; firstBackDone = false }
            }
        }
        PlayerScreen(
            engine, title, status, playing, controls, info, speed, position, duration, detected, error, playingUrl ?: "", vlcPlayer, exoPlayer, androidPlayer,
            onToggleControls = { controls = !controls; firstBackDone = false },
            onPlayPause = { when (engine) { Engine.LIBVLC -> if (playing) vlcPlayer.pause() else vlcPlayer.play(); Engine.MEDIA3 -> if (exoPlayer.isPlaying) exoPlayer.pause() else exoPlayer.play(); Engine.ANDROID -> if (androidPlayer.isPlaying) androidPlayer.pause() else androidPlayer.start() } },
            onSeek = { delta -> val p = (pos() + delta).coerceAtLeast(0); when (engine) { Engine.LIBVLC -> vlcPlayer.time = p; Engine.MEDIA3 -> exoPlayer.seekTo(p); Engine.ANDROID -> androidPlayer.seekTo(p.toInt()) } },
            onSeekTo = { p -> when (engine) { Engine.LIBVLC -> vlcPlayer.time = p; Engine.MEDIA3 -> exoPlayer.seekTo(p); Engine.ANDROID -> androidPlayer.seekTo(p.toInt()) } },
            onSpeed = { speed = when (speed) { 0.25f -> .5f; .5f -> .75f; .75f -> 1f; 1f -> 1.25f; 1.25f -> 1.5f; 1.5f -> 2f; 2f -> 3f; 3f -> 4f; else -> .25f }; runCatching { vlcPlayer.rate = speed }; runCatching { exoPlayer.setPlaybackSpeed(speed) }; runCatching { androidPlayer.playbackParams = androidPlayer.playbackParams.setSpeed(speed) } },
            onInfo = { info = !info }, onStop = { stopAll(); screen = "home" }, onHome = { saveHistory(); stopAll(); screen = "home" }, onSettings = { settings = true; controls = true },
            onAudio = { cycleAudio(vlcPlayer) }, onSub = { cycleSub(vlcPlayer) }, onVolume = { delta -> runCatching { vlcPlayer.volume = (vlcPlayer.volume + delta).coerceIn(0, 200) } }
        )
        if (settings) SettingsDialog(prefs, engine, onEngine = { engine = it; prefs.engine = it }, onClose = { settings = false })
        return
    }
    if (screen == "settings") { SettingsScreen(prefs, engine, onEngine = { engine = it; prefs.engine = it }, onBack = { screen = "home" }); return }

    HomeScreen(url, history, engine, onUrl = { url = it }, onPlay = { startMedia(url) }, onHistory = { h -> startMedia(h.url, if (prefs.rememberPosition) h.position else 0L, h.engine) }, onSettings = { screen = "settings" }, onOpenFile = { openDocument.launch(arrayOf("video/*", "audio/*", "application/octet-stream")) }, onClearHistory = { prefs.history = mutableListOf(); history = mutableListOf() })
}

@Composable
private fun HomeScreen(url: String, history: List<HistoryItem>, engine: Engine, onUrl: (String) -> Unit, onPlay: () -> Unit, onHistory: (HistoryItem) -> Unit, onSettings: () -> Unit, onOpenFile: () -> Unit, onClearHistory: () -> Unit) {
    Column(Modifier.fillMaxSize().background(Bg).padding(42.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) { Text("UNIVERSAL TV PLAYER", color = Color.White, fontSize = 32.sp, fontWeight = FontWeight.Bold); Text("Android TV • Professional VLC-style player", color = Muted, fontSize = 15.sp) }
            TVButton("⚙  SETTINGS", onSettings)
        }
        Spacer(Modifier.height(26.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.weight(1f).height(58.dp).background(Panel2, RoundedCornerShape(10.dp)).border(2.dp, Border, RoundedCornerShape(10.dp)).padding(horizontal = 18.dp), Alignment.CenterStart) {
                androidx.compose.foundation.text.BasicTextField(value = url, onValueChange = onUrl, singleLine = true, textStyle = androidx.compose.ui.text.TextStyle(color = Color.White, fontSize = 18.sp), modifier = Modifier.fillMaxWidth())
                if (url.isBlank()) Text("Enter media URL • HLS / DASH / RTSP / HTTP / HTTPS", color = Color(0xFF727D8D), fontSize = 17.sp)
            }
            TVButton("▶  PLAY", onPlay, true)
            TVButton("📁  OPEN", onOpenFile)
        }
        Spacer(Modifier.height(18.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("ENGINE  ", color = Muted, fontSize = 13.sp, fontWeight = FontWeight.Bold)
            Text(engine.label, color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.width(20.dp)); Text("•", color = Muted); Spacer(Modifier.width(20.dp)); Text("Local files + network streams + resume history", color = Muted, fontSize = 14.sp)
        }
        Spacer(Modifier.height(28.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("CONTINUE WATCHING", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            if (history.isNotEmpty()) TVButton("CLEAR HISTORY", onClearHistory)
        }
        Spacer(Modifier.height(12.dp))
        if (history.isEmpty()) Text("No history yet. Your playback position will appear here automatically.", color = Muted, fontSize = 16.sp)
        else LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(history.take(10)) { h ->
                val pct = if (h.duration > 0) ((h.position * 100) / h.duration).coerceIn(0, 100) else 0
                Row(Modifier.fillMaxWidth().height(82.dp).background(Panel, RoundedCornerShape(10.dp)).border(1.dp, Border, RoundedCornerShape(10.dp)).clickable { onHistory(h) }.padding(horizontal = 18.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) { Text(h.title, color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis); Text("${h.engine.label}  •  ${formatTime(h.position)} / ${formatTime(h.duration)}", color = Muted, fontSize = 13.sp); Spacer(Modifier.height(6.dp)); LinearProgressIndicator(progress = pct / 100f, modifier = Modifier.fillMaxWidth().height(4.dp)) }
                    Spacer(Modifier.width(20.dp)); Text("$pct%", color = Accent, fontWeight = FontWeight.Bold); Spacer(Modifier.width(20.dp)); TVButton("▶ RESUME", onClick = { onHistory(h) }, primary = true)
                }
            }
        }
    }
}

@Composable
private fun PlayerScreen(engine: Engine, title: String, status: String, playing: Boolean, controls: Boolean, info: Boolean, speed: Float, position: Long, duration: Long, detected: Detected?, error: String, mediaKey: String, vlc: MediaPlayer, exo: ExoPlayer, android: AndroidMediaPlayer, onToggleControls: () -> Unit, onPlayPause: () -> Unit, onSeek: (Long) -> Unit, onSeekTo: (Long) -> Unit, onSpeed: () -> Unit, onInfo: () -> Unit, onStop: () -> Unit, onHome: () -> Unit, onSettings: () -> Unit, onAudio: () -> Unit, onSub: () -> Unit, onVolume: (Int) -> Unit) {
    val playFocus = remember { FocusRequester() }
    LaunchedEffect(controls) { if (controls) { runCatching { playFocus.requestFocus() }; kotlinx.coroutines.delay(8000); onToggleControls() } }
    Box(Modifier.fillMaxSize().background(Color.Black).onPreviewKeyEvent { e ->
        if (e.type == KeyEventType.KeyDown && !controls) { onToggleControls(); true } else false
    }.clickable { onToggleControls() }) {
        when (engine) { Engine.LIBVLC -> VLCVideoSurface(vlc, mediaKey); Engine.MEDIA3 -> AndroidView(factory = { ctx -> PlayerView(ctx).apply { player = exo; useController = false; setShutterBackgroundColor(android.graphics.Color.BLACK) } }, modifier = Modifier.fillMaxSize(), update = { it.player = exo }); Engine.ANDROID -> AndroidMediaSurface(android) }
        if (controls) {
            Column(Modifier.fillMaxSize()) {
                Row(Modifier.fillMaxWidth().background(Color(0xCC080B10)).padding(horizontal = 26.dp, vertical = 16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) { Text(title, color = Color.White, fontSize = 21.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis); Text("${engine.label}  •  $status", color = Muted, fontSize = 13.sp) }
                    TVButton("ℹ INFO", onInfo); Spacer(Modifier.width(8.dp)); TVButton("⚙", onSettings)
                }
                Spacer(Modifier.weight(1f))
                if (error.isNotBlank()) Text(error, color = Color(0xFFFFC8C2), modifier = Modifier.padding(horizontal = 28.dp).background(Color(0xEE45130F), RoundedCornerShape(8.dp)).padding(12.dp))
                Column(Modifier.fillMaxWidth().background(Color(0xF20A0D12)).padding(horizontal = 24.dp, vertical = 12.dp)) {
                    if (duration > 0) Slider(value = position.coerceIn(0, duration).toFloat(), onValueChange = { onSeekTo(it.toLong()) }, valueRange = 0f..duration.toFloat(), modifier = Modifier.fillMaxWidth())
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) { Text(formatTime(position), color = Color.White, fontSize = 14.sp); Spacer(Modifier.weight(1f)); Text(formatTime(duration), color = Color.White, fontSize = 14.sp) }
                    Spacer(Modifier.height(8.dp))
                    Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                        TVButton("⏮ 60", { onSeek(-60000) }); TVButton("⏮ 30", { onSeek(-30000) }); TVButton("◀ 10", { onSeek(-10000) }); TVButton("◀ 5", { onSeek(-5000) })
                        TVButton(if (playing) "⏸  PAUSE" else "▶  PLAY", onPlayPause, true, playFocus)
                        TVButton("5 ▶", { onSeek(5000) }); TVButton("10 ▶", { onSeek(10000) }); TVButton("30 ⏭", { onSeek(30000) }); TVButton("60 ⏭", { onSeek(60000) }); TVButton("${speed}x", onSpeed); TVButton("AUDIO", onAudio); TVButton("SUB", onSub); TVButton("VOL−", { onVolume(-10) }); TVButton("VOL+", { onVolume(10) }); TVButton("■ STOP", onStop); TVButton("⌂ HOME", onHome)
                    }
                    Spacer(Modifier.height(4.dp)); Text("OK/ENTER: select   •   BACK: first hides controls, second returns home   •   ←/→: seek", color = Color(0xFF7F8A9A), fontSize = 11.sp)
                }
            }
        }
        if (info && detected != null) InfoOverlay(detected, engine, status)
    }
}

@Composable
private fun VLCVideoSurface(player: MediaPlayer, mediaKey: String) {
    AndroidView(factory = { ctx ->
        SurfaceView(ctx).apply {
            setBackgroundColor(android.graphics.Color.BLACK)
            holder.addCallback(object : SurfaceHolder.Callback {
                override fun surfaceCreated(holder: SurfaceHolder) { runCatching { player.vlcVout.setVideoView(this@apply); player.vlcVout.attachViews(); player.play() } }
                override fun surfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) { runCatching { player.vlcVout.setVideoView(this@apply); player.vlcVout.attachViews(); if (!player.isPlaying) player.play() } }
                override fun surfaceDestroyed(holder: SurfaceHolder) { runCatching { player.vlcVout.detachViews() } }
            })
        }
    }, modifier = Modifier.fillMaxSize(), update = { view -> runCatching { player.vlcVout.setVideoView(view); player.vlcVout.attachViews(); player.play() } })
    LaunchedEffect(mediaKey) { kotlinx.coroutines.delay(250); runCatching { player.vlcVout.attachViews(); player.play() } }
}

@Composable
private fun AndroidMediaSurface(player: AndroidMediaPlayer) {
    AndroidView(factory = { ctx -> SurfaceView(ctx).apply { holder.addCallback(object : SurfaceHolder.Callback { override fun surfaceCreated(holder: SurfaceHolder) { runCatching { player.setDisplay(holder) } }; override fun surfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) {}; override fun surfaceDestroyed(holder: SurfaceHolder) {} }) } }, modifier = Modifier.fillMaxSize(), update = {})
}

@Composable
private fun InfoOverlay(d: Detected, engine: Engine, status: String) {
    Box(Modifier.fillMaxSize().background(Color(0x99000000))) {
        Column(Modifier.align(Alignment.CenterEnd).width(470.dp).padding(24.dp).background(Color(0xF5141921), RoundedCornerShape(14.dp)).border(2.dp, Accent, RoundedCornerShape(14.dp)).padding(22.dp)) {
            Text("PLAYBACK INFORMATION", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold); Spacer(Modifier.height(12.dp)); Text("Engine   ${engine.label}", color = Color.White); Text("Status   $status", color = Muted); Text("Container ${d.container}", color = Muted); Text("Video    ${d.video}", color = Muted); Text("Audio    ${d.audio}", color = Muted); Text("HDR      ${d.hdr}", color = Muted); Text("Quality  ${d.resolution}", color = Muted); if (d.tags.isNotEmpty()) Text("Tags     ${d.tags.joinToString(" • ")}", color = Muted)
        }
    }
}

@Composable
private fun SettingsDialog(prefs: Prefs, selected: Engine, onEngine: (Engine) -> Unit, onClose: () -> Unit) {
    Box(Modifier.fillMaxSize().background(Color(0xD9000000)), Alignment.Center) {
        Column(Modifier.width(720.dp).background(Panel, RoundedCornerShape(16.dp)).border(2.dp, Border, RoundedCornerShape(16.dp)).padding(26.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) { Text("PLAYER SETTINGS", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f)); TVButton("CLOSE", onClose) }
            Spacer(Modifier.height(14.dp)); Text("Playback engine", color = Muted, fontSize = 13.sp, fontWeight = FontWeight.Bold)
            Engine.values().forEach { e -> SettingChoice(e.label, e.description, selected == e) { onEngine(e) } }
            Spacer(Modifier.height(10.dp)); Text("Buffer ${prefs.bufferMs} ms  •  Resume ${if (prefs.rememberPosition) "ON" else "OFF"}  •  Auto-play ${if (prefs.autoPlay) "ON" else "OFF"}", color = Muted)
        }
    }
}

@Composable
private fun SettingsScreen(prefs: Prefs, selected: Engine, onEngine: (Engine) -> Unit, onBack: () -> Unit) {
    Column(Modifier.fillMaxSize().background(Bg).padding(42.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) { Text("SETTINGS", color = Color.White, fontSize = 32.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f)); TVButton("← BACK", onBack) }
        Spacer(Modifier.height(20.dp)); Text("PLAYBACK ENGINE", color = Muted, fontSize = 13.sp, fontWeight = FontWeight.Bold); Spacer(Modifier.height(8.dp)); Engine.values().forEach { e -> SettingChoice(e.label, e.description, selected == e) { onEngine(e) } }
        Spacer(Modifier.height(18.dp)); Text("PLAYBACK", color = Muted, fontSize = 13.sp, fontWeight = FontWeight.Bold); SettingToggle("Auto play on open", prefs.autoPlay) { prefs.autoPlay = it }; SettingToggle("Remember / resume position", prefs.rememberPosition) { prefs.rememberPosition = it }
        Spacer(Modifier.height(14.dp)); Text("NETWORK BUFFER: ${prefs.bufferMs} ms", color = Color.White); Slider(value = prefs.bufferMs.toFloat(), onValueChange = { prefs.bufferMs = it.toInt() }, valueRange = 250f..5000f, steps = 18)
        Spacer(Modifier.height(14.dp)); Text("DECODER", color = Muted, fontSize = 13.sp, fontWeight = FontWeight.Bold); SettingChoice("Hardware decoder: AUTO", "Recommended for Android TV", prefs.hwDecoder == "any") { prefs.hwDecoder = "any" }; SettingChoice("Software decoder", "Use when hardware output glitches", prefs.hwDecoder == "none") { prefs.hwDecoder = "none" }; SettingToggle("Drop late frames", prefs.dropLateFrames) { prefs.dropLateFrames = it }; SettingToggle("Skip frames", prefs.skipFrames) { prefs.skipFrames = it }; SettingToggle("Deinterlace", prefs.deinterlace) { prefs.deinterlace = it }
        Spacer(Modifier.height(14.dp)); Text("VIDEO", color = Muted, fontSize = 13.sp, fontWeight = FontWeight.Bold); Text("Aspect ratio: ${prefs.aspect}", color = Color.White); Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { listOf("Fit", "16:9", "4:3", "Fill", "Original").forEach { a -> TVButton(a, { prefs.aspect = a }, prefs.aspect == a) } }
        Spacer(Modifier.height(14.dp)); Text("AUDIO", color = Muted, fontSize = 13.sp, fontWeight = FontWeight.Bold); SettingToggle("HDMI / SPDIF passthrough", prefs.audioPassthrough) { prefs.audioPassthrough = it }; Text("LibVLC multi-audio, subtitle, equalizer and passthrough controls are available when the active TV/device path exposes them.", color = Muted, fontSize = 13.sp)
    }
}

@Composable
private fun SettingChoice(title: String, description: String, selected: Boolean, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp).background(if (selected) Color(0xFF17345D) else Panel2, RoundedCornerShape(10.dp)).border(2.dp, if (selected) Accent else Border, RoundedCornerShape(10.dp)).clickable { onClick() }.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(if (selected) "●" else "○", color = if (selected) Accent else Color(0xFF718096), fontSize = 22.sp); Spacer(Modifier.width(12.dp)); Column { Text(title, color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.Bold); Text(description, color = Muted, fontSize = 13.sp) }
    }
}

@Composable
private fun SettingToggle(title: String, enabled: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp).background(Panel2, RoundedCornerShape(10.dp)).border(1.dp, Border, RoundedCornerShape(10.dp)).clickable { onChange(!enabled) }.padding(14.dp), verticalAlignment = Alignment.CenterVertically) { Text(title, color = Color.White, fontSize = 16.sp, modifier = Modifier.weight(1f)); Text(if (enabled) "ON" else "OFF", color = if (enabled) Accent else Muted, fontWeight = FontWeight.Bold) }
}

@Composable
private fun TVButton(text: String, onClick: () -> Unit, primary: Boolean = false, requester: FocusRequester? = null) {
    var focused by remember { mutableStateOf(false) }
    val mod = Modifier.onFocusChanged { focused = it.isFocused }.focusable().then(if (requester != null) Modifier.focusRequester(requester) else Modifier)
    Button(onClick = onClick, modifier = mod, colors = ButtonDefaults.buttonColors(containerColor = if (primary) Accent else if (focused) Color(0xFF39475A) else Color(0xFF252C36), contentColor = Color.White), border = if (focused) androidx.compose.foundation.BorderStroke(2.dp, Focus) else null, shape = RoundedCornerShape(8.dp), contentPadding = PaddingValues(horizontal = 16.dp, vertical = 10.dp)) { Text(text, fontWeight = if (focused || primary) FontWeight.Bold else FontWeight.Medium, fontSize = 13.sp) }
}

private fun cycleAudio(player: MediaPlayer) { runCatching { val tracks = player.audioTracks ?: return; if (tracks.size < 2) return; val current = player.audioTrack; val ids = tracks.map { it.id }; val idx = ids.indexOf(current); player.setAudioTrack(ids[(idx + 1).mod(ids.size)]) } }
private fun cycleSub(player: MediaPlayer) { runCatching { val tracks = player.spuTracks ?: return; if (tracks.size < 2) return; val current = player.spuTrack; val ids = tracks.map { it.id }; val idx = ids.indexOf(current); player.setSpuTrack(ids[(idx + 1).mod(ids.size)]) } }

private fun formatTime(ms: Long): String { if (ms <= 0) return "00:00"; val total = ms / 1000; val h = total / 3600; val m = (total % 3600) / 60; val s = total % 60; return if (h > 0) String.format(Locale.US, "%d:%02d:%02d", h, m, s) else String.format(Locale.US, "%02d:%02d", m, s) }

private fun detect(raw: String): Detected {
    val s = raw.lowercase(Locale.US); fun has(vararg x: String) = x.any { s.contains(it) }
    val container = when { has(".mkv") -> "MKV"; has(".mp4") -> "MP4"; has(".avi") -> "AVI"; has(".mov") -> "MOV"; has(".webm") -> "WebM"; has(".m2ts") -> "M2TS"; has(".ts") -> "MPEG-TS"; has(".flv") -> "FLV"; has(".wmv") -> "WMV"; has(".m3u8") -> "HLS"; has(".mpd") -> "DASH"; has("rtsp:") -> "RTSP"; else -> "Auto" }
    val video = when { has("h.266", "h266", "vvc") -> "H.266 / VVC"; has("h.265", "h265", "hevc", "x265") -> "H.265 / HEVC"; has("h.264", "h264", "avc", "x264") -> "H.264 / AVC"; has("av1") -> "AV1"; has("vp9") -> "VP9"; has("vp8") -> "VP8"; has("prores") -> "ProRes"; has("vc-1", "vc1") -> "VC-1"; else -> "Auto-detect" }
    val audio = when { has("truehd") -> "Dolby TrueHD"; has("atmos") -> "Dolby Atmos"; has("dts:x", "dtsx") -> "DTS:X"; has("dts-hd", "dtshd") -> "DTS-HD MA"; has("eac3", "ddp") -> "E-AC3 / DDP"; has("ac3") -> "AC3"; has("flac") -> "FLAC"; has("opus") -> "Opus"; has("aac") -> "AAC"; has("mp3") -> "MP3"; else -> "Auto-detect" }
    val hdr = when { has("dolby vision", "dovi") -> "Dolby Vision"; has("hdr10+") -> "HDR10+"; has("hdr10") -> "HDR10"; has("hlg") -> "HLG"; has("hdr") -> "HDR"; else -> "SDR / Unknown" }
    val resolution = when { has("16k") -> "16K"; has("8k") -> "8K"; has("2160p", "4k") -> "4K / 2160p"; has("1440p", "2k") -> "QHD / 1440p"; has("1080p") -> "FHD / 1080p"; has("720p") -> "HD / 720p"; has("480p") -> "SD / 480p"; else -> "Auto" }
    val tags = buildList { if (has("remux")) add("REMUX"); if (has("web-dl")) add("WEB-DL"); if (has("webrip")) add("WEBRip"); if (has("bluray", "blu-ray")) add("BluRay"); if (has("director's cut", "directors cut")) add("Director's Cut"); if (has("extended")) add("Extended"); if (has("unrated")) add("Unrated"); if (has("remastered")) add("Remastered"); if (has("dual audio", "dual-audio")) add("Dual Audio"); if (has("5.1")) add("5.1"); if (has("7.1")) add("7.1"); if (has("10bit", "10-bit")) add("10-bit"); if (has("12bit", "12-bit")) add("12-bit") }
    return Detected(container, video, audio, hdr, resolution, tags)
}
