# Clean Rewrite Feature Matrix

| Area | Implementation |
|---|---|
| Outer UI | Original Compose TV/mobile hub |
| Inner UI | Lightweight, original player overlay inspired by the requested interaction model |
| Media engine | Media3 ExoPlayer 1.11.0 |
| LibVLC | Removed completely |
| HLS/DASH/SS/RTSP | Included Media3 modules |
| Local video/audio | Android document picker |
| HTTP/HTTPS | OkHttp DataSource |
| Redirects | Enabled |
| UA / Referer | Configurable in PlayerController |
| Cache | 256 MB LRU disk cache |
| Target buffer | 128 MB load-control target |
| D-pad seek | ±10s |
| Media skip keys | ±30s |
| Back | Hide controls → exit player |
| Audio selection | Media3 TrackSelectionOverride |
| Subtitle selection | Media3 text track selection |
| External SRT/ASS/SSA/VTT | Add during playback |
| HDR | Hardware/device dependent passthrough |
| Tone mapping | Uses platform/Media3 capability where supported; no fake universal guarantee |
| FFmpeg | Official Media3 native extension build script |
| System chooser | VIEW + SEND intent filters, app label + icon |
