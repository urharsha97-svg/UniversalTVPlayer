package com.universaltvplayer.app

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.KeyEvent
import android.view.SurfaceView
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.focusable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.scale
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.input.key.KeyEventType
import androidx.compose.ui.input.key.key
import androidx.compose.ui.input.key.onPreviewKeyEvent
import androidx.compose.ui.input.key.type
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.C
import kotlinx.coroutines.delay
import java.util.Locale

class MainActivity : ComponentActivity() {
    private lateinit var controller: PlayerController

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        controller = (application as UniversalTvApplication).player
        setContent {
            MaterialTheme(colorScheme = darkColorScheme()) {
                UniversalTvPlayerRoot(controller = controller)
            }
        }
        handleIntent(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIntent(intent)
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        if (controller.player.currentMediaItem != null) {
            when (keyCode) {
                KeyEvent.KEYCODE_MEDIA_SKIP_FORWARD -> { controller.seekBy(30_000); return true }
                KeyEvent.KEYCODE_MEDIA_SKIP_BACKWARD -> { controller.seekBy(-30_000); return true }
                KeyEvent.KEYCODE_MEDIA_FAST_FORWARD -> { controller.seekBy(10_000); return true }
                KeyEvent.KEYCODE_MEDIA_REWIND -> { controller.seekBy(-10_000); return true }
            }
        }
        return super.onKeyDown(keyCode, event)
    }

    private fun handleIntent(intent: Intent?) {
        val uri = intent?.data ?: intent?.getParcelableExtra(Intent.EXTRA_STREAM, Uri::class.java)
        uri?.let {
            try { contentResolver.takePersistableUriPermission(it, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}
            controller.play(it)
        }
    }
}

@Composable
private fun UniversalTvPlayerRoot(controller: PlayerController) {
    var showPlayer by remember { mutableStateOf(controller.player.currentMediaItem != null) }
    var playing by remember { mutableStateOf(controller.player.isPlaying) }

    LaunchedEffect(Unit) {
        while (true) {
            showPlayer = controller.player.currentMediaItem != null
            playing = controller.player.isPlaying
            delay(150)
        }
    }

    if (showPlayer && controller.player.currentMediaItem != null) {
        PlayerScreen(controller, playing) {
            controller.player.pause()
            controller.player.clearMediaItems()
            showPlayer = false
        }
    } else {
        PremiumHub { uri -> controller.play(uri); showPlayer = true }
    }
}

private data class HubItem(val title: String, val subtitle: String, val icon: String)

@Composable
private fun PremiumHub(onOpen: (Uri) -> Unit) {
    val context = LocalContext.current
    var url by remember { mutableStateOf("") }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { it?.let(onOpen) }
    val items = remember {
        listOf(
            HubItem("Local Library", "USB • Downloads • Files", "▶"),
            HubItem("Network Stream", "HTTP • HTTPS • HLS • DASH", "◎"),
            HubItem("Audio Library", "AAC • FLAC • DTS • Lossless", "♫"),
            HubItem("Recent Playback", "Resume where you left off", "↺"),
            HubItem("Subtitle Center", "SRT • ASS • SSA • VTT", "CC"),
            HubItem("Playback Lab", "Tracks • aspect • diagnostics", "◇")
        )
    }

    Box(
        Modifier.fillMaxSize().background(
            Brush.radialGradient(listOf(Color(0xFF17213A), Color(0xFF080A10), Color.Black))
        )
    ) {
        Column(Modifier.fillMaxSize().padding(horizontal = 42.dp, vertical = 30.dp)) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("UI REWRITE 11.2", color = Color(0xFF8998C7), fontSize = 12.sp, letterSpacing = 4.sp)
                    Spacer(Modifier.height(4.dp))
                    Text("UNIVERSAL", color = Color(0xFF8998C7), fontSize = 12.sp, letterSpacing = 5.sp)
                    Text("TV PLAYER", color = Color.White, fontSize = 34.sp, letterSpacing = 1.sp)
                    Text("A focused media hub for TV and mobile", color = Color(0xFF858EA3), fontSize = 13.sp)
                }
                Surface(
                    shape = RoundedCornerShape(20.dp),
                    color = Color.White.copy(alpha = .06f),
                    border = BorderStroke(1.dp, Color.White.copy(alpha = .10f))
                ) { Text("MEDIA3 ENGINE", Modifier.padding(horizontal = 18.dp, vertical = 11.dp), color = Color(0xFFDCE3FF), fontSize = 11.sp) }
            }
            Spacer(Modifier.height(28.dp))
            Text("OPEN MEDIA", color = Color.White, fontSize = 18.sp)
            Spacer(Modifier.height(12.dp))
            LazyVerticalGrid(
                columns = GridCells.Adaptive(minSize = 230.dp),
                horizontalArrangement = Arrangement.spacedBy(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp),
                modifier = Modifier.weight(1f)
            ) {
                items(items) { item ->
                    HubCard(item) {
                        when (item.title) {
                            "Local Library", "Audio Library", "Subtitle Center" -> picker.launch(arrayOf("video/*", "audio/*", "text/*", "application/x-subrip"))
                            "Network Stream" -> Unit
                            else -> Unit
                        }
                    }
                }
            }
            Spacer(Modifier.height(14.dp))
            Surface(
                Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(22.dp),
                color = Color.Black.copy(alpha = .34f),
                border = BorderStroke(1.dp, Color.White.copy(alpha = .09f))
            ) {
                Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    BasicTextField(
                        value = url,
                        onValueChange = { url = it },
                        modifier = Modifier.weight(1f).padding(horizontal = 12.dp, vertical = 10.dp),
                        textStyle = TextStyle(color = Color.White, fontSize = 14.sp),
                        singleLine = true,
                        decorationBox = { inner -> if (url.isBlank()) Text("Paste an authorized stream URL…", color = Color(0xFF687188)); inner() }
                    )
                    Button(
                        onClick = { url.trim().takeIf { it.startsWith("http://") || it.startsWith("https://") }?.let { onOpen(Uri.parse(it)) } },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFD9E1FF), contentColor = Color.Black),
                        shape = RoundedCornerShape(14.dp)
                    ) { Text("PLAY", fontSize = 12.sp) }
                }
            }
        }
    }
}

@Composable
private fun HubCard(item: HubItem, onClick: () -> Unit) {
    var focused by remember { mutableStateOf(false) }
    val scale by animateFloatAsState(if (focused) 1.035f else 1f, label = "focus")
    Surface(
        Modifier.fillMaxWidth().height(150.dp).scale(scale).onFocusChanged { focused = it.isFocused }.focusable().onPreviewKeyEvent {
            if (it.type == KeyEventType.KeyDown && it.key == Key.Enter) { onClick(); true } else false
        }.clickable { onClick() },
        shape = RoundedCornerShape(24.dp),
        color = if (focused) Color(0xFF1A2340) else Color(0xFF101522),
        border = BorderStroke(if (focused) 2.dp else 1.dp, if (focused) Color(0xFF9FB2FF) else Color.White.copy(alpha = .08f))
    ) {
        Box(Modifier.fillMaxSize()) {
            Box(
                Modifier
                    .align(Alignment.CenterEnd)
                    .size(170.dp)
                    .blur(28.dp)
                    .background(
                        Brush.radialGradient(listOf(Color(0xFF556CFF).copy(alpha = .30f), Color.Transparent)),
                        RoundedCornerShape(50)
                    )
            )
            Row(Modifier.fillMaxSize().padding(20.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(54.dp).background(Color.White.copy(alpha = .07f), RoundedCornerShape(17.dp)), contentAlignment = Alignment.Center) {
                    Text(item.icon, color = Color(0xFFDCE4FF), fontSize = 20.sp)
                    }
                Spacer(Modifier.width(16.dp))
                Column {
                    Text(item.title, color = Color.White, fontSize = 18.sp)
                    Spacer(Modifier.height(6.dp))
                    Text(item.subtitle, color = Color(0xFF7E879B), fontSize = 12.sp)
                }
            }
        }
    }
}

private enum class OverlaySheet { Audio, Subtitle, Aspect, Settings }

@Composable
private fun PlayerScreen(controller: PlayerController, playing: Boolean, onExit: () -> Unit) {
    var controlsVisible by remember { mutableStateOf(true) }
    var sheet by remember { mutableStateOf<OverlaySheet?>(null) }
    var position by remember { mutableLongStateOf(controller.player.currentPosition) }
    var duration by remember { mutableLongStateOf(controller.player.duration) }
    var scrub by remember { mutableFloatStateOf(0f) }
    val rootFocus = remember { FocusRequester() }

    LaunchedEffect(Unit) { rootFocus.requestFocus() }
    LaunchedEffect(controlsVisible, playing) {
        if (controlsVisible && playing) { delay(4000); controlsVisible = false }
    }
    LaunchedEffect(Unit) {
        while (true) {
            position = controller.player.currentPosition
            duration = controller.player.duration
            if (duration > 0) scrub = position.toFloat() / duration.toFloat()
            delay(120)
        }
    }

    BackHandler {
        if (sheet != null) sheet = null
        else if (controlsVisible) controlsVisible = false
        else onExit()
    }

    Box(
        Modifier.fillMaxSize().background(Color.Black).focusRequester(rootFocus).focusable()
            .onPreviewKeyEvent { event ->
                if (event.type != KeyEventType.KeyDown) return@onPreviewKeyEvent false
                when (event.key) {
                    Key.DirectionLeft -> { controller.seekBy(-5_000); controlsVisible = true; true }
                    Key.DirectionRight -> { controller.seekBy(5_000); controlsVisible = true; true }
                    Key.MediaPlayPause, Key.Enter -> { controller.player.playWhenReady = !controller.player.playWhenReady; controlsVisible = true; true }
                    Key.Back -> { if (controlsVisible) controlsVisible = false else onExit(); true }
                    else -> false
                }
            }
    ) {
        AndroidView(
            Modifier.fillMaxSize(),
            factory = { ctx -> SurfaceView(ctx).also { it.setBackgroundColor(android.graphics.Color.BLACK); controller.player.setVideoSurfaceView(it) } },
            update = { controller.player.setVideoSurfaceView(it) }
        )

        if (controlsVisible) {
            Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color.Black.copy(.48f), Color.Transparent, Color.Black.copy(.82f)))))
            Column(Modifier.fillMaxSize().padding(horizontal = 28.dp, vertical = 24.dp), verticalArrangement = Arrangement.SpaceBetween) {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(controller.player.currentMediaItem?.localConfiguration?.uri?.lastPathSegment ?: "Playing", color = Color.White, fontSize = 19.sp)
                        Text("UI REWRITE 11.2  •  Media3  •  SurfaceView", color = Color(0xFF8E97AC), fontSize = 11.sp)
                    }
                    Text(if (playing) "PLAYING" else "PAUSED", color = Color(0xFFDDE4FF), fontSize = 10.sp)
                }

                Column(Modifier.fillMaxWidth()) {
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Text(formatTime(position), color = Color.White, fontSize = 12.sp)
                        Spacer(Modifier.width(10.dp))
                        Slider(
                            value = scrub,
                            onValueChange = { scrub = it; controller.seekToFraction(it) },
                            modifier = Modifier.weight(1f).height(34.dp),
                            thumb = { Box(Modifier.size(13.dp).background(Color.White, RoundedCornerShape(50))) },

                        )
                        Spacer(Modifier.width(10.dp))
                        Text(formatTime(duration), color = Color(0xFFCDD2DE), fontSize = 12.sp)
                    }
                    Spacer(Modifier.height(8.dp))
                    Surface(
                        Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(20.dp),
                        color = Color.Black.copy(alpha = .62f),
                        border = BorderStroke(1.dp, Color.White.copy(alpha = .10f))
                    ) {
                        Row(Modifier.fillMaxWidth().padding(10.dp), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                            ControlButton("−30") { controller.seekBy(-30_000) }
                            ControlButton("−10") { controller.seekBy(-10_000) }
                            ControlButton(if (playing) "❚❚" else "▶") { controller.player.playWhenReady = !controller.player.playWhenReady }
                            ControlButton("+10") { controller.seekBy(10_000) }
                            ControlButton("+30") { controller.seekBy(30_000) }
                            Spacer(Modifier.width(4.dp))
                            ControlButton("AUDIO") { sheet = OverlaySheet.Audio }
                            ControlButton("SUB") { sheet = OverlaySheet.Subtitle }
                            ControlButton("ASPECT") { sheet = OverlaySheet.Aspect }
                            ControlButton("SETTINGS") { sheet = OverlaySheet.Settings }
                        }
                    }
                }
            }
        }
    }

    sheet?.let { TrackSheet(controller, it) { sheet = null } }
}

@Composable
private fun ControlButton(text: String, onClick: () -> Unit) {
    var focused by remember { mutableStateOf(false) }
    Surface(
        Modifier.height(42.dp).onFocusChanged { focused = it.isFocused }.focusable().onPreviewKeyEvent { e -> if (e.type == KeyEventType.KeyDown && e.key == Key.Enter) { onClick(); true } else false }.clickable { onClick() },
        shape = RoundedCornerShape(12.dp),
        color = if (focused) Color.White.copy(.20f) else Color.White.copy(.08f),
        border = BorderStroke(1.dp, Color.White.copy(if (focused) .32f else .10f))
    ) { Box(Modifier.padding(horizontal = 12.dp), contentAlignment = Alignment.Center) { Text(text, color = Color.White, fontSize = 10.sp) } }
}

@Composable
private fun TrackSheet(controller: PlayerController, kind: OverlaySheet, onDismiss: () -> Unit) {
    ModalBottomSheet(onDismissRequest = onDismiss, containerColor = Color(0xFF10131C)) {
        when (kind) {
            OverlaySheet.Audio -> TrackList(controller, C.TRACK_TYPE_AUDIO, "Audio Tracks", onDismiss)
            OverlaySheet.Subtitle -> TrackList(controller, C.TRACK_TYPE_TEXT, "Subtitle Tracks", onDismiss)
            OverlaySheet.Aspect -> OptionList("Aspect Ratio", listOf("Fit", "Fill", "16:9", "4:3", "21:9"), onDismiss)
            OverlaySheet.Settings -> OptionList("Playback Settings", listOf("Hardware decoder: automatic", "Buffer: adaptive", "Theme: AMOLED", "Headers: configured in engine"), onDismiss)
        }
    }
}

@Composable
private fun TrackList(controller: PlayerController, type: Int, title: String, onDismiss: () -> Unit) {
    val groups = controller.player.currentTracks.groups.filter { it.type == type }
    Column(Modifier.fillMaxWidth().padding(horizontal = 24.dp, vertical = 12.dp)) {
        Text(title, color = Color.White, fontSize = 22.sp)
        Spacer(Modifier.height(12.dp))
        if (groups.isEmpty()) Text("No tracks detected", color = Color(0xFF858EA2), modifier = Modifier.padding(bottom = 28.dp))
        groups.forEach { group ->
            for (i in 0 until group.length) {
                val f = group.getTrackFormat(i)
                val label = listOfNotNull(
                    f.label,
                    f.language?.let { Locale.forLanguageTag(it).getDisplayLanguage(Locale.getDefault()) },
                    f.sampleMimeType,
                    f.channelCount.takeIf { it > 0 }?.let { "${it}ch" }
                ).distinct().joinToString(" • ").ifBlank { "Track ${i + 1}" }
                TextButton(onClick = { controller.selectTrack(group, i); onDismiss() }, modifier = Modifier.fillMaxWidth()) { Text(label, color = Color.White, fontSize = 16.sp) }
            }
        }
        if (type == C.TRACK_TYPE_TEXT) TextButton(onClick = { controller.disableTextTracks(); onDismiss() }, modifier = Modifier.fillMaxWidth()) { Text("Subtitles Off", color = Color(0xFFFFB7B7)) }
        Spacer(Modifier.height(24.dp))
    }
}

@Composable
private fun OptionList(title: String, options: List<String>, onDismiss: () -> Unit) {
    Column(Modifier.fillMaxWidth().padding(24.dp)) {
        Text(title, color = Color.White, fontSize = 22.sp)
        Spacer(Modifier.height(10.dp))
        options.forEach { TextButton(onClick = onDismiss, modifier = Modifier.fillMaxWidth()) { Text(it, color = Color.White, fontSize = 16.sp) } }
        Spacer(Modifier.height(24.dp))
    }
}

private fun formatTime(ms: Long): String {
    if (ms < 0) return "00:00"
    val total = ms / 1000
    val h = total / 3600
    val m = (total % 3600) / 60
    val s = total % 60
    return if (h > 0) "%d:%02d:%02d".format(h, m, s) else "%02d:%02d".format(m, s)
}
