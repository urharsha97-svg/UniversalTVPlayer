package com.universaltvplayer

import android.app.Application

class UniversalTvApplication : Application()
