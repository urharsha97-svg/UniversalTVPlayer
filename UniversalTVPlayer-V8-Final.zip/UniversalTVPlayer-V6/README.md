# UniversalTVPlayer V6 — VLC-style Multi-Engine Android TV Player

V6 focuses on a real TV-player experience inspired by the feature set of VLC for Android, while keeping multiple playback engines.

## Engines
- LibVLC 3.7.5 — primary universal engine
- Media3 ExoPlayer — modern Android streaming fallback
- Android MediaPlayer — native fallback

## VLC-style features in the UI
- D-pad friendly player controls and high-contrast overlays
- Play/pause, stop, +/-10s and +/-30s seek
- Playback speed control
- Continue watching + resume history
- Player INFO / engine visibility
- Network buffer control
- Hardware/software decoder preference
- Drop late frames / skip frames
- Deinterlace preference
- Aspect ratio preference
- Audio passthrough preference
- Subtitle size and subtitle delay preferences
- Auto play / resume / statistics options
- File picker for local media
- HLS / DASH / RTSP URL playback
- Metadata/tag detection from filenames and URLs

## Storage optimization
The build is ABI-filtered for common Android TV ARM devices (arm64-v8a and armeabi-v7a), avoiding unused x86 native libraries. GitHub Actions publishes ABI-specific APKs instead of a large universal APK.

Actual codec/HDR/10-bit/12-bit and passthrough support still depends on the Android TV hardware, firmware, display and selected engine. VLC itself supports hardware decoding and broad media formats; libVLC is the core VLC engine. See VideoLAN documentation.
