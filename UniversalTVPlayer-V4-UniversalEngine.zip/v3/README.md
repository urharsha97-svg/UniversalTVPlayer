# Universal TV Player V3

TV-first Android streaming player.

V3 includes:
- Android TV / Google TV launcher
- D-pad friendly UI
- Direct URL playback
- Progressive HTTP/HTTPS
- HLS (.m3u8)
- DASH (.mpd)
- Media3/ExoPlayer
- Buffering state
- Basic stream information
- Video/audio track discovery
- Playback speed control
- Fullscreen PlayerView controls
- GitHub Actions APK build

Compatibility note:
Actual codec, HDR10/HDR10+/HLG/Dolby Vision, audio and resolution support depends on the TV's Android version, hardware decoder, software decoder availability and display pipeline.


V3 build fixes:
- Android cleartext HTTP playback enabled for legacy IPTV/HTTP streams
- Version bumped to 0.3.0 (versionCode 3)
- GitHub Actions artifact renamed to UniversalTVPlayer-V3-APK
- CI performs a Gradle project verification step before assembling the APK
