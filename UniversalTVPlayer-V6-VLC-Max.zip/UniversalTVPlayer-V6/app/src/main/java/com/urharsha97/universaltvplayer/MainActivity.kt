package com.urharsha97.universaltvplayer

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.media.AudioManager
import android.media.MediaPlayer as AndroidMediaPlayer
import android.net.Uri
import android.os.Bundle
import android.view.SurfaceHolder
import android.view.SurfaceView
import android.view.View
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.focusable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import org.json.JSONArray
import org.json.JSONObject
import org.videolan.libvlc.LibVLC
import org.videolan.libvlc.Media
import org.videolan.libvlc.MediaPlayer
import java.util.Locale

private enum class Engine(val label: String, val description: String) {
    LIBVLC("LibVLC 3.7.5", "Maximum format/protocol coverage"),
    MEDIA3("Media3 ExoPlayer", "Modern Android TV streaming engine"),
    ANDROID("Android MediaPlayer", "System/native fallback engine")
}

private data class HistoryItem(val title: String, val url: String, val position: Long, val duration: Long, val engine: Engine)

private data class Detected(val container: String, val video: String, val audio: String, val hdr: String, val resolution: String, val tags: List<String>)

private class Prefs(context: Context) {
    private val p = context.getSharedPreferences("utvp_v6", Context.MODE_PRIVATE)
    var engine: Engine
        get() = runCatching { Engine.valueOf(p.getString("engine", Engine.LIBVLC.name)!!) }.getOrDefault(Engine.LIBVLC)
        set(v) { p.edit().putString("engine", v.name).apply() }
    var autoPlay: Boolean
        get() = p.getBoolean("autoplay", true)
        set(v) { p.edit().putBoolean("autoplay", v).apply() }
    var rememberPosition: Boolean
        get() = p.getBoolean("resume", true)
        set(v) { p.edit().putBoolean("resume", v).apply() }
    var bufferMs: Int
        get() = p.getInt("buffer", 1500)
        set(v) { p.edit().putInt("buffer", v).apply() }
    var showStats: Boolean
        get() = p.getBoolean("stats", true)
        set(v) { p.edit().putBoolean("stats", v).apply() }
    var hwDecoder: String
        get() = p.getString("hw", "any") ?: "any"
        set(v) { p.edit().putString("hw", v).apply() }
    var dropLateFrames: Boolean
        get() = p.getBoolean("drop_late", true)
        set(v) { p.edit().putBoolean("drop_late", v).apply() }
    var skipFrames: Boolean
        get() = p.getBoolean("skip_frames", true)
        set(v) { p.edit().putBoolean("skip_frames", v).apply() }
    var deinterlace: Boolean
        get() = p.getBoolean("deinterlace", false)
        set(v) { p.edit().putBoolean("deinterlace", v).apply() }
    var audioPassthrough: Boolean
        get() = p.getBoolean("passthrough", false)
        set(v) { p.edit().putBoolean("passthrough", v).apply() }
    var aspect: String
        get() = p.getString("aspect", "Fit") ?: "Fit"
        set(v) { p.edit().putString("aspect", v).apply() }
    var subtitleSize: Int
        get() = p.getInt("sub_size", 100)
        set(v) { p.edit().putInt("sub_size", v).apply() }
    var subtitleDelayMs: Int
        get() = p.getInt("sub_delay", 0)
        set(v) { p.edit().putInt("sub_delay", v).apply() }
    var history: MutableList<HistoryItem>
        get() {
            val out = mutableListOf<HistoryItem>()
            val a = runCatching { JSONArray(p.getString("history", "[]")) }.getOrElse { JSONArray() }
            for (i in 0 until a.length()) {
                val o = a.optJSONObject(i) ?: continue
                val e = runCatching { Engine.valueOf(o.optString("engine", Engine.LIBVLC.name)) }.getOrDefault(Engine.LIBVLC)
                out += HistoryItem(o.optString("title"), o.optString("url"), o.optLong("position"), o.optLong("duration"), e)
            }
            return out
        }
        set(value) {
            val a = JSONArray()
            value.take(30).forEach { h ->
                a.put(JSONObject().apply { put("title", h.title); put("url", h.url); put("position", h.position); put("duration", h.duration); put("engine", h.engine.name) })
            }
            p.edit().putString("history", a.toString()).apply()
        }
}

class MainActivity : ComponentActivity() {
    private val openDocument = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        uri?.let { setResult(RESULT_OK, Intent().setData(it)); contentUri = it }
    }
    private var contentUri: Uri? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
        setContent { MaterialTheme { UniversalTVPlayerV6(openDocument) } }
    }
}

@Composable
private fun UniversalTVPlayerV6(openDocument: androidx.activity.result.ActivityResultLauncher<Array<String>>) {
    val context = LocalContext.current
    val prefs = remember { Prefs(context) }
    var engine by remember { mutableStateOf(prefs.engine) }
    var screen by remember { mutableStateOf("home") }
    var url by remember { mutableStateOf("") }
    var playingUrl by remember { mutableStateOf<String?>(null) }
    var title by remember { mutableStateOf("") }
    var playing by remember { mutableStateOf(false) }
    var controls by remember { mutableStateOf(true) }
    var info by remember { mutableStateOf(false) }
    var settings by remember { mutableStateOf(false) }
    var speed by remember { mutableFloatStateOf(1f) }
    var position by remember { mutableLongStateOf(0L) }
    var duration by remember { mutableLongStateOf(0L) }
    var status by remember { mutableStateOf("Ready") }
    var error by remember { mutableStateOf("") }
    var detected by remember { mutableStateOf<Detected?>(null) }
    var history by remember { mutableStateOf(prefs.history) }

    val libVlc = remember {
        val opts = arrayListOf<String>()
        opts += "--audio-time-stretch"
        opts += "--network-caching=${prefs.bufferMs}"
        opts += "--file-caching=${prefs.bufferMs}"
        opts += "--avcodec-hw=${prefs.hwDecoder}"
        if (prefs.dropLateFrames) opts += "--drop-late-frames"
        if (prefs.skipFrames) opts += "--skip-frames"
        if (prefs.deinterlace) { opts += "--deinterlace=1"; opts += "--deinterlace-mode=auto" }
        if (prefs.audioPassthrough) opts += "--spdif"
        opts += "--http-reconnect"
        LibVLC(context, opts)
    }
    val vlcPlayer = remember { MediaPlayer(libVlc) }
    val exoPlayer = remember { ExoPlayer.Builder(context).build() }
    val androidPlayer = remember { AndroidMediaPlayer() }

    fun saveHistory() {
        val u = playingUrl ?: return
        if (u.isBlank()) return
        val list = prefs.history.filterNot { it.url == u }.toMutableList()
        list.add(0, HistoryItem(title.ifBlank { u.substringAfterLast('/').ifBlank { "Media" } }, u, position, duration, engine))
        prefs.history = list
        history = prefs.history
    }

    fun currentPosition(): Long = when (engine) {
        Engine.LIBVLC -> runCatching { vlcPlayer.time }.getOrDefault(0L)
        Engine.MEDIA3 -> exoPlayer.currentPosition
        Engine.ANDROID -> runCatching { androidPlayer.currentPosition.toLong() }.getOrDefault(0L)
    }
    fun currentDuration(): Long = when (engine) {
        Engine.LIBVLC -> runCatching { vlcPlayer.length }.getOrDefault(0L)
        Engine.MEDIA3 -> exoPlayer.duration.takeIf { it > 0 } ?: 0L
        Engine.ANDROID -> runCatching { androidPlayer.duration.toLong() }.getOrDefault(0L)
    }
    fun stopAll() {
        saveHistory()
        runCatching { vlcPlayer.stop() }
        runCatching { exoPlayer.stop() }
        runCatching { androidPlayer.stop() }
        playing = false
        status = "Stopped"
    }
    fun startMedia(target: String, resume: Long = 0L, requestedEngine: Engine = engine) {
        val clean = target.trim()
        if (clean.isBlank()) { error = "Enter a media URL"; return }
        stopAll()
        error = ""
        engine = requestedEngine
        prefs.engine = requestedEngine
        url = clean
        playingUrl = clean
        title = clean.substringAfterLast('/').substringBefore('?').ifBlank { "Network Media" }
        detected = detect(clean)
        status = "Opening…"
        position = resume
        when (requestedEngine) {
            Engine.LIBVLC -> {
                runCatching {
                    val media = Media(libVlc, Uri.parse(clean))
                    media.setHWDecoderEnabled(true, false)
                    media.addOption(":network-caching=${prefs.bufferMs}")
                    media.addOption(":file-caching=${prefs.bufferMs}")
                    media.addOption(":http-reconnect=true")
                    media.addOption(":avcodec-hw=${prefs.hwDecoder}")
                    if (prefs.dropLateFrames) media.addOption(":drop-late-frames")
                    if (prefs.skipFrames) media.addOption(":skip-frames")
                    if (prefs.deinterlace) media.addOption(":deinterlace=1")
                    if (prefs.audioPassthrough) media.addOption(":spdif")
                    vlcPlayer.setMedia(media)
                    media.release()
                    // Surface callback will start playback when the video surface is ready.
                }.onFailure { error = it.message ?: "LibVLC open failed" }
            }
            Engine.MEDIA3 -> {
                exoPlayer.setMediaItem(MediaItem.fromUri(Uri.parse(clean)))
                exoPlayer.prepare()
                exoPlayer.setPlaybackSpeed(speed)
                if (prefs.autoPlay) exoPlayer.play()
            }
            Engine.ANDROID -> {
                runCatching {
                    androidPlayer.reset()
                    androidPlayer.setAudioStreamType(AudioManager.STREAM_MUSIC)
                    androidPlayer.setDataSource(context, Uri.parse(clean))
                    androidPlayer.setOnPreparedListener { mp ->
                        duration = mp.duration.toLong()
                        if (resume > 0) mp.seekTo(resume.toInt())
                        if (prefs.autoPlay) mp.start()
                        status = "Playing"
                        playing = prefs.autoPlay
                    }
                    androidPlayer.setOnCompletionListener { playing = false; status = "Ended"; saveHistory() }
                    androidPlayer.setOnErrorListener { _, what, extra -> error = "Android MediaPlayer error $what/$extra"; status = "Playback error"; true }
                    androidPlayer.prepareAsync()
                }.onFailure { error = it.message ?: "Android MediaPlayer open failed" }
            }
        }
        screen = "player"
    }

    DisposableEffect(Unit) {
        val listener = MediaPlayer.EventListener { event ->
            when (event.type) {
                MediaPlayer.Event.Opening -> status = "Opening…"
                MediaPlayer.Event.Buffering -> status = "Buffering… ${event.getBuffering().toInt()}%"
                MediaPlayer.Event.Playing -> { playing = true; status = "Playing" }
                MediaPlayer.Event.Paused -> { playing = false; status = "Paused" }
                MediaPlayer.Event.Stopped -> { playing = false; status = "Stopped" }
                MediaPlayer.Event.EndReached -> { playing = false; status = "Ended"; saveHistory() }
                MediaPlayer.Event.EncounteredError -> { playing = false; status = "Playback error"; error = "LibVLC could not decode/open this media." }
            }
        }
        vlcPlayer.setEventListener(listener)
        onDispose {
            runCatching { saveHistory() }
            runCatching { vlcPlayer.stop(); vlcPlayer.vlcVout.detachViews(); vlcPlayer.release(); libVlc.release() }
            runCatching { exoPlayer.release() }
            runCatching { androidPlayer.release() }
        }
    }

    LaunchedEffect(screen, playing) {
        while (screen == "player") {
            position = currentPosition()
            duration = currentDuration()
            if (playing) saveHistory()
            kotlinx.coroutines.delay(1000)
        }
    }

    if (screen == "player") {
        PlayerScreen(
            engine = engine,
            title = title,
            status = status,
            playing = playing,
            controls = controls,
            info = info,
            speed = speed,
            position = position,
            duration = duration,
            detected = detected,
            error = error,
            vlcPlayer = vlcPlayer,
            exoPlayer = exoPlayer,
            androidPlayer = androidPlayer,
            onToggleControls = { controls = !controls },
            onPlayPause = {
                when (engine) {
                    Engine.LIBVLC -> if (playing) vlcPlayer.pause() else vlcPlayer.play()
                    Engine.MEDIA3 -> if (exoPlayer.isPlaying) exoPlayer.pause() else exoPlayer.play()
                    Engine.ANDROID -> if (androidPlayer.isPlaying) androidPlayer.pause() else androidPlayer.start()
                }
            },
            onSeek = { delta ->
                val p = (currentPosition() + delta).coerceAtLeast(0L)
                when (engine) {
                    Engine.LIBVLC -> vlcPlayer.time = p
                    Engine.MEDIA3 -> exoPlayer.seekTo(p)
                    Engine.ANDROID -> androidPlayer.seekTo(p.toInt())
                }
            },
            onSeekTo = { p ->
                when (engine) {
                    Engine.LIBVLC -> vlcPlayer.time = p
                    Engine.MEDIA3 -> exoPlayer.seekTo(p)
                    Engine.ANDROID -> androidPlayer.seekTo(p.toInt())
                }
            },
            onSpeed = {
                speed = when (speed) { 1f -> 1.25f; 1.25f -> 1.5f; 1.5f -> 2f; else -> 1f }
                runCatching { vlcPlayer.rate = speed }
                runCatching { exoPlayer.setPlaybackSpeed(speed) }
                runCatching { androidPlayer.playbackParams = androidPlayer.playbackParams.setSpeed(speed) }
            },
            onInfo = { info = !info },
            onStop = { stopAll(); screen = "home" },
            onHome = { saveHistory(); screen = "home" },
            onSettings = { settings = true }
        )
        if (settings) SettingsDialog(prefs, engine, onEngine = { engine = it; prefs.engine = it }, onClose = { settings = false })
        return
    }

    if (screen == "settings") {
        SettingsScreen(prefs, engine, onEngine = { engine = it; prefs.engine = it }, onBack = { screen = "home" })
        return
    }

    HomeScreen(
        url = url,
        history = history,
        engine = engine,
        onUrl = { url = it },
        onPlay = { startMedia(url) },
        onHistory = { h -> startMedia(h.url, if (prefs.rememberPosition) h.position else 0L, h.engine) },
        onSettings = { screen = "settings" },
        onOpenFile = { openDocument.launch(arrayOf("video/*", "audio/*", "application/octet-stream")) }
    )
}

@Composable
private fun HomeScreen(url: String, history: List<HistoryItem>, engine: Engine, onUrl: (String) -> Unit, onPlay: () -> Unit, onHistory: (HistoryItem) -> Unit, onSettings: () -> Unit, onOpenFile: () -> Unit) {
    Box(Modifier.fillMaxSize().background(Color(0xFF080A0F)).padding(48.dp)) {
        Column(Modifier.fillMaxSize()) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("UNIVERSAL TV PLAYER", color = Color.White, fontSize = 34.sp, fontWeight = FontWeight.Bold)
                    Text("V6 • VLC-style multi-engine TV player", color = Color(0xFF9AA4B2), fontSize = 16.sp)
                }
                TVButton("⚙ SETTINGS", onSettings)
            }
            Spacer(Modifier.height(28.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                TVButton("▶ PLAY URL", onPlay, true)
                TVButton("📁 OPEN FILE", onOpenFile)
                Text("Engine: ${engine.label}", color = Color(0xFFB8C1CC), modifier = Modifier.align(Alignment.CenterVertically))
            }
            Spacer(Modifier.height(18.dp))
            Box(Modifier.fillMaxWidth().height(66.dp).background(Color(0xFF171B22), RoundedCornerShape(12.dp)).border(2.dp, Color(0xFF394353), RoundedCornerShape(12.dp)).padding(horizontal = 20.dp), contentAlignment = Alignment.CenterStart) {
                androidx.compose.foundation.text.BasicTextField(value = url, onValueChange = onUrl, singleLine = true, textStyle = androidx.compose.ui.text.TextStyle(color = Color.White, fontSize = 19.sp), modifier = Modifier.fillMaxWidth())
                if (url.isBlank()) Text("Paste URL: MP4 / MKV / HLS / DASH / RTSP / stream…", color = Color(0xFF707A88), fontSize = 18.sp)
            }
            Spacer(Modifier.height(30.dp))
            Text("CONTINUE WATCHING", color = Color.White, fontSize = 21.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(12.dp))
            if (history.isEmpty()) {
                Text("No history yet. Play something and your resume position will appear here.", color = Color(0xFF7F8997), fontSize = 16.sp)
            } else {
                LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxHeight()) {
                    items(history.take(8)) { h ->
                        val pct = if (h.duration > 0) ((h.position * 100) / h.duration).coerceIn(0, 100) else 0
                        Row(Modifier.fillMaxWidth().height(72.dp).background(Color(0xFF141820), RoundedCornerShape(12.dp)).border(1.dp, Color(0xFF2A3240), RoundedCornerShape(12.dp)).clickable { onHistory(h) }.padding(horizontal = 18.dp), verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text(h.title, color = Color.White, fontSize = 18.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                Text("${h.engine.label} • ${formatTime(h.position)} / ${formatTime(h.duration)} • $pct%", color = Color(0xFF8E98A7), fontSize = 13.sp)
                            }
                            Text("▶ RESUME", color = Color.White, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun PlayerScreen(engine: Engine, title: String, status: String, playing: Boolean, controls: Boolean, info: Boolean, speed: Float, position: Long, duration: Long, detected: Detected?, error: String, vlcPlayer: MediaPlayer, exoPlayer: ExoPlayer, androidPlayer: AndroidMediaPlayer, onToggleControls: () -> Unit, onPlayPause: () -> Unit, onSeek: (Long) -> Unit, onSeekTo: (Long) -> Unit, onSpeed: () -> Unit, onInfo: () -> Unit, onStop: () -> Unit, onHome: () -> Unit, onSettings: () -> Unit) {
    var eqPreset by remember { mutableIntStateOf(0) }
    var eqName by remember { mutableStateOf("EQ: Off") }
    Box(Modifier.fillMaxSize().background(Color.Black).clickable { onToggleControls() }) {
        when (engine) {
            Engine.LIBVLC -> VLCVideoSurface(vlcPlayer)
            Engine.MEDIA3 -> AndroidView(modifier = Modifier.fillMaxSize(), factory = { PlayerView(it).apply { player = exoPlayer; useController = false; setShutterBackgroundColor(android.graphics.Color.BLACK) } }, update = { it.player = exoPlayer })
            Engine.ANDROID -> AndroidMediaSurface(androidPlayer)
        }
        if (controls) {
            Column(Modifier.fillMaxSize().padding(28.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(title, color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text("${engine.label} • $status", color = Color(0xFFBFC8D4), fontSize = 14.sp)
                    }
                    TVButton("ℹ INFO", onInfo)
                    TVButton("⚙", onSettings)
                }
                Spacer(Modifier.weight(1f))
                if (error.isNotBlank()) Text(error, color = Color(0xFFFFB4AB), fontSize = 16.sp, modifier = Modifier.background(Color(0xDD260D0B), RoundedCornerShape(8.dp)).padding(12.dp))
                Spacer(Modifier.height(12.dp))
                if (duration > 0) Slider(value = position.coerceIn(0, duration).toFloat(), onValueChange = { onSeekTo(it.toLong()) }, valueRange = 0f..duration.toFloat(), modifier = Modifier.fillMaxWidth())
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text(formatTime(position), color = Color.White, fontSize = 14.sp)
                    Text(formatTime(duration), color = Color.White, fontSize = 14.sp)
                }
                Spacer(Modifier.height(10.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
                    TVButton("⏮ -30s") { onSeek(-30_000) }
                    TVButton("◀ -10s") { onSeek(-10_000) }
                    TVButton(if (playing) "⏸ PAUSE" else "▶ PLAY", onPlayPause, true)
                    TVButton("+10s ▶") { onSeek(10_000) }
                    TVButton("+30s ⏭") { onSeek(30_000) }
                    TVButton("${speed}x") { onSpeed() }
                    if (engine == Engine.LIBVLC) {
                        TVButton("AUDIO") {
                            runCatching {
                                val tracks = vlcPlayer.getAudioTracks()?.filter { it.id >= 0 }.orEmpty()
                                if (tracks.isNotEmpty()) {
                                    val current = vlcPlayer.getAudioTrack()
                                    val idx = tracks.indexOfFirst { it.id == current }
                                    vlcPlayer.setAudioTrack(tracks[(idx + 1).mod(tracks.size)].id)
                                }
                            }
                        }
                        TVButton("SUB") {
                            runCatching {
                                val tracks = vlcPlayer.getSpuTracks()?.filter { it.id >= 0 }.orEmpty()
                                if (tracks.isNotEmpty()) {
                                    val current = vlcPlayer.getSpuTrack()
                                    val idx = tracks.indexOfFirst { it.id == current }
                                    vlcPlayer.setSpuTrack(tracks[(idx + 1).mod(tracks.size)].id)
                                }
                            }
                        }
                        TVButton(eqName) {
                            runCatching {
                                val count = MediaPlayer.Equalizer.getPresetCount()
                                if (count > 0) {
                                    if (eqPreset >= count) eqPreset = 0
                                    val next = eqPreset
                                    val eq = MediaPlayer.Equalizer.createFromPreset(next)
                                    vlcPlayer.setEqualizer(eq)
                                    eqName = "EQ: ${MediaPlayer.Equalizer.getPresetName(next)}"
                                    eqPreset = (next + 1) % count
                                }
                            }
                        }
                        TVButton("VOL-") { runCatching { vlcPlayer.setVolume((vlcPlayer.getVolume() - 10).coerceAtLeast(0)) } }
                        TVButton("VOL+") { runCatching { vlcPlayer.setVolume((vlcPlayer.getVolume() + 10).coerceAtMost(200)) } }
                    }
                    TVButton("■ STOP", onStop)
                    TVButton("⌂ HOME", onHome)
                }
            }
        }
        if (info && detected != null) InfoOverlay(detected, engine, status)
    }
}

@Composable
private fun VLCVideoSurface(player: MediaPlayer) {
    AndroidView(modifier = Modifier.fillMaxSize(), factory = { ctx ->
        SurfaceView(ctx).apply {
            setBackgroundColor(android.graphics.Color.BLACK)
            holder.addCallback(object : SurfaceHolder.Callback {
                override fun surfaceCreated(holder: SurfaceHolder) {
                    runCatching {
                        player.vlcVout.setVideoView(this@apply)
                        player.vlcVout.attachViews()
                        player.play()
                    }
                }
                override fun surfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) {}
                override fun surfaceDestroyed(holder: SurfaceHolder) { runCatching { player.vlcVout.detachViews() } }
            })
        }
    }, update = {})
}

@Composable
private fun AndroidMediaSurface(player: AndroidMediaPlayer) {
    AndroidView(modifier = Modifier.fillMaxSize(), factory = { ctx ->
        SurfaceView(ctx).apply { holder.addCallback(object : SurfaceHolder.Callback {
            override fun surfaceCreated(holder: SurfaceHolder) { runCatching { player.setDisplay(holder) } }
            override fun surfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) {}
            override fun surfaceDestroyed(holder: SurfaceHolder) {}
        }) }
    }, update = {})
}

@Composable
private fun InfoOverlay(d: Detected, engine: Engine, status: String) {
    Column(Modifier.align(Alignment.CenterEnd).width(430.dp).padding(24.dp).background(Color(0xF0151920), RoundedCornerShape(14.dp)).border(2.dp, Color(0xFF4D596B), RoundedCornerShape(14.dp)).padding(20.dp)) {
        Text("PLAYBACK INFORMATION", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(10.dp))
        Text("Engine: ${engine.label}", color = Color(0xFFDBE3ED))
        Text("Status: $status", color = Color(0xFFDBE3ED))
        Text("Container: ${d.container}", color = Color(0xFFDBE3ED))
        Text("Video: ${d.video}", color = Color(0xFFDBE3ED))
        Text("Resolution: ${d.resolution}", color = Color(0xFFDBE3ED))
        Text("HDR: ${d.hdr}", color = Color(0xFFDBE3ED))
        Text("Audio: ${d.audio}", color = Color(0xFFDBE3ED))
        if (d.tags.isNotEmpty()) Text("Tags: ${d.tags.joinToString(" • ")}", color = Color(0xFFDBE3ED))
    }
}

@Composable
private fun SettingsScreen(prefs: Prefs, selected: Engine, onEngine: (Engine) -> Unit, onBack: () -> Unit) {
    var engine by remember { mutableStateOf(selected) }
    var auto by remember { mutableStateOf(prefs.autoPlay) }
    var resume by remember { mutableStateOf(prefs.rememberPosition) }
    var stats by remember { mutableStateOf(prefs.showStats) }
    var buffer by remember { mutableIntStateOf(prefs.bufferMs) }
    var hw by remember { mutableStateOf(prefs.hwDecoder) }
    var drop by remember { mutableStateOf(prefs.dropLateFrames) }
    var skip by remember { mutableStateOf(prefs.skipFrames) }
    var deint by remember { mutableStateOf(prefs.deinterlace) }
    var pass by remember { mutableStateOf(prefs.audioPassthrough) }
    var aspect by remember { mutableStateOf(prefs.aspect) }
    var subSize by remember { mutableIntStateOf(prefs.subtitleSize) }
    var subDelay by remember { mutableIntStateOf(prefs.subtitleDelayMs) }
    Column(Modifier.fillMaxSize().background(Color(0xFF080A0F)).padding(48.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) { Text("SETTINGS", color = Color.White, fontSize = 34.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f)); TVButton("← BACK", onBack) }
        Spacer(Modifier.height(24.dp))
        Text("PLAYBACK ENGINE", color = Color(0xFF8FA0B3), fontSize = 14.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        Engine.values().forEach { e ->
            SettingChoice(e.label, e.description, engine == e) { engine = e; onEngine(e) }
        }
        Spacer(Modifier.height(20.dp))
        Text("PLAYBACK", color = Color(0xFF8FA0B3), fontSize = 14.sp, fontWeight = FontWeight.Bold)
        SettingToggle("Auto play on open", auto) { auto = it; prefs.autoPlay = it }
        SettingToggle("Remember / resume position", resume) { resume = it; prefs.rememberPosition = it }
        SettingToggle("Show playback statistics in INFO", stats) { stats = it; prefs.showStats = it }
        Spacer(Modifier.height(18.dp))
        Text("NETWORK BUFFER: ${buffer} ms", color = Color.White, fontSize = 16.sp)
        Slider(value = buffer.toFloat(), onValueChange = { buffer = it.toInt() }, onValueChangeFinished = { prefs.bufferMs = buffer }, valueRange = 250f..5000f, steps = 18)
        Spacer(Modifier.height(10.dp))
        Text("Recommended: 1000–2000 ms for normal streaming. Higher values help unstable networks but increase startup delay.", color = Color(0xFF7F8997), fontSize = 13.sp)
        Spacer(Modifier.height(22.dp))
        Text("DECODER & PERFORMANCE", color = Color(0xFF8FA0B3), fontSize = 14.sp, fontWeight = FontWeight.Bold)
        SettingChoice("Hardware decoder: AUTO", "Let VLC choose the best hardware path", hw == "any") { hw = if (hw == "any") "none" else "auto"; prefs.hwDecoder = hw }
        SettingChoice("Hardware decoder: SOFTWARE", "Force software decoding when hardware output is problematic", hw == "none") { hw = "none"; prefs.hwDecoder = hw }
        SettingToggle("Drop late frames", drop) { drop = it; prefs.dropLateFrames = it }
        SettingToggle("Skip frames when needed", skip) { skip = it; prefs.skipFrames = it }
        SettingToggle("Deinterlace", deint) { deint = it; prefs.deinterlace = it }
        Spacer(Modifier.height(18.dp))
        Text("VIDEO", color = Color(0xFF8FA0B3), fontSize = 14.sp, fontWeight = FontWeight.Bold)
        Text("Aspect ratio: $aspect", color = Color.White, fontSize = 16.sp)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("Fit", "16:9", "4:3", "Fill", "Original").forEach { a -> TVButton(a, { aspect = a; prefs.aspect = a }, aspect == a) }
        }
        Spacer(Modifier.height(12.dp))
        Text("SUBTITLES", color = Color(0xFF8FA0B3), fontSize = 14.sp, fontWeight = FontWeight.Bold)
        Text("Subtitle size: $subSize%", color = Color.White, fontSize = 16.sp)
        Slider(value = subSize.toFloat(), onValueChange = { subSize = it.toInt() }, onValueChangeFinished = { prefs.subtitleSize = subSize }, valueRange = 60f..180f, steps = 11)
        Text("Subtitle delay: ${subDelay} ms", color = Color.White, fontSize = 16.sp)
        Slider(value = subDelay.toFloat(), onValueChange = { subDelay = it.toInt() }, onValueChangeFinished = { prefs.subtitleDelayMs = subDelay }, valueRange = -5000f..5000f, steps = 39)
        Spacer(Modifier.height(18.dp))
        Text("AUDIO", color = Color(0xFF8FA0B3), fontSize = 14.sp, fontWeight = FontWeight.Bold)
        SettingToggle("HD audio / HDMI passthrough", pass) { pass = it; prefs.audioPassthrough = it }
        Text("Tip: passthrough requires a compatible TV/AVR and can send formats such as AC3, E-AC3, TrueHD or DTS-family audio when supported by the device path.", color = Color(0xFF7F8997), fontSize = 13.sp)
        Spacer(Modifier.height(18.dp))
        Text("VLC-STYLE PLAYER TOOLS", color = Color(0xFF8FA0B3), fontSize = 14.sp, fontWeight = FontWeight.Bold)
        Text("• Hardware/software decoding • frame drop/skip • deinterlace • aspect presets • subtitle sizing/delay • audio/subtitle track switching • VLC equalizer presets • volume control • network cache • resume/history • multi-engine playback • HLS/DASH/RTSP • local file picker", color = Color(0xFFBFC8D4), fontSize = 14.sp)
    }
}

@Composable
private fun SettingsDialog(prefs: Prefs, selected: Engine, onEngine: (Engine) -> Unit, onClose: () -> Unit) {
    Box(Modifier.fillMaxSize().background(Color(0xCC000000)), contentAlignment = Alignment.Center) {
        Column(Modifier.width(700.dp).background(Color(0xFF11161E), RoundedCornerShape(16.dp)).border(2.dp, Color(0xFF465262), RoundedCornerShape(16.dp)).padding(26.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) { Text("PLAYER SETTINGS", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f)); TVButton("CLOSE", onClose) }
            Spacer(Modifier.height(16.dp))
            Text("Engine", color = Color(0xFF8FA0B3))
            Engine.values().forEach { e -> SettingChoice(e.label, e.description, selected == e) { onEngine(e) } }
            Spacer(Modifier.height(10.dp))
            Text("Buffer: ${prefs.bufferMs} ms • Resume: ${if (prefs.rememberPosition) "ON" else "OFF"} • AutoPlay: ${if (prefs.autoPlay) "ON" else "OFF"}", color = Color(0xFFBFC8D4))
        }
    }
}

@Composable
private fun SettingChoice(title: String, description: String, selected: Boolean, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp).background(if (selected) Color(0xFF243142) else Color(0xFF141920), RoundedCornerShape(10.dp)).border(2.dp, if (selected) Color(0xFF8FB7FF) else Color(0xFF2D3542), RoundedCornerShape(10.dp)).clickable { onClick() }.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(if (selected) "●" else "○", color = if (selected) Color(0xFF8FB7FF) else Color(0xFF687487), fontSize = 22.sp)
        Spacer(Modifier.width(12.dp))
        Column { Text(title, color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.Bold); Text(description, color = Color(0xFF8D98A8), fontSize = 13.sp) }
    }
}

@Composable
private fun SettingToggle(title: String, enabled: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 5.dp).background(Color(0xFF141920), RoundedCornerShape(10.dp)).clickable { onChange(!enabled) }.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(title, color = Color.White, fontSize = 17.sp, modifier = Modifier.weight(1f)); Text(if (enabled) "ON" else "OFF", color = if (enabled) Color(0xFF8FB7FF) else Color(0xFF7A8492), fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun TVButton(text: String, onClick: () -> Unit, primary: Boolean = false) {
    var focused by remember { mutableStateOf(false) }
    Button(onClick = onClick, modifier = Modifier.onFocusChanged { focused = it.isFocused }.focusable(), colors = ButtonDefaults.buttonColors(containerColor = if (primary) Color(0xFF1E6FE8) else Color(0xFF242B35), contentColor = Color.White), shape = RoundedCornerShape(10.dp)) { Text(text, fontWeight = if (focused) FontWeight.Bold else FontWeight.Medium) }
}

private fun formatTime(ms: Long): String {
    if (ms <= 0) return "00:00"
    val total = ms / 1000
    val h = total / 3600
    val m = (total % 3600) / 60
    val s = total % 60
    return if (h > 0) String.format(Locale.US, "%d:%02d:%02d", h, m, s) else String.format(Locale.US, "%02d:%02d", m, s)
}

private fun detect(raw: String): Detected {
    val s = raw.lowercase(Locale.US)
    fun has(vararg x: String) = x.any { s.contains(it) }
    val container = when { s.contains(".mkv") -> "MKV"; s.contains(".mp4") -> "MP4"; s.contains(".webm") -> "WebM"; s.contains(".avi") -> "AVI"; s.contains(".mov") -> "MOV"; s.contains(".m2ts") -> "M2TS"; s.contains(".ts") -> "MPEG-TS"; s.contains(".m3u8") -> "HLS"; s.contains(".mpd") -> "DASH"; s.contains("rtsp:") -> "RTSP"; else -> "Stream / Auto" }
    val video = when { has("h.266", "h266", "vvc") -> "H.266 / VVC"; has("h.265", "h265", "hevc", "x265") -> "H.265 / HEVC"; has("h.264", "h264", "avc", "x264") -> "H.264 / AVC"; has("av1") -> "AV1"; has("vp9") -> "VP9"; has("vp8") -> "VP8"; has("prores") -> "ProRes"; has("vc-1", "vc1") -> "VC-1"; else -> "Auto-detect" }
    val audio = when { has("truehd") -> "Dolby TrueHD"; has("atmos") -> "Dolby Atmos"; has("dts:x", "dtsx") -> "DTS:X"; has("dts-hd", "dtshd") -> "DTS-HD MA"; has("eac3", "ddp") -> "E-AC3 / DDP"; has("ac3") -> "AC3"; has("flac") -> "FLAC"; has("opus") -> "Opus"; has("aac") -> "AAC"; has("mp3") -> "MP3"; else -> "Auto-detect" }
    val hdr = when { has("dolby vision", "dovi") -> "Dolby Vision"; has("hdr10+") -> "HDR10+"; has("hdr10") -> "HDR10"; has("hlg") -> "HLG"; has("hdr") -> "HDR"; else -> "SDR / Unknown" }
    val resolution = when { has("16k") -> "16K"; has("8k") -> "8K"; has("2160p", "4k") -> "4K / 2160p"; has("1440p", "2k") -> "QHD / 1440p"; has("1080p") -> "FHD / 1080p"; has("720p") -> "HD / 720p"; has("480p") -> "SD / 480p"; else -> "Auto" }
    val tags = buildList { if (has("remux")) add("REMUX"); if (has("web-dl")) add("WEB-DL"); if (has("webrip")) add("WEBRip"); if (has("bluray", "blu-ray")) add("BluRay"); if (has("director's cut", "directors cut")) add("Director's Cut"); if (has("extended")) add("Extended"); if (has("unrated")) add("Unrated"); if (has("remastered")) add("Remastered"); if (has("dual audio", "dual-audio")) add("Dual Audio"); if (has("5.1")) add("5.1"); if (has("7.1")) add("7.1"); if (has("10bit", "10-bit")) add("10-bit"); if (has("12bit", "12-bit")) add("12-bit") }
    return Detected(container, video, audio, hdr, resolution, tags)
}
