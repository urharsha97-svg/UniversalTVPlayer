package com.universaltvplayer

import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView

class MainActivity : ComponentActivity() {
    private var player: ExoPlayer? = null
    private var playerView: PlayerView? = null

    private val openFile = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            try {
                contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            } catch (_: SecurityException) { }
            playUri(uri)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        showHome()
    }

    private fun showHome() {
        releasePlayer()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setBackgroundColor(Color.BLACK)
            setPadding(56, 40, 56, 40)
        }

        val title = TextView(this).apply {
            text = "Universal TV Player"
            textSize = 32f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
        }
        val subtitle = TextView(this).apply {
            text = "Step 2 • Standard Media3 Player"
            textSize = 16f
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
        }
        val open = Button(this).apply {
            text = "OPEN VIDEO FILE"
            isFocusable = true
            isFocusableInTouchMode = true
            setOnClickListener { openFile.launch(arrayOf("video/*", "audio/*")) }
        }
        val url = Button(this).apply {
            text = "PLAY URL"
            isFocusable = true
            isFocusableInTouchMode = true
            setOnClickListener { showUrlDialog() }
        }
        root.addView(title, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = 8 })
        root.addView(subtitle, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = 28 })
        root.addView(open, LinearLayout.LayoutParams(-2, -2).apply { bottomMargin = 12 })
        root.addView(url, LinearLayout.LayoutParams(-2, -2))
        setContentView(root)
        open.requestFocus()
    }

    private fun showUrlDialog() {
        val input = EditText(this).apply {
            hint = "https://example.com/video.mp4"
            singleLine = true
            setTextColor(Color.WHITE)
            setHintTextColor(Color.GRAY)
        }
        val box = LinearLayout(this).apply {
            setPadding(32, 0, 32, 0)
            addView(input, LinearLayout.LayoutParams(-1, -2))
        }
        android.app.AlertDialog.Builder(this)
            .setTitle("Play URL")
            .setView(box)
            .setNegativeButton("CANCEL", null)
            .setPositiveButton("PLAY") { _, _ ->
                val value = input.text.toString().trim()
                if (value.startsWith("http://") || value.startsWith("https://") || value.startsWith("rtsp://")) {
                    playUri(Uri.parse(value))
                } else {
                    Toast.makeText(this, "Enter a valid HTTP/HTTPS/RTSP URL", Toast.LENGTH_LONG).show()
                }
            }
            .show()
    }

    private fun playUri(uri: Uri) {
        val view = PlayerView(this).apply {
            setBackgroundColor(Color.BLACK)
            useController = true
            controllerShowTimeoutMs = 3000
            keepScreenOn = true
        }
        playerView = view
        setContentView(view)

        val exo = ExoPlayer.Builder(this).build()
        player = exo
        view.player = exo
        exo.addListener(object : Player.Listener {
            override fun onPlayerError(error: PlaybackException) {
                Toast.makeText(this@MainActivity, "Playback error: ${error.errorCodeName}", Toast.LENGTH_LONG).show()
            }
        })
        exo.setMediaItem(MediaItem.fromUri(uri))
        exo.prepare()
        exo.playWhenReady = true
        exo.play()
    }

    private fun releasePlayer() {
        playerView?.player = null
        playerView = null
        player?.release()
        player = null
    }

    override fun onStop() {
        super.onStop()
        // Keep lifecycle simple for this stability step; release native playback when leaving the screen.
        releasePlayer()
    }

    override fun onDestroy() {
        releasePlayer()
        super.onDestroy()
    }
}
