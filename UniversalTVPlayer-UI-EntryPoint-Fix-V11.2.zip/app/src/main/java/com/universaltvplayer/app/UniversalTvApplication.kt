package com.universaltvplayer.app

import android.app.Application

class UniversalTvApplication : Application() {
    lateinit var player: PlayerController
        private set

    override fun onCreate() {
        super.onCreate()
        player = PlayerController(this)
    }

    override fun onTerminate() {
        if (::player.isInitialized) player.release()
        super.onTerminate()
    }
}
