package com.universaltvplayer.app

import android.content.Context
import android.net.Uri
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.Player
import androidx.media3.common.Tracks
import androidx.media3.common.TrackSelectionOverride
import androidx.media3.common.util.UnstableApi
import androidx.media3.database.StandaloneDatabaseProvider
import androidx.media3.datasource.DataSource
import androidx.media3.datasource.okhttp.OkHttpDataSource
import androidx.media3.datasource.cache.CacheDataSource
import androidx.media3.datasource.cache.LeastRecentlyUsedCacheEvictor
import androidx.media3.datasource.cache.SimpleCache
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.SeekParameters
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.exoplayer.upstream.DefaultBandwidthMeter
import okhttp3.OkHttpClient
import java.util.concurrent.TimeUnit

@OptIn(UnstableApi::class)
class PlayerController(context: Context) {
    private val appContext = context.applicationContext

    private val database: StandaloneDatabaseProvider by lazy {
        StandaloneDatabaseProvider(appContext)
    }

    private val cache: SimpleCache by lazy {
        SimpleCache(
            appContext.cacheDir.resolve("media-cache"),
            LeastRecentlyUsedCacheEvictor(256L * 1024L * 1024L),
            database
        )
    }

    private val httpClient: OkHttpClient by lazy {
        OkHttpClient.Builder()
            .followRedirects(true)
            .followSslRedirects(true)
            .retryOnConnectionFailure(true)
            .connectTimeout(15, TimeUnit.SECONDS)
            .readTimeout(30, TimeUnit.SECONDS)
            .writeTimeout(30, TimeUnit.SECONDS)
            .build()
    }

    private var userAgent = "UniversalTVPlayer/1.0 Android"
    private var referer = ""

    private val upstreamFactory: DataSource.Factory by lazy {
        val headers = mutableMapOf("User-Agent" to userAgent)
        if (referer.isNotBlank()) headers["Referer"] = referer
        OkHttpDataSource.Factory(httpClient)
            .setUserAgent(userAgent)
            .setDefaultRequestProperties(headers)
    }

    private val dataSourceFactory: DataSource.Factory by lazy {
        CacheDataSource.Factory()
            .setCache(cache)
            .setUpstreamDataSourceFactory(upstreamFactory)
            .setFlags(CacheDataSource.FLAG_IGNORE_CACHE_ON_ERROR)
    }

    private val mediaSourceFactory: DefaultMediaSourceFactory by lazy {
        DefaultMediaSourceFactory(dataSourceFactory)
    }

    private var playerInstance: ExoPlayer? = null
    private var released = false

    val player: ExoPlayer
        get() {
            check(!released) { "PlayerController has been released" }
            return playerInstance ?: createPlayer().also { playerInstance = it }
        }

    var lastError: String? = null
        private set

    private fun createPlayer(): ExoPlayer {
        return ExoPlayer.Builder(appContext)
            .setMediaSourceFactory(mediaSourceFactory)
            .setLoadControl(
                DefaultLoadControl.Builder()
                    .setBufferDurationsMs(10_000, 60_000, 1_000, 2_000)
                    .setTargetBufferBytes(128 * 1024 * 1024)
                    .build()
            )
            .setBandwidthMeter(DefaultBandwidthMeter.getSingletonInstance(appContext))
            .build()
            .apply {
                setSeekParameters(SeekParameters.CLOSEST_SYNC)
                addListener(object : Player.Listener {
                    override fun onPlayerError(error: androidx.media3.common.PlaybackException) {
                        lastError = error.message ?: "Playback error"
                    }
                })
            }
    }

    fun configureHeaders(newUserAgent: String, newReferer: String) {
        userAgent = newUserAgent.ifBlank { "UniversalTVPlayer/1.0 Android" }
        referer = newReferer
    }

    fun play(uri: Uri, subtitleUri: Uri? = null) {
        lastError = null
        val builder = MediaItem.Builder().setUri(uri)
        subtitleUri?.let {
            val name = it.toString().lowercase()
            val mime = when {
                name.endsWith(".ass") || name.endsWith(".ssa") -> MimeTypes.TEXT_SSA
                name.endsWith(".vtt") -> MimeTypes.TEXT_VTT
                else -> MimeTypes.APPLICATION_SUBRIP
            }
            builder.setSubtitleConfigurations(
                listOf(
                    MediaItem.SubtitleConfiguration.Builder(it)
                        .setMimeType(mime)
                        .setLanguage("und")
                        .setSelectionFlags(androidx.media3.common.C.SELECTION_FLAG_DEFAULT)
                        .build()
                )
            )
        }
        player.setMediaItem(builder.build())
        player.prepare()
        player.play()
    }

    fun addExternalSubtitle(uri: Uri) {
        val current = player.currentMediaItem ?: return
        val cfg = MediaItem.SubtitleConfiguration.Builder(uri)
            .setMimeType(
                when {
                    uri.toString().lowercase().endsWith(".ass") ||
                        uri.toString().lowercase().endsWith(".ssa") -> MimeTypes.TEXT_SSA
                    uri.toString().lowercase().endsWith(".vtt") -> MimeTypes.TEXT_VTT
                    else -> MimeTypes.APPLICATION_SUBRIP
                }
            )
            .setLanguage("und")
            .setSelectionFlags(androidx.media3.common.C.SELECTION_FLAG_DEFAULT)
            .build()
        val updated = current.buildUpon()
            .setSubtitleConfigurations(current.localConfiguration?.subtitleConfigurations.orEmpty() + cfg)
            .build()
        val position = player.currentPosition
        player.setMediaItem(updated, position)
        player.prepare()
        player.play()
    }

    fun seekBy(deltaMs: Long) {
        val duration = player.duration
        val target = (player.currentPosition + deltaMs).coerceAtLeast(0L)
        val finalTarget = if (duration > 0) target.coerceAtMost(duration) else target
        player.seekTo(finalTarget)
    }

    fun seekToFraction(fraction: Float) {
        val duration = player.duration
        if (duration > 0) player.seekTo((duration * fraction.coerceIn(0f, 1f)).toLong())
    }

    fun selectTrack(group: Tracks.Group, trackIndex: Int) {
        if (!group.isSupported) return
        val params = player.trackSelectionParameters
        val override = TrackSelectionOverride(group.mediaTrackGroup, listOf(trackIndex))
        player.trackSelectionParameters = params.buildUpon()
            .setOverrideForType(override)
            .build()
    }

    fun disableTextTracks() {
        player.trackSelectionParameters = player.trackSelectionParameters.buildUpon()
            .setTrackTypeDisabled(androidx.media3.common.C.TRACK_TYPE_TEXT, true)
            .build()
    }

    fun enableTextTracks() {
        player.trackSelectionParameters = player.trackSelectionParameters.buildUpon()
            .setTrackTypeDisabled(androidx.media3.common.C.TRACK_TYPE_TEXT, false)
            .build()
    }

    fun release() {
        if (released) return
        released = true
        playerInstance?.release()
        playerInstance = null
    }
}
