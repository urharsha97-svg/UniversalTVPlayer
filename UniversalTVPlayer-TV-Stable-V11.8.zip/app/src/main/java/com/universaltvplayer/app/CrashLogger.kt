package com.universaltvplayer.app

import android.content.Context
import java.io.PrintWriter
import java.io.StringWriter

object CrashLogger {
    @JvmStatic
    fun install(context: Context) {
        val appContext = context.applicationContext
        val previous = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { thread, throwable ->
            log(appContext, "Uncaught exception on ${thread.name}", throwable)
            previous?.uncaughtException(thread, throwable)
        }
    }

    @JvmStatic
    fun log(context: Context, message: String, throwable: Throwable? = null) {
        runCatching {
            val sw = StringWriter()
            throwable?.let { PrintWriter(sw).use { pw -> it.printStackTrace(pw) } }
            val text = buildString {
                append(System.currentTimeMillis())
                append(" ")
                append(message)
                append('\n')
                if (sw.isNotEmpty()) append(sw)
                append("\n")
            }
            context.applicationContext.openFileOutput("crash.log", Context.MODE_APPEND).use { it.write(text.toByteArray()) }
        }
    }
}
