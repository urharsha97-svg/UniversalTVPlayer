# Universal TV Player V8 — TV-first playback rebuild

This build focuses on the parts that previously felt unfinished: reliable Android file-manager integration, a repeatable TV control overlay, proper Back-button behavior, live resume/history persistence, and a clearer VLC-style player surface.

## Playback
- LibVLC / Media3 / Android MediaPlayer engines
- 5/10/30/60 second seek
- elapsed + remaining timeline
- 0.25x–4x playback speed
- hardware/software decoder preference
- buffering/reconnect options
- local files and network URLs
- HLS / DASH / RTSP where supported by the selected engine

## TV UX
- high-contrast focusable controls
- auto-hide controls
- OK/ENTER or click/tap can re-open controls
- Back first hides the overlay, then exits the player
- VLC-style bottom control bar
- visible engine + playback status
- INFO and SETTINGS overlays

## History
- Continue Watching
- last-position resume
- live position/duration refresh
- finished items are removed from Continue Watching
- engine is remembered per history item

## Android integration
- ACTION_VIEW for video/* and audio/*
- application/octet-stream fallback
- content:// URI playback
- Android TV launcher categories

## Important compatibility note
Format/codec/HDR/audio support is engine- and device-dependent. The app exposes LibVLC as the broad-coverage engine but does not fake support for codecs or hardware capabilities that a particular TV cannot decode.
