package com.universaltvplayer.app

import android.app.Application

class UniversalTvApplication : Application() {
    // Deliberately does not instantiate Media3/ExoPlayer during application startup.
    // The player is created only after the user explicitly opens media.
    fun createPlayerController(): PlayerController = PlayerController(applicationContext)
}
