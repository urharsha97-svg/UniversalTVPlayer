plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.universaltvplayer"
    compileSdk = 35

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }

    defaultConfig {
        applicationId = "com.universaltvplayer"
        minSdk = 23
        targetSdk = 35
        versionCode = 120
        versionName = "1.2.0"
    }
}

dependencies {
    implementation("androidx.activity:activity-ktx:1.10.1")
}
