# UniversalTVPlayer V14 — Universal Playback Engine

## Preserved baseline
- Media3 1.11.0 remains the primary playback stack.
- Existing INTERNET permission, Android TV launcher, landscape activity, file picker, URL playback and PlayerView remain.
- No DRM/access-control bypass is implemented.

## Added
- Manual Engine Center: Universal Engine / Media3 Engine / FFmpeg Engine.
- Universal Engine: Media3 hardware/platform renderers first, FFmpeg extension available as an in-engine software decoder extension.
- FFmpeg Engine: same Media3 player surface with FFmpeg extension renderers given priority.
- HLS, DASH and SmoothStreaming modules.
- Larger network buffering, HTTP connect/read timeouts and cross-protocol redirects.
- Optional Authorization and Cookie request headers are read from app preferences (`authorization_header`, `cookie_header`) for authorized sources.
- Playback history, up to 30 recent sources.
- File/stream details: size, duration, buffered position, codecs, MIME, bitrate, resolution, FPS, HDR/color info, audio channel count/sample rate, language/label, subtitles, selection/role flags.
- Double remote BACK within 1.6 seconds returns from playback to Home.
- Build workflow collects and prints all Kotlin/build error lines and uploads the full build log artifact even when the build fails.

## Validation performed here
- ZIP integrity checked.
- AndroidManifest.xml parsed successfully.
- styles.xml parsed successfully.
- build.yml parsed successfully with YAML parser.
- Source audit checked for requested engine/history/details/back/network features.

## Important build validation limit
A full Android Gradle build was not executed in this environment because the Android/Gradle dependency cache is unavailable and outbound Maven DNS/network access is disabled here. The GitHub Actions workflow is therefore the authoritative dependency/build test.

## V14 UI/compatibility pass
- Player top bar reduced to the movie/file name only and automatically hides with the Media3 controller.
- Player bottom-left quick controls: SIZE and SUB; bottom-right SETTINGS.
- Engine and file/stream DETAILS are inside player SETTINGS.
- Engine selection is manual; selecting an engine immediately rebuilds the same source and autoplays from the saved position.
- Android ACTION_VIEW handlers added for video/audio files so Universal TV Player appears in the system player chooser and starts playback directly when selected.
- Added a Universal TV Player launcher/home logo asset.
- HDR-aware window color mode is updated from detected HDR10/PQ, HLG or Dolby Vision video format; actual TV HDR mode remains dependent on Android TV/display/decoder capabilities.
- Media3 PlayerView remains the actual video playback surface/controller; the requested overlays are only shortcuts and hide with the controller.
