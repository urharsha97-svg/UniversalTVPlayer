package com.universaltvplayer

import android.content.Intent
import android.content.pm.ActivityInfo
import android.database.Cursor
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.OpenableColumns
import android.text.TextUtils
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.PopupWindow
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.media3.common.C
import androidx.media3.common.Format
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.Tracks
import androidx.media3.common.TrackSelectionOverride
import androidx.media3.datasource.DefaultDataSource
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.exoplayer.analytics.AnalyticsListener
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.exoplayer.trackselection.DefaultTrackSelector
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import io.github.anilbeesetti.nextlib.media3ext.ffdecoder.NextRenderersFactory
import java.util.Locale

class MainActivity : ComponentActivity() {
    private enum class Engine(val title: String) {
        UNIVERSAL("Universal Engine"),
        MEDIA3("Media3 Engine"),
        FFMPEG("FFmpeg Engine")
    }

    private enum class VideoSize(val title: String, val resizeMode: Int) {
        FIT("Fit", AspectRatioFrameLayout.RESIZE_MODE_FIT),
        FILL("Fill", AspectRatioFrameLayout.RESIZE_MODE_FILL),
        ZOOM("Zoom", AspectRatioFrameLayout.RESIZE_MODE_ZOOM),
        FIXED_WIDTH("Width fixed", AspectRatioFrameLayout.RESIZE_MODE_FIXED_WIDTH),
        FIXED_HEIGHT("Height fixed", AspectRatioFrameLayout.RESIZE_MODE_FIXED_HEIGHT)
    }

    private var engine = Engine.UNIVERSAL
    private var videoSize = VideoSize.FIT
    private var subtitlesEnabled = true
    private var player: ExoPlayer? = null
    private var playerView: PlayerView? = null
    private var currentUri: Uri? = null
    private var currentTitle: String = ""
    private var lastBackMs = 0L
    private var retryCount = 0
    private var resumePositionMs = C.TIME_UNSET
    private var launchedFromExternalChooser = false

    private val prefs by lazy { getSharedPreferences("universal_player", MODE_PRIVATE) }

    private val openFile = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            try {
                contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            } catch (_: SecurityException) { }
            playUri(uri)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        restoreSettings()
        if (!handleIncomingIntent(intent)) showHome()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        if (intent != null && handleIncomingIntent(intent)) setIntent(intent)
    }

    private fun handleIncomingIntent(incoming: Intent): Boolean {
        if (incoming.action == Intent.ACTION_VIEW) {
            launchedFromExternalChooser = true
            val uri = incoming.data
            if (uri != null) {
                try {
                    contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
                } catch (_: SecurityException) { }
                playUri(uri)
                return true
            }
        }
        return false
    }

    private fun restoreSettings() {
        engine = runCatching { Engine.valueOf(prefs.getString("engine", Engine.UNIVERSAL.name) ?: Engine.UNIVERSAL.name) }
            .getOrDefault(Engine.UNIVERSAL)
        videoSize = runCatching { VideoSize.valueOf(prefs.getString("video_size", VideoSize.FIT.name) ?: VideoSize.FIT.name) }
            .getOrDefault(VideoSize.FIT)
        subtitlesEnabled = prefs.getBoolean("subtitles_enabled", true)
    }

    private fun showHome() {
        releasePlayer()
        val root = tvPage()
        val logo = ImageView(this).apply {
            setImageResource(com.universaltvplayer.R.drawable.ic_universal_tv)
            contentDescription = "Universal TV Player"
        }
        root.addView(logo, LinearLayout.LayoutParams(92, 92).apply { bottomMargin = 14 })
        addTitle(root, "Universal TV Player", "V14 • Professional TV interface")
        addButton(root, "▶  OPEN VIDEO / AUDIO FILE", 0) { openFile.launch(arrayOf("video/*", "audio/*", "application/octet-stream")) }
        addButton(root, "🌐  PLAY URL", 1) { showUrlDialog() }
        addButton(root, "▣  HISTORY", 2) { showHistory() }
        addButton(root, "⚙  SETTINGS", 3) { showSettings(false) }
        addButton(root, "⏻  EXIT", 4) { finish() }
        setContentView(root)
        requestFirstFocus(root)
    }

    /** Settings is the single place for engine/details/size/subtitle controls. */
    private fun showSettings(fromPlayer: Boolean) {
        if (fromPlayer) {
            showPlayerSettingsDialog()
            return
        }
        val root = tvPage()
        addTitle(root, "SETTINGS", if (fromPlayer) "Playback settings • source remains loaded" else "Player and playback settings")
        addButton(root, "ENGINE  •  ${engine.title}", 0) { showEngineSettings(fromPlayer) }
        addButton(root, "DETAILS  •  File / Stream information", 1) { showFileDetails(currentUri ?: Uri.EMPTY, returnToPlayer = fromPlayer) }
        addButton(root, "VIDEO SIZE  •  ${videoSize.title}", 2) { showVideoSizeSettings(fromPlayer) }
        addButton(root, "SUBTITLES  •  ${if (subtitlesEnabled) "ON" else "OFF"}", 3) { showSubtitleSettings(fromPlayer) }
        addButton(root, "BACK", 4) {
            if (fromPlayer && currentUri != null) showPlayer() else showHome()
        }
        setContentView(root)
        requestFirstFocus(root)
    }

    /** Just Player-style compact menu opened by the bottom-right gear. */
    private fun showPlayerSettingsDialog() {
        val menu = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, 0, 0, 0)
            setBackgroundColor(Color.rgb(22, 24, 28))
            isFocusable = true
            isFocusableInTouchMode = true
        }

        val popup = PopupWindow(menu, dp(330), dp(300), true).apply {
            setBackgroundDrawable(GradientDrawable().apply {
                cornerRadius = dp(4).toFloat()
                setColor(Color.rgb(22, 24, 28))
            })
            elevation = dp(10).toFloat()
            isOutsideTouchable = true
        }

        fun row(icon: String, title: String, value: String, action: () -> Unit) {
            val item = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(20), 0, dp(20), 0)
                isFocusable = true
                isFocusableInTouchMode = true
                background = GradientDrawable().apply { setColor(Color.TRANSPARENT) }
                setOnFocusChangeListener { v, focused ->
                    v.background = GradientDrawable().apply {
                        setColor(if (focused) Color.rgb(90, 90, 90) else Color.TRANSPARENT)
                    }
                }
                setOnClickListener { popup.dismiss(); action() }
            }
            val i = TextView(this).apply {
                text = icon
                textSize = 26f
                setTextColor(Color.WHITE)
                gravity = Gravity.CENTER
            }
            val labels = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER_VERTICAL
            }
            labels.addView(TextView(this@MainActivity).apply {
                text = title
                textSize = 18f
                setTextColor(Color.WHITE)
            })
            labels.addView(TextView(this@MainActivity).apply {
                text = value
                textSize = 14f
                setTextColor(Color.LTGRAY)
            })
            item.addView(i, LinearLayout.LayoutParams(dp(54), -1))
            item.addView(labels, LinearLayout.LayoutParams(0, -1, 1f))
            menu.addView(item, LinearLayout.LayoutParams(-1, dp(74)))
        }

        row("⚙", "Engine", engine.title) { showEngineSettings(true) }
        row("ⓘ", "Detail", "File / Stream information") { showFileDetails(currentUri ?: Uri.EMPTY, false) }
        row("▶", "Speed", speedLabel()) { showSpeedSettings(popup) }
        row("🔊", "Audio", currentAudioLabel()) { showAudioSettings(popup) }

        val gear = playerView ?: return
        menu.measure(View.MeasureSpec.makeMeasureSpec(dp(330), View.MeasureSpec.EXACTLY), View.MeasureSpec.makeMeasureSpec(dp(300), View.MeasureSpec.EXACTLY))
        popup.showAtLocation(gear, Gravity.BOTTOM or Gravity.END, dp(18), dp(118))
        menu.getChildAt(0)?.requestFocus()
    }

    private fun showSpeedSettings(parent: PopupWindow) {
        val speeds = floatArrayOf(0.5f, 0.75f, 1f, 1.25f, 1.5f, 2f)
        val labels = speeds.map { if (it == 1f) "Normal" else "${it}x" }.toTypedArray()
        android.app.AlertDialog.Builder(this)
            .setTitle("Speed")
            .setSingleChoiceItems(labels, speeds.indexOfFirst { it == (player?.playbackParameters?.speed ?: 1f) }.coerceAtLeast(0)) { dialog, which ->
                player?.setPlaybackSpeed(speeds[which])
                toast("Speed: ${labels[which]}")
                dialog.dismiss()
            }
            .setNegativeButton("BACK", null)
            .show()
    }

    private fun showAudioSettings(parent: PopupWindow) {
        val p = player ?: return
        val tracks = p.currentTracks.groups.filter { it.type == C.TRACK_TYPE_AUDIO && it.length > 0 }
        if (tracks.isEmpty()) {
            android.app.AlertDialog.Builder(this).setTitle("Audio").setMessage("No audio tracks detected yet.")
                .setPositiveButton("CLOSE", null).show()
            return
        }
        val entries = mutableListOf<String>()
        val refs = mutableListOf<Pair<Tracks.Group, Int>>()
        tracks.forEachIndexed { index, group ->
            for (trackIndex in 0 until group.length) {
                if (!group.isTrackSupported(trackIndex)) continue
                val f = group.getTrackFormat(trackIndex)
                val language = f.language?.takeIf { it.isNotBlank() } ?: "Unknown"
                val label = f.label?.takeIf { it.isNotBlank() } ?: "Audio ${entries.size + 1}"
                val channels = if (f.channelCount > 0) " • ${f.channelCount}ch" else ""
                entries += "$label • $language$channels"
                refs += group to trackIndex
            }
        }
        android.app.AlertDialog.Builder(this)
            .setTitle("Audio")
            .setItems(entries.toTypedArray()) { _, which ->
                val (group, trackIndex) = refs[which]
                p.trackSelectionParameters = p.trackSelectionParameters.buildUpon()
                    .setOverrideForType(TrackSelectionOverride(group.mediaTrackGroup, listOf(trackIndex)))
                    .build()
                toast("Audio: ${entries[which]}")
            }
            .setNegativeButton("BACK", null)
            .show()
    }

    private fun speedLabel(): String {
        val speed = player?.playbackParameters?.speed ?: 1f
        return if (kotlin.math.abs(speed - 1f) < 0.01f) "Normal" else String.format(Locale.US, "%.2fx", speed)
    }

    private fun currentAudioLabel(): String {
        val p = player ?: return "Auto"
        val group = p.currentTracks.groups.firstOrNull { it.type == C.TRACK_TYPE_AUDIO && it.length > 0 }
        val index = group?.let { (0 until it.length).firstOrNull { n -> it.isTrackSelected(n) } }
        val f = if (group != null && index != null) group.getTrackFormat(index) else null
        return f?.language ?: "Auto"
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    private fun showEngineSettings(fromPlayer: Boolean) {
        if (fromPlayer) {
            val dialog = android.app.AlertDialog.Builder(this)
                .setTitle("ENGINE")
                .setNegativeButton("BACK", null)
                .create()
            val box = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(28, 10, 28, 10)
            }
            fun addEngine(label: String, accent: Int, target: Engine) {
                val button = tvButton(label + if (engine == target) "  ✓" else "", accent) {
                    dialog.dismiss()
                    selectEngine(target, true)
                }
                box.addView(button, LinearLayout.LayoutParams(-1, 58).apply { bottomMargin = 8 })
            }
            addEngine("UNIVERSAL ENGINE", 0, Engine.UNIVERSAL)
            addEngine("MEDIA3 ENGINE", 1, Engine.MEDIA3)
            addEngine("FFMPEG ENGINE", 2, Engine.FFMPEG)
            dialog.setView(box)
            dialog.setOnShowListener { box.getChildAt(0)?.requestFocus() }
            dialog.show()
            return
        }

        val root = tvPage()
        addTitle(root, "ENGINE", "Manual selection")
        addButton(root, "UNIVERSAL ENGINE${if (engine == Engine.UNIVERSAL) "  ✓" else ""}", 0) {
            selectEngine(Engine.UNIVERSAL, false)
        }
        addButton(root, "MEDIA3 ENGINE${if (engine == Engine.MEDIA3) "  ✓" else ""}", 1) {
            selectEngine(Engine.MEDIA3, false)
        }
        addButton(root, "FFMPEG ENGINE${if (engine == Engine.FFMPEG) "  ✓" else ""}", 2) {
            selectEngine(Engine.FFMPEG, false)
        }
        addButton(root, "BACK TO SETTINGS", 3) { showSettings(false) }
        setContentView(root)
        requestFirstFocus(root)
    }

    private fun selectEngine(newEngine: Engine, fromPlayer: Boolean) {
        if (fromPlayer) resumePositionMs = player?.currentPosition ?: C.TIME_UNSET
        engine = newEngine
        prefs.edit().putString("engine", engine.name).apply()
        toast("${engine.title} selected")
        // Engine switching is always a user action. If a source is active, immediately rebuild
        // the player with the selected engine and autoplay that same source.
        val uri = currentUri
        if (fromPlayer && uri != null) {
            playUri(uri, saveHistory = false, seekToMs = resumePositionMs)
            resumePositionMs = C.TIME_UNSET
        } else {
            showSettings(false)
        }
    }

    private fun showVideoSizeSettings(fromPlayer: Boolean) {
        if (fromPlayer) {
            val titles = VideoSize.values().map { it.title + if (it == videoSize) "  ✓" else "" }.toTypedArray()
            android.app.AlertDialog.Builder(this)
                .setTitle("VIDEO SIZE")
                .setItems(titles) { _, which ->
                    videoSize = VideoSize.values()[which]
                    prefs.edit().putString("video_size", videoSize.name).apply()
                    playerView?.resizeMode = videoSize.resizeMode
                    toast("Video size: ${videoSize.title}")
                }
                .setNegativeButton("BACK", null)
                .show()
            return
        }

        val root = tvPage()
        addTitle(root, "VIDEO SIZE", "Change only the video display size")
        VideoSize.values().forEachIndexed { index, option ->
            addButton(root, "${option.title}${if (videoSize == option) "  ✓" else ""}", index) {
                videoSize = option
                prefs.edit().putString("video_size", videoSize.name).apply()
                playerView?.resizeMode = videoSize.resizeMode
                toast("Video size: ${videoSize.title}")
                showSettings(false)
            }
        }
        addButton(root, "BACK TO SETTINGS", 5) { showSettings(false) }
        setContentView(root)
        requestFirstFocus(root)
    }

    private fun showSubtitleSettings(fromPlayer: Boolean) {
        if (fromPlayer) {
            android.app.AlertDialog.Builder(this)
                .setTitle("SUBTITLES")
                .setSingleChoiceItems(
                    arrayOf("SUBTITLES ON", "SUBTITLES OFF"),
                    if (subtitlesEnabled) 0 else 1
                ) { dialog, which ->
                    setSubtitlesOnPlayer(which == 0)
                    dialog.dismiss()
                }
                .setNegativeButton("BACK", null)
                .show()
            return
        }

        val root = tvPage()
        addTitle(root, "SUBTITLES", "Turn text tracks on/off")
        addButton(root, "SUBTITLES ON${if (subtitlesEnabled) "  ✓" else ""}", 0) {
            setSubtitles(true, false)
        }
        addButton(root, "SUBTITLES OFF${if (!subtitlesEnabled) "  ✓" else ""}", 1) {
            setSubtitles(false, false)
        }
        addButton(root, "BACK TO SETTINGS", 3) { showSettings(false) }
        setContentView(root)
        requestFirstFocus(root)
    }

    private fun setSubtitles(enabled: Boolean, fromPlayer: Boolean) {
        subtitlesEnabled = enabled
        prefs.edit().putBoolean("subtitles_enabled", enabled).apply()
        player?.let { activePlayer ->
            val currentParameters = activePlayer.trackSelectionParameters ?: DefaultTrackSelector.Parameters.DEFAULT
            activePlayer.trackSelectionParameters = currentParameters
                .buildUpon()
                .setTrackTypeDisabled(C.TRACK_TYPE_TEXT, !enabled)
                .build()
        }
        toast("Subtitles ${if (enabled) "ON" else "OFF"}")
        if (fromPlayer && player != null) showPlayer() else showSettings(false)
    }

    private fun showPlayer() {
        val uri = currentUri ?: return showHome()
        playUri(uri, saveHistory = false, seekToMs = resumePositionMs)
        resumePositionMs = C.TIME_UNSET
    }

    private fun showUrlDialog() {
        val input = EditText(this).apply {
            hint = "https://example.com/video.mp4"
            setSingleLine(true)
            setTextColor(Color.WHITE)
            setHintTextColor(Color.GRAY)
            isFocusable = true
            isFocusableInTouchMode = true
        }
        val box = LinearLayout(this).apply {
            setPadding(32, 0, 32, 0)
            addView(input, LinearLayout.LayoutParams(-1, -2))
        }
        android.app.AlertDialog.Builder(this)
            .setTitle("PLAY URL")
            .setView(box)
            .setNegativeButton("CANCEL", null)
            .setPositiveButton("PLAY") { _, _ ->
                val value = input.text.toString().trim()
                if (value.startsWith("http://") || value.startsWith("https://") || value.startsWith("rtsp://")) {
                    playUri(Uri.parse(value))
                } else {
                    toast("Enter a valid HTTP/HTTPS/RTSP URL")
                }
            }
            .show()
    }

    private fun playUri(uri: Uri, saveHistory: Boolean = true, seekToMs: Long = C.TIME_UNSET) {
        currentUri = uri
        currentTitle = queryDisplayName(uri) ?: uri.lastPathSegment ?: uri.toString()
        if (saveHistory) saveHistory(uri, currentTitle)
        releasePlayer()
        retryCount = 0

        val container = FrameLayout(this).apply {
            setBackgroundColor(Color.BLACK)
            isFocusable = true
            isFocusableInTouchMode = true
        }

        // Keep the real Media3 PlayerView/controller as the playback surface. The custom
        // overlays only provide the requested TV shortcuts and disappear with the controller.
        val view = PlayerView(this).apply {
            setBackgroundColor(Color.BLACK)
            useController = true
            controllerShowTimeoutMs = 3500
            controllerHideOnTouch = true
            keepScreenOn = true
            setKeepContentOnPlayerReset(true)
            setShowBuffering(PlayerView.SHOW_BUFFERING_WHEN_PLAYING)
            resizeMode = videoSize.resizeMode
            layoutParams = FrameLayout.LayoutParams(-1, -1)
        }
        playerView = view
        container.addView(view)

        val title = TextView(this).apply {
            text = currentTitle
            textSize = 15f
            setTextColor(Color.WHITE)
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
            gravity = Gravity.CENTER_VERTICAL
            setPadding(18, 0, 18, 0)
            background = GradientDrawable().apply {
                cornerRadius = 12f
                setColor(Color.argb(185, 0, 0, 0))
            }
        }
        container.addView(title, FrameLayout.LayoutParams(-1, 48).apply {
            gravity = Gravity.TOP
            leftMargin = 18
            rightMargin = 18
            topMargin = 16
        })

        // Bottom-right player actions, matching the simple Just Player style:
        // subtitle -> video size -> gear. Engine and file details live inside the gear menu.
        val actionBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(4, 4, 4, 4)
            background = GradientDrawable().apply {
                cornerRadius = 14f
                setColor(Color.argb(150, 0, 0, 0))
            }
        }

        fun actionButton(icon: String, description: String, action: () -> Unit): Button =
            Button(this).apply {
                text = icon
                contentDescription = description
                textSize = 24f
                minWidth = 58
                minHeight = 52
                isAllCaps = false
                isFocusable = true
                isFocusableInTouchMode = true
                setTextColor(Color.WHITE)
                gravity = Gravity.CENTER
                setPadding(0, 0, 0, 0)
                layoutParams = LinearLayout.LayoutParams(58, 52).apply {
                    leftMargin = 2
                    rightMargin = 2
                }
                background = GradientDrawable().apply { setColor(Color.TRANSPARENT) }
                setOnFocusChangeListener { v, focused ->
                    v.background = GradientDrawable().apply {
                        setColor(if (focused) Color.argb(95, 255, 255, 255) else Color.TRANSPARENT)
                    }
                }
                setOnClickListener { action() }
            }

        val subtitleButton = actionButton("CC", "Subtitles") {
            setSubtitlesOnPlayer(!subtitlesEnabled)
        }
        val sizeButton = actionButton("⛶", "Video size") {
            videoSize = when (videoSize) {
                VideoSize.FIT -> VideoSize.FILL
                VideoSize.FILL -> VideoSize.ZOOM
                VideoSize.ZOOM -> VideoSize.FIT
                VideoSize.FIXED_WIDTH -> VideoSize.FIXED_HEIGHT
                VideoSize.FIXED_HEIGHT -> VideoSize.FIT
            }
            prefs.edit().putString("video_size", videoSize.name).apply()
            playerView?.resizeMode = videoSize.resizeMode
            toast("Video size: ${videoSize.title}")
        }
        actionBar.addView(subtitleButton)
        actionBar.addView(sizeButton)

        container.addView(actionBar, FrameLayout.LayoutParams(-2, 60).apply {
            gravity = Gravity.BOTTOM or Gravity.END
            rightMargin = 76
            bottomMargin = 54
        })

        // One compact gear, exactly like the circled control in the reference player.
        // Engine change and Details are opened from this gear; no separate settings bar/button.
        val settingsButton = Button(this).apply {
            text = "⚙"
            contentDescription = "Player settings"
            textSize = 25f
            isAllCaps = false
            isFocusable = true
            isFocusableInTouchMode = true
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, 0)
            background = GradientDrawable().apply { setColor(Color.TRANSPARENT) }
            layoutParams = FrameLayout.LayoutParams(58, 52).apply {
                gravity = Gravity.BOTTOM or Gravity.END
                rightMargin = 18
                bottomMargin = 58
            }
            setOnFocusChangeListener { v, focused ->
                v.background = GradientDrawable().apply {
                    setColor(if (focused) Color.argb(95, 255, 255, 255) else Color.TRANSPARENT)
                }
            }
            setOnClickListener { showSettings(true) }
        }
        container.addView(settingsButton)

        view.setControllerVisibilityListener(PlayerView.ControllerVisibilityListener { visibility ->
            title.visibility = visibility
            actionBar.visibility = visibility
            settingsButton.visibility = visibility
        })
        title.visibility = View.VISIBLE
        actionBar.visibility = View.VISIBLE
        settingsButton.visibility = View.VISIBLE

        setContentView(container)
        view.post { view.requestFocus() }

        val exo = buildPlayer()
        player = exo
        view.player = exo
        exo.addListener(object : Player.Listener {
            override fun onPlayerError(error: PlaybackException) {
                if (retryCount < 2 && currentUri == uri) {
                    retryCount++
                    toast("Playback/network issue — retrying ($retryCount/2)")
                    view.postDelayed({
                        if (player === exo) {
                            exo.prepare()
                            exo.play()
                        }
                    }, 900L * retryCount)
                } else {
                    toast("Playback error: ${error.errorCodeName}")
                }
            }

            override fun onPlaybackStateChanged(playbackState: Int) {
                if (playbackState == Player.STATE_READY) retryCount = 0
            }

            override fun onTracksChanged(tracks: Tracks) {
                updateWindowHdrMode(exo.videoFormat)
            }
        })
        // Media3 exposes the actual decoder input format through AnalyticsListener.
        // Use it for HDR/Dolby Vision detection instead of overriding a non-existent
        // Player.Listener callback.
        exo.addAnalyticsListener(object : AnalyticsListener {
            override fun onVideoInputFormatChanged(
                eventTime: AnalyticsListener.EventTime,
                format: Format,
                decoderReuseEvaluation: androidx.media3.exoplayer.DecoderReuseEvaluation?
            ) {
                updateWindowHdrMode(format)
            }
        })
        exo.setMediaItem(MediaItem.fromUri(uri))
        exo.prepare()
        if (seekToMs != C.TIME_UNSET && seekToMs > 0) exo.seekTo(seekToMs)
        exo.playWhenReady = true
        exo.play()
    }

    private fun setSubtitlesOnPlayer(enabled: Boolean) {
        subtitlesEnabled = enabled
        prefs.edit().putBoolean("subtitles_enabled", enabled).apply()
        player?.let { activePlayer ->
            val currentParameters = activePlayer.trackSelectionParameters ?: DefaultTrackSelector.Parameters.DEFAULT
            activePlayer.trackSelectionParameters = currentParameters
                .buildUpon()
                .setTrackTypeDisabled(C.TRACK_TYPE_TEXT, !enabled)
                .build()
        }
        toast("Subtitles ${if (enabled) "ON" else "OFF"}")
    }

    private fun hdrType(format: Format?): String {
        if (format == null) return "SDR / unknown"
        val mime = format.sampleMimeType.orEmpty()
        val codecs = format.codecs.orEmpty().lowercase(Locale.US)
        val colorInfo = format.colorInfo
        val sourceTag = currentTitle.lowercase(Locale.US)
        val isDolbyVision = mime.contains("dolby-vision", ignoreCase = true) ||
            codecs.startsWith("dvhe") || codecs.startsWith("dvh1") || codecs.startsWith("dvav") ||
            sourceTag.contains("dolby vision") || sourceTag.contains(" dolbyvision") || sourceTag.contains(" dv ")
        val isHdr10 = colorInfo?.colorTransfer == C.COLOR_TRANSFER_ST2084 ||
            sourceTag.contains("hdr10") || sourceTag.contains("hdr 10")
        val isHlg = colorInfo?.colorTransfer == C.COLOR_TRANSFER_HLG || sourceTag.contains("hlg")
        return when {
            isDolbyVision && isHdr10 -> "Dolby Vision + HDR10/PQ"
            isDolbyVision -> "Dolby Vision"
            isHdr10 -> "HDR10/PQ"
            isHlg -> "HLG"
            else -> "SDR / unknown"
        }
    }

    private fun updateWindowHdrMode(format: Format?) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        val colorInfo = format?.colorInfo
        val mime = format?.sampleMimeType.orEmpty()
        val codecs = format?.codecs.orEmpty().lowercase(Locale.US)
        val sourceTag = currentTitle.lowercase(Locale.US)
        val hdr = mime.contains("dolby-vision", ignoreCase = true) ||
            codecs.startsWith("dvhe") || codecs.startsWith("dvh1") || codecs.startsWith("dvav") ||
            colorInfo?.colorTransfer == C.COLOR_TRANSFER_ST2084 ||
            colorInfo?.colorTransfer == C.COLOR_TRANSFER_HLG ||
            sourceTag.contains("hdr10") || sourceTag.contains("hdr 10") ||
            sourceTag.contains("dolby vision") || sourceTag.contains(" dolbyvision")
        window.colorMode = if (hdr) ActivityInfo.COLOR_MODE_HDR else ActivityInfo.COLOR_MODE_DEFAULT
    }

    private fun buildPlayer(): ExoPlayer {
        // Avoid an excessive initial wait while still retaining enough headroom for unstable links.
        val loadControl = DefaultLoadControl.Builder()
            .setBufferDurationsMs(
                3_000,
                60_000,
                750,
                1_500
            )
            .setPrioritizeTimeOverSizeThresholds(false)
            .build()

        val httpFactory = DefaultHttpDataSource.Factory()
            .setConnectTimeoutMs(12_000)
            .setReadTimeoutMs(20_000)
            .setAllowCrossProtocolRedirects(true)
            .setUserAgent("UniversalTVPlayer/1.4")
            .setDefaultRequestProperties(authorizedHeaders())
        val dataSourceFactory = DefaultDataSource.Factory(this, httpFactory)
        val mediaSourceFactory = DefaultMediaSourceFactory(dataSourceFactory)
        val trackSelector = DefaultTrackSelector(this).apply {
            parameters = buildUponParameters()
                .setTrackTypeDisabled(C.TRACK_TYPE_TEXT, !subtitlesEnabled)
                .build()
        }

        val builder = ExoPlayer.Builder(this)
            .setLoadControl(loadControl)
            .setTrackSelector(trackSelector)
            .setMediaSourceFactory(mediaSourceFactory)

        when (engine) {
            Engine.UNIVERSAL -> {
                val renderers = NextRenderersFactory(this)
                    .setExtensionRendererMode(DefaultRenderersFactory.EXTENSION_RENDERER_MODE_ON)
                builder.setRenderersFactory(renderers)
            }
            Engine.MEDIA3 -> {
                val renderers = DefaultRenderersFactory(this)
                    .setExtensionRendererMode(DefaultRenderersFactory.EXTENSION_RENDERER_MODE_OFF)
                builder.setRenderersFactory(renderers)
            }
            Engine.FFMPEG -> {
                val renderers = NextRenderersFactory(this)
                    .setExtensionRendererMode(DefaultRenderersFactory.EXTENSION_RENDERER_MODE_PREFER)
                builder.setRenderersFactory(renderers)
            }
        }
        return builder.build()
    }

    private fun authorizedHeaders(): Map<String, String> {
        val headers = mutableMapOf<String, String>()
        prefs.getString("authorization_header", null)?.takeIf { it.isNotBlank() }?.let { headers["Authorization"] = it }
        prefs.getString("cookie_header", null)?.takeIf { it.isNotBlank() }?.let { headers["Cookie"] = it }
        return headers
    }

    private fun showFileDetails(uri: Uri, returnToPlayer: Boolean = false) {
        val p = player
        val lines = mutableListOf<String>()
        lines += "ENGINE: ${engine.title}"
        lines += "NAME: ${currentTitle.ifBlank { queryDisplayName(uri) ?: "Unknown" }}"
        lines += "URI: ${if (uri == Uri.EMPTY) "No active source" else uri}"
        lines += "SIZE: ${querySize(uri)}"
        if (p != null) {
            lines += "DURATION: ${formatDuration(p.duration)}"
            lines += "POSITION: ${formatDuration(p.currentPosition)}"
            lines += "BUFFERED: ${formatDuration(p.bufferedPosition)}"
            lines += "VIDEO SIZE: ${if (p.videoSize.width > 0) "${p.videoSize.width}x${p.videoSize.height}" else "unknown"}"
            p.videoFormat?.let { lines += "VIDEO FORMAT:\n${formatDetails(it)}" }
            appendTrackDetails(lines, p.currentTracks.groups)
        } else {
            lines += "STATUS: No player currently active"
            lines += "Open a file/URL, then press SETTINGS → DETAILS after tracks are detected."
        }

        val scroll = ScrollView(this).apply {
            setBackgroundColor(Color.BLACK)
            addView(TextView(this@MainActivity).apply {
                text = lines.joinToString("\n\n")
                textSize = 15f
                setTextColor(Color.WHITE)
                setPadding(32, 24, 32, 24)
            })
        }
        android.app.AlertDialog.Builder(this)
            .setTitle("FILE / STREAM DETAILS")
            .setView(scroll)
            .setPositiveButton("CLOSE") { _, _ -> if (returnToPlayer) showPlayer() }
            .setOnCancelListener { if (returnToPlayer) showPlayer() }
            .show()
    }

    private fun appendTrackDetails(lines: MutableList<String>, groups: List<Tracks.Group>) {
        var videoIndex = 0
        var audioIndex = 0
        var textIndex = 0
        for (group in groups) {
            val firstSupportedTrack = (0 until group.length).firstOrNull { group.isTrackSupported(it) } ?: continue
            val format = group.getTrackFormat(firstSupportedTrack)
            when (group.type) {
                C.TRACK_TYPE_VIDEO -> { videoIndex++; lines += "VIDEO #$videoIndex\n${formatDetails(format)}" }
                C.TRACK_TYPE_AUDIO -> { audioIndex++; lines += "AUDIO #$audioIndex\n${formatDetails(format)}" }
                C.TRACK_TYPE_TEXT -> { textIndex++; lines += "SUBTITLE #$textIndex\n${formatDetails(format)}" }
            }
        }
        if (videoIndex == 0) lines += "VIDEO: none detected"
        if (audioIndex == 0) lines += "AUDIO: none detected"
        if (textIndex == 0) lines += "SUBTITLES: none detected"
    }

    private fun formatDetails(f: Format): String = buildString {
        appendLine("codec: ${f.sampleMimeType ?: "unknown"}")
        appendLine("codecs: ${f.codecs ?: "unknown"}")
        appendLine("bitrate: ${if (f.bitrate > 0) formatBitrate(f.bitrate) else "unknown"}")
        if (f.width > 0 || f.height > 0) appendLine("resolution: ${f.width}x${f.height}")
        if (f.frameRate > 0f) appendLine("FPS: ${String.format(Locale.US, "%.3f", f.frameRate)}")
        if (f.channelCount > 0) appendLine("channels: ${f.channelCount}")
        if (f.sampleRate > 0) appendLine("sample rate: ${f.sampleRate} Hz")
        if (!f.language.isNullOrBlank()) appendLine("language: ${f.language}")
        if (!f.label.isNullOrBlank()) appendLine("label: ${f.label}")
        val hdr = hdrType(f)
        if (hdr != "SDR / unknown") {
            appendLine("HDR: $hdr")
            f.colorInfo?.let {
                appendLine("HDR/color: transfer=${it.colorTransfer}, space=${it.colorSpace}, range=${it.colorRange}")
            }
        }
        appendLine("selection flags: ${f.selectionFlags}")
        appendLine("role flags: ${f.roleFlags}")
    }

    private fun showHistory() {
        val history = loadHistory()
        if (history.isEmpty()) {
            android.app.AlertDialog.Builder(this).setTitle("HISTORY").setMessage("No playback history yet.")
                .setPositiveButton("CLOSE", null).show()
            return
        }
        val labels = history.map { "${it.second}\n${it.first}" }.toTypedArray()
        android.app.AlertDialog.Builder(this)
            .setTitle("HISTORY")
            .setItems(labels) { _, which -> playUri(Uri.parse(history[which].first)) }
            .setNegativeButton("CLOSE", null)
            .setNeutralButton("CLEAR") { _, _ ->
                prefs.edit().remove("history_order").remove("history").apply()
                toast("History cleared")
            }.show()
    }

    private fun saveHistory(uri: Uri, title: String) {
        val existing = loadHistory().filterNot { it.first == uri.toString() }.toMutableList()
        existing.add(0, uri.toString() to title)
        val trimmed = existing.take(30)
        prefs.edit().putStringSet("history", trimmed.map { "${it.first}\t${it.second}" }.toSet())
            .putString("history_order", trimmed.joinToString("\n") { "${it.first}\t${it.second}" }).apply()
    }

    private fun loadHistory(): List<Pair<String, String>> {
        val raw = prefs.getString("history_order", "") ?: ""
        if (raw.isBlank()) return emptyList()
        return raw.lines().mapNotNull {
            val tab = it.indexOf('\t')
            if (tab <= 0) null else it.substring(0, tab) to it.substring(tab + 1)
        }
    }

    private fun queryDisplayName(uri: Uri): String? {
        if (uri == Uri.EMPTY) return null
        var cursor: Cursor? = null
        return try {
            cursor = contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)
            if (cursor?.moveToFirst() == true) cursor.getString(0) else null
        } catch (_: Exception) { null } finally { cursor?.close() }
    }

    private fun querySize(uri: Uri): String {
        if (uri == Uri.EMPTY) return "unknown"
        var cursor: Cursor? = null
        return try {
            cursor = contentResolver.query(uri, arrayOf(OpenableColumns.SIZE), null, null, null)
            if (cursor?.moveToFirst() == true) {
                val size = cursor.getLong(0)
                if (size >= 0) formatBytes(size) else "unknown"
            } else "remote/unknown"
        } catch (_: Exception) { "remote/unknown" } finally { cursor?.close() }
    }

    private fun formatBytes(value: Long): String {
        if (value < 1024) return "$value B"
        val kb = value / 1024.0
        if (kb < 1024) return String.format(Locale.US, "%.2f KiB", kb)
        val mb = kb / 1024.0
        if (mb < 1024) return String.format(Locale.US, "%.2f MiB", mb)
        return String.format(Locale.US, "%.2f GiB", mb / 1024.0)
    }

    private fun formatBitrate(value: Int): String = if (value >= 1_000_000) {
        String.format(Locale.US, "%.2f Mbps", value / 1_000_000.0)
    } else String.format(Locale.US, "%.0f kbps", value / 1000.0)

    private fun formatDuration(ms: Long): String {
        if (ms == C.TIME_UNSET || ms < 0) return "unknown"
        val total = ms / 1000
        val h = total / 3600
        val m = (total % 3600) / 60
        val s = total % 60
        return if (h > 0) String.format(Locale.US, "%d:%02d:%02d", h, m, s)
        else String.format(Locale.US, "%02d:%02d", m, s)
    }

    private fun tvPage(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        gravity = Gravity.CENTER
        setBackgroundColor(Color.rgb(8, 10, 14))
        setPadding(72, 42, 72, 42)
        isFocusable = true
        isFocusableInTouchMode = true
    }

    private fun addTitle(root: LinearLayout, title: String, subtitle: String) {
        val t = TextView(this).apply {
            text = title
            textSize = 30f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
        }
        val s = TextView(this).apply {
            text = subtitle
            textSize = 15f
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
        }
        root.addView(t, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = 8 })
        root.addView(s, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = 24 })
    }

    private fun addButton(root: LinearLayout, text: String, accentIndex: Int, action: () -> Unit) {
        val button = tvButton(text, accentIndex, action)
        root.addView(button, LinearLayout.LayoutParams(-1, 58).apply {
            bottomMargin = 10
        })
    }

    private fun tvButton(text: String, accentIndex: Int, action: () -> Unit): Button = Button(this).apply {
        this.text = text
        textSize = 15f
        isAllCaps = false
        isFocusable = true
        isFocusableInTouchMode = true
        gravity = Gravity.CENTER
        setTextColor(Color.WHITE)
        setPadding(24, 0, 24, 0)
        applyTvButtonBackground(this, accentIndex)
        setOnFocusChangeListener { v, focused -> applyTvButtonBackground(v as Button, accentIndex, focused) }
        setOnClickListener { action() }
    }

    private fun tvSmallButton(text: String, accentIndex: Int, action: () -> Unit): Button = tvButton(text, accentIndex, action).apply {
        layoutParams = LinearLayout.LayoutParams(-2, 48)
        textSize = 13f
    }

    private fun applyTvButtonBackground(button: Button, accentIndex: Int, focused: Boolean = button.hasFocus()) {
        val accents = intArrayOf(Color.rgb(24, 105, 190), Color.rgb(0, 137, 123), Color.rgb(123, 72, 180), Color.rgb(190, 106, 24), Color.rgb(48, 120, 66), Color.rgb(150, 50, 70))
        val base = accents[accentIndex.coerceAtMost(accents.lastIndex)]
        val color = if (focused) Color.WHITE else Color.argb(235, Color.red(base), Color.green(base), Color.blue(base))
        val text = if (focused) Color.BLACK else Color.WHITE
        button.background = GradientDrawable().apply {
            cornerRadius = 14f
            setColor(color)
            if (focused) setStroke(4, base) else setStroke(1, Color.argb(180, 255, 255, 255))
        }
        button.setTextColor(text)
        button.scaleX = if (focused) 1.015f else 1f
        button.scaleY = if (focused) 1.015f else 1f
    }

    private fun requestFirstFocus(root: LinearLayout) {
        val first = root.childrenButtons().firstOrNull()
        first?.post { first.requestFocus() }
    }

    private fun LinearLayout.childrenButtons(): List<Button> = (0 until childCount).mapNotNull { getChildAt(it) as? Button }

    override fun onKeyDown(keyCode: Int, event: KeyEvent): Boolean {
        if (keyCode == KeyEvent.KEYCODE_BACK && player != null) {
            if (launchedFromExternalChooser) {
                releasePlayer()
                finish()
                return true
            }
            val now = System.currentTimeMillis()
            if (now - lastBackMs <= 1600) {
                lastBackMs = 0L
                showHome()
            } else {
                lastBackMs = now
                toast("Press BACK again to return to Home")
            }
            return true
        }
        return super.onKeyDown(keyCode, event)
    }

    private fun releasePlayer() {
        playerView?.player = null
        playerView = null
        player?.release()
        player = null
    }

    override fun onDestroy() {
        releasePlayer()
        super.onDestroy()
    }

    private fun toast(message: String) = Toast.makeText(this, message, Toast.LENGTH_LONG).show()
}
