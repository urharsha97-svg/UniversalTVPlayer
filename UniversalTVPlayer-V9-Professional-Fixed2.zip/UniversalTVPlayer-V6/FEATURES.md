# Universal TV Player V9 – Android TV Professional

- VLC-style fullscreen player layout with top title/status and bottom transport bar.
- Controls can be reopened with any D-pad key; first BACK hides controls, second BACK returns Home.
- Reliable LibVLC surface re-attach/play handling to reduce audio-only/black-screen cases when switching media.
- Clear high-contrast focus states: selected buttons are blue and focused controls have a yellow outline.
- 5/10/30/60 second seek, speed 0.25x–4x, play/pause, stop, volume, audio/subtitle track cycling.
- INFO overlay with engine/status/container/video/audio/HDR/resolution/tag detection.
- Continue Watching history with progress, resume and clear-history.
- Android TV ACTION_VIEW support for video/audio content opened from Files Manager and other apps.
- LibVLC, Media3 and Android MediaPlayer engines.
- Universal APK plus ARM ABI outputs; universal APK is easiest for Android 11 TVs when CPU ABI is unknown.

Compatibility for individual codecs/HDR/audio formats remains dependent on the TV hardware, Android framework and active playback engine.
