package com.universaltvplayer.app

import android.app.Application

class UniversalTvApplication : Application() {
    /**
     * Keep media-engine construction out of Application.onCreate(). Android may create the
     * Application very early; the player is only needed after the Activity has attached.
     */
    val player: PlayerController by lazy(LazyThreadSafetyMode.SYNCHRONIZED) {
        PlayerController(applicationContext)
    }

    override fun onCreate() {
        super.onCreate()
        // Intentionally do not initialize PlayerController here.
    }
}
