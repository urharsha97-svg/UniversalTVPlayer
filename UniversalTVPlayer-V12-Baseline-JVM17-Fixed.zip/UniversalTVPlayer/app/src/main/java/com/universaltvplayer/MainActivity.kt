package com.universaltvplayer

import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.activity.ComponentActivity

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setBackgroundColor(Color.BLACK)
            setPadding(48, 48, 48, 48)
        }

        val title = TextView(this).apply {
            text = "Universal TV Player"
            textSize = 32f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
        }

        val button = Button(this).apply {
            text = "BASELINE OK"
            isFocusable = true
            isFocusableInTouchMode = true
            setOnClickListener { text = "BASELINE RUNNING" }
        }

        root.addView(title, LinearLayout.LayoutParams(-2, -2).apply { bottomMargin = 32 })
        root.addView(button, LinearLayout.LayoutParams(-2, -2))
        setContentView(root)
        button.requestFocus()
    }
}
