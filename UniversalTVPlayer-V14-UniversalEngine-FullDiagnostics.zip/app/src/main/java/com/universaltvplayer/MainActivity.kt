package com.universaltvplayer

import android.content.Intent
import android.database.Cursor
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.text.TextUtils
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.media3.common.C
import androidx.media3.common.Format
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.Tracks
import androidx.media3.datasource.DefaultDataSource
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.exoplayer.trackselection.DefaultTrackSelector
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import io.github.anilbeesetti.nextlib.media3ext.ffdecoder.NextRenderersFactory
import java.util.Locale

class MainActivity : ComponentActivity() {
    private enum class Engine(val title: String) {
        UNIVERSAL("Universal Engine"),
        MEDIA3("Media3 Engine"),
        FFMPEG("FFmpeg Engine")
    }

    private enum class VideoSize(val title: String, val resizeMode: Int) {
        FIT("Fit", AspectRatioFrameLayout.RESIZE_MODE_FIT),
        FILL("Fill", AspectRatioFrameLayout.RESIZE_MODE_FILL),
        ZOOM("Zoom", AspectRatioFrameLayout.RESIZE_MODE_ZOOM),
        FIXED_WIDTH("Width fixed", AspectRatioFrameLayout.RESIZE_MODE_FIXED_WIDTH),
        FIXED_HEIGHT("Height fixed", AspectRatioFrameLayout.RESIZE_MODE_FIXED_HEIGHT)
    }

    private var engine = Engine.UNIVERSAL
    private var videoSize = VideoSize.FIT
    private var subtitlesEnabled = true
    private var player: ExoPlayer? = null
    private var playerView: PlayerView? = null
    private var currentUri: Uri? = null
    private var currentTitle: String = ""
    private var lastBackMs = 0L
    private var retryCount = 0
    private var resumePositionMs = C.TIME_UNSET

    private val prefs by lazy { getSharedPreferences("universal_player", MODE_PRIVATE) }

    private val openFile = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            try {
                contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            } catch (_: SecurityException) { }
            playUri(uri)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        restoreSettings()
        showHome()
    }

    private fun restoreSettings() {
        engine = runCatching { Engine.valueOf(prefs.getString("engine", Engine.UNIVERSAL.name) ?: Engine.UNIVERSAL.name) }
            .getOrDefault(Engine.UNIVERSAL)
        videoSize = runCatching { VideoSize.valueOf(prefs.getString("video_size", VideoSize.FIT.name) ?: VideoSize.FIT.name) }
            .getOrDefault(VideoSize.FIT)
        subtitlesEnabled = prefs.getBoolean("subtitles_enabled", true)
    }

    private fun showHome() {
        releasePlayer()
        val root = tvPage()
        addTitle(root, "Universal TV Player", "V14 • Professional TV interface")
        addButton(root, "▶  OPEN VIDEO / AUDIO FILE", 0) { openFile.launch(arrayOf("video/*", "audio/*", "application/octet-stream")) }
        addButton(root, "🌐  PLAY URL", 1) { showUrlDialog() }
        addButton(root, "▣  HISTORY", 2) { showHistory() }
        addButton(root, "⚙  SETTINGS", 3) { showSettings(false) }
        addButton(root, "⏻  EXIT", 4) { finish() }
        setContentView(root)
        requestFirstFocus(root)
    }

    /** Settings is the single place for engine/details/size/subtitle controls. */
    private fun showSettings(fromPlayer: Boolean) {
        if (fromPlayer) {
            resumePositionMs = player?.currentPosition ?: C.TIME_UNSET
            player?.pause()
        }
        val root = tvPage()
        addTitle(root, "SETTINGS", if (fromPlayer) "Playback settings • source remains loaded" else "Player and playback settings")
        addButton(root, "ENGINE  •  ${engine.title}", 0) { showEngineSettings(fromPlayer) }
        addButton(root, "DETAILS  •  File / Stream information", 1) { showFileDetails(currentUri ?: Uri.EMPTY, returnToPlayer = fromPlayer) }
        addButton(root, "VIDEO SIZE  •  ${videoSize.title}", 2) { showVideoSizeSettings(fromPlayer) }
        addButton(root, "SUBTITLES  •  ${if (subtitlesEnabled) "ON" else "OFF"}", 3) { showSubtitleSettings(fromPlayer) }
        addButton(root, "BACK", 4) {
            if (fromPlayer && currentUri != null) showPlayer() else showHome()
        }
        setContentView(root)
        requestFirstFocus(root)
    }

    private fun showEngineSettings(fromPlayer: Boolean) {
        val root = tvPage()
        addTitle(root, "ENGINE", "Manual selection • selecting an engine starts playback immediately")
        addButton(root, "UNIVERSAL ENGINE${if (engine == Engine.UNIVERSAL) "  ✓" else ""}", 0) {
            selectEngine(Engine.UNIVERSAL, fromPlayer)
        }
        addButton(root, "MEDIA3 ENGINE${if (engine == Engine.MEDIA3) "  ✓" else ""}", 1) {
            selectEngine(Engine.MEDIA3, fromPlayer)
        }
        addButton(root, "FFMPEG ENGINE${if (engine == Engine.FFMPEG) "  ✓" else ""}", 2) {
            selectEngine(Engine.FFMPEG, fromPlayer)
        }
        addButton(root, "BACK TO SETTINGS", 3) { showSettings(fromPlayer) }
        setContentView(root)
        requestFirstFocus(root)
    }

    private fun selectEngine(newEngine: Engine, fromPlayer: Boolean) {
        if (fromPlayer) resumePositionMs = player?.currentPosition ?: C.TIME_UNSET
        engine = newEngine
        prefs.edit().putString("engine", engine.name).apply()
        toast("${engine.title} selected")
        // Engine switching is always a user action. If a source is active, immediately rebuild
        // the player with the selected engine and autoplay that same source.
        val uri = currentUri
        if (fromPlayer && uri != null) {
            playUri(uri, saveHistory = false, seekToMs = resumePositionMs)
            resumePositionMs = C.TIME_UNSET
        } else {
            showSettings(false)
        }
    }

    private fun showVideoSizeSettings(fromPlayer: Boolean) {
        val root = tvPage()
        addTitle(root, "VIDEO SIZE", "Change only the video display size; playback engine is unchanged")
        VideoSize.values().forEachIndexed { index, option ->
            addButton(root, "${option.title}${if (videoSize == option) "  ✓" else ""}", index) {
                videoSize = option
                prefs.edit().putString("video_size", videoSize.name).apply()
                playerView?.resizeMode = videoSize.resizeMode
                toast("Video size: ${videoSize.title}")
                if (fromPlayer && player != null) showPlayer() else showSettings(false)
            }
        }
        addButton(root, "BACK TO SETTINGS", 5) { showSettings(fromPlayer) }
        setContentView(root)
        requestFirstFocus(root)
    }

    private fun showSubtitleSettings(fromPlayer: Boolean) {
        val root = tvPage()
        addTitle(root, "SUBTITLES", "Turn subtitles on/off for text tracks")
        addButton(root, "SUBTITLES ON${if (subtitlesEnabled) "  ✓" else ""}", 0) {
            setSubtitles(true, fromPlayer)
        }
        addButton(root, "SUBTITLES OFF${if (!subtitlesEnabled) "  ✓" else ""}", 1) {
            setSubtitles(false, fromPlayer)
        }
        addButton(root, "SUBTITLE  •  Toggle text tracks on/off", 2) {
            toast("Subtitle text tracks are controlled here; the original Media3 player controls remain unchanged")
            showSettings(fromPlayer)
        }
        addButton(root, "BACK TO SETTINGS", 3) { showSettings(fromPlayer) }
        setContentView(root)
        requestFirstFocus(root)
    }

    private fun setSubtitles(enabled: Boolean, fromPlayer: Boolean) {
        subtitlesEnabled = enabled
        prefs.edit().putBoolean("subtitles_enabled", enabled).apply()
        player?.let { activePlayer ->
            activePlayer.trackSelectionParameters = activePlayer.trackSelectionParameters
                .buildUpon()
                .setTrackTypeDisabled(C.TRACK_TYPE_TEXT, !enabled)
                .build()
        }
        toast("Subtitles ${if (enabled) "ON" else "OFF"}")
        if (fromPlayer && player != null) showPlayer() else showSettings(false)
    }

    private fun showPlayer() {
        val uri = currentUri ?: return showHome()
        playUri(uri, saveHistory = false, seekToMs = resumePositionMs)
        resumePositionMs = C.TIME_UNSET
    }

    private fun showUrlDialog() {
        val input = EditText(this).apply {
            hint = "https://example.com/video.mp4"
            setSingleLine(true)
            setTextColor(Color.WHITE)
            setHintTextColor(Color.GRAY)
            isFocusable = true
            isFocusableInTouchMode = true
        }
        val box = LinearLayout(this).apply {
            setPadding(32, 0, 32, 0)
            addView(input, LinearLayout.LayoutParams(-1, -2))
        }
        android.app.AlertDialog.Builder(this)
            .setTitle("PLAY URL")
            .setView(box)
            .setNegativeButton("CANCEL", null)
            .setPositiveButton("PLAY") { _, _ ->
                val value = input.text.toString().trim()
                if (value.startsWith("http://") || value.startsWith("https://") || value.startsWith("rtsp://")) {
                    playUri(Uri.parse(value))
                } else {
                    toast("Enter a valid HTTP/HTTPS/RTSP URL")
                }
            }
            .show()
    }

    private fun playUri(uri: Uri, saveHistory: Boolean = true, seekToMs: Long = C.TIME_UNSET) {
        currentUri = uri
        currentTitle = queryDisplayName(uri) ?: uri.lastPathSegment ?: uri.toString()
        if (saveHistory) saveHistory(uri, currentTitle)
        releasePlayer()
        retryCount = 0

        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.BLACK)
        }
        val bar = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            setPadding(12, 8, 12, 8)
            setBackgroundColor(Color.rgb(18, 18, 18))
        }
        val label = TextView(this).apply {
            text = "${engine.title}  •  $currentTitle"
            textSize = 14f
            setTextColor(Color.WHITE)
            ellipsize = TextUtils.TruncateAt.END
            maxLines = 1
        }
        val settingsButton = tvSmallButton("⚙  SETTINGS", 0) { showSettings(true) }
        bar.addView(label, LinearLayout.LayoutParams(0, -2, 1f))
        bar.addView(settingsButton, LinearLayout.LayoutParams(-2, -2))

        val view = PlayerView(this).apply {
            setBackgroundColor(Color.BLACK)
            useController = true
            controllerShowTimeoutMs = 3500
            keepScreenOn = true
            setShowBuffering(PlayerView.SHOW_BUFFERING_WHEN_PLAYING)
            resizeMode = videoSize.resizeMode
            layoutParams = LinearLayout.LayoutParams(-1, 0, 1f)
        }
        playerView = view
        container.addView(bar)
        container.addView(view)
        setContentView(container)

        val exo = buildPlayer()
        player = exo
        view.player = exo
        exo.addListener(object : Player.Listener {
            override fun onPlayerError(error: PlaybackException) {
                if (retryCount < 2 && currentUri == uri) {
                    retryCount++
                    toast("Network/decoder issue — retrying ($retryCount/2)")
                    view.postDelayed({
                        if (player === exo && exo.playbackState != Player.STATE_IDLE) {
                            exo.prepare()
                            exo.play()
                        }
                    }, 900L * retryCount)
                } else {
                    toast("Playback error: ${error.errorCodeName}")
                }
            }

            override fun onPlaybackStateChanged(playbackState: Int) {
                if (playbackState == Player.STATE_READY) retryCount = 0
            }

            override fun onTracksChanged(tracks: Tracks) { }
        })
        exo.setMediaItem(MediaItem.fromUri(uri))
        exo.prepare()
        if (seekToMs != C.TIME_UNSET && seekToMs > 0) exo.seekTo(seekToMs)
        exo.playWhenReady = true
        exo.play()
    }

    private fun buildPlayer(): ExoPlayer {
        // Avoid an excessive initial wait while still retaining enough headroom for unstable links.
        val loadControl = DefaultLoadControl.Builder()
            .setBufferDurationsMs(
                8_000,
                90_000,
                1_500,
                4_000
            )
            .setPrioritizeTimeOverSizeThresholds(false)
            .build()

        val httpFactory = DefaultHttpDataSource.Factory()
            .setConnectTimeoutMs(12_000)
            .setReadTimeoutMs(20_000)
            .setAllowCrossProtocolRedirects(true)
            .setUserAgent("UniversalTVPlayer/1.4")
            .setDefaultRequestProperties(authorizedHeaders())
        val dataSourceFactory = DefaultDataSource.Factory(this, httpFactory)
        val mediaSourceFactory = DefaultMediaSourceFactory(dataSourceFactory)
        val trackSelector = DefaultTrackSelector(this).apply {
            parameters = buildUponParameters()
                .setTrackTypeDisabled(C.TRACK_TYPE_TEXT, !subtitlesEnabled)
                .build()
        }

        val builder = ExoPlayer.Builder(this)
            .setLoadControl(loadControl)
            .setTrackSelector(trackSelector)
            .setMediaSourceFactory(mediaSourceFactory)

        when (engine) {
            Engine.UNIVERSAL -> {
                val renderers = NextRenderersFactory(this)
                    .setExtensionRendererMode(DefaultRenderersFactory.EXTENSION_RENDERER_MODE_ON)
                builder.setRenderersFactory(renderers)
            }
            Engine.MEDIA3 -> {
                val renderers = DefaultRenderersFactory(this)
                    .setExtensionRendererMode(DefaultRenderersFactory.EXTENSION_RENDERER_MODE_OFF)
                builder.setRenderersFactory(renderers)
            }
            Engine.FFMPEG -> {
                val renderers = NextRenderersFactory(this)
                    .setExtensionRendererMode(DefaultRenderersFactory.EXTENSION_RENDERER_MODE_PREFER)
                builder.setRenderersFactory(renderers)
            }
        }
        return builder.build()
    }

    private fun authorizedHeaders(): Map<String, String> {
        val headers = mutableMapOf<String, String>()
        prefs.getString("authorization_header", null)?.takeIf { it.isNotBlank() }?.let { headers["Authorization"] = it }
        prefs.getString("cookie_header", null)?.takeIf { it.isNotBlank() }?.let { headers["Cookie"] = it }
        return headers
    }

    private fun showFileDetails(uri: Uri, returnToPlayer: Boolean = false) {
        val p = player
        val lines = mutableListOf<String>()
        lines += "ENGINE: ${engine.title}"
        lines += "NAME: ${currentTitle.ifBlank { queryDisplayName(uri) ?: "Unknown" }}"
        lines += "URI: ${if (uri == Uri.EMPTY) "No active source" else uri}"
        lines += "SIZE: ${querySize(uri)}"
        if (p != null) {
            lines += "DURATION: ${formatDuration(p.duration)}"
            lines += "POSITION: ${formatDuration(p.currentPosition)}"
            lines += "BUFFERED: ${formatDuration(p.bufferedPosition)}"
            lines += "VIDEO SIZE: ${if (p.videoSize.width > 0) "${p.videoSize.width}x${p.videoSize.height}" else "unknown"}"
            p.videoFormat?.let { lines += "VIDEO FORMAT:\n${formatDetails(it)}" }
            appendTrackDetails(lines, p.currentTracks.groups)
        } else {
            lines += "STATUS: No player currently active"
            lines += "Open a file/URL, then press SETTINGS → DETAILS after tracks are detected."
        }

        val scroll = ScrollView(this).apply {
            setBackgroundColor(Color.BLACK)
            addView(TextView(this@MainActivity).apply {
                text = lines.joinToString("\n\n")
                textSize = 15f
                setTextColor(Color.WHITE)
                setPadding(32, 24, 32, 24)
            })
        }
        android.app.AlertDialog.Builder(this)
            .setTitle("FILE / STREAM DETAILS")
            .setView(scroll)
            .setPositiveButton("CLOSE") { _, _ -> if (returnToPlayer) showPlayer() }
            .setOnCancelListener { if (returnToPlayer) showPlayer() }
            .show()
    }

    private fun appendTrackDetails(lines: MutableList<String>, groups: List<Tracks.Group>) {
        var videoIndex = 0
        var audioIndex = 0
        var textIndex = 0
        for (group in groups) {
            val firstSupportedTrack = (0 until group.length).firstOrNull { group.isTrackSupported(it) } ?: continue
            val format = group.getTrackFormat(firstSupportedTrack)
            when (group.type) {
                C.TRACK_TYPE_VIDEO -> { videoIndex++; lines += "VIDEO #$videoIndex\n${formatDetails(format)}" }
                C.TRACK_TYPE_AUDIO -> { audioIndex++; lines += "AUDIO #$audioIndex\n${formatDetails(format)}" }
                C.TRACK_TYPE_TEXT -> { textIndex++; lines += "SUBTITLE #$textIndex\n${formatDetails(format)}" }
            }
        }
        if (videoIndex == 0) lines += "VIDEO: none detected"
        if (audioIndex == 0) lines += "AUDIO: none detected"
        if (textIndex == 0) lines += "SUBTITLES: none detected"
    }

    private fun formatDetails(f: Format): String = buildString {
        appendLine("codec: ${f.sampleMimeType ?: "unknown"}")
        appendLine("codecs: ${f.codecs ?: "unknown"}")
        appendLine("bitrate: ${if (f.bitrate > 0) formatBitrate(f.bitrate) else "unknown"}")
        if (f.width > 0 || f.height > 0) appendLine("resolution: ${f.width}x${f.height}")
        if (f.frameRate > 0f) appendLine("FPS: ${String.format(Locale.US, "%.3f", f.frameRate)}")
        if (f.channelCount > 0) appendLine("channels: ${f.channelCount}")
        if (f.sampleRate > 0) appendLine("sample rate: ${f.sampleRate} Hz")
        if (!f.language.isNullOrBlank()) appendLine("language: ${f.language}")
        if (!f.label.isNullOrBlank()) appendLine("label: ${f.label}")
        f.colorInfo?.let { appendLine("HDR/color: transfer=${it.colorTransfer}, space=${it.colorSpace}, range=${it.colorRange}") }
        appendLine("selection flags: ${f.selectionFlags}")
        appendLine("role flags: ${f.roleFlags}")
    }

    private fun showHistory() {
        val history = loadHistory()
        if (history.isEmpty()) {
            android.app.AlertDialog.Builder(this).setTitle("HISTORY").setMessage("No playback history yet.")
                .setPositiveButton("CLOSE", null).show()
            return
        }
        val labels = history.map { "${it.second}\n${it.first}" }.toTypedArray()
        android.app.AlertDialog.Builder(this)
            .setTitle("HISTORY")
            .setItems(labels) { _, which -> playUri(Uri.parse(history[which].first)) }
            .setNegativeButton("CLOSE", null)
            .setNeutralButton("CLEAR") { _, _ ->
                prefs.edit().remove("history_order").remove("history").apply()
                toast("History cleared")
            }.show()
    }

    private fun saveHistory(uri: Uri, title: String) {
        val existing = loadHistory().filterNot { it.first == uri.toString() }.toMutableList()
        existing.add(0, uri.toString() to title)
        val trimmed = existing.take(30)
        prefs.edit().putStringSet("history", trimmed.map { "${it.first}\t${it.second}" }.toSet())
            .putString("history_order", trimmed.joinToString("\n") { "${it.first}\t${it.second}" }).apply()
    }

    private fun loadHistory(): List<Pair<String, String>> {
        val raw = prefs.getString("history_order", "") ?: ""
        if (raw.isBlank()) return emptyList()
        return raw.lines().mapNotNull {
            val tab = it.indexOf('\t')
            if (tab <= 0) null else it.substring(0, tab) to it.substring(tab + 1)
        }
    }

    private fun queryDisplayName(uri: Uri): String? {
        if (uri == Uri.EMPTY) return null
        var cursor: Cursor? = null
        return try {
            cursor = contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)
            if (cursor?.moveToFirst() == true) cursor.getString(0) else null
        } catch (_: Exception) { null } finally { cursor?.close() }
    }

    private fun querySize(uri: Uri): String {
        if (uri == Uri.EMPTY) return "unknown"
        var cursor: Cursor? = null
        return try {
            cursor = contentResolver.query(uri, arrayOf(OpenableColumns.SIZE), null, null, null)
            if (cursor?.moveToFirst() == true) {
                val size = cursor.getLong(0)
                if (size >= 0) formatBytes(size) else "unknown"
            } else "remote/unknown"
        } catch (_: Exception) { "remote/unknown" } finally { cursor?.close() }
    }

    private fun formatBytes(value: Long): String {
        if (value < 1024) return "$value B"
        val kb = value / 1024.0
        if (kb < 1024) return String.format(Locale.US, "%.2f KiB", kb)
        val mb = kb / 1024.0
        if (mb < 1024) return String.format(Locale.US, "%.2f MiB", mb)
        return String.format(Locale.US, "%.2f GiB", mb / 1024.0)
    }

    private fun formatBitrate(value: Int): String = if (value >= 1_000_000) {
        String.format(Locale.US, "%.2f Mbps", value / 1_000_000.0)
    } else String.format(Locale.US, "%.0f kbps", value / 1000.0)

    private fun formatDuration(ms: Long): String {
        if (ms == C.TIME_UNSET || ms < 0) return "unknown"
        val total = ms / 1000
        val h = total / 3600
        val m = (total % 3600) / 60
        val s = total % 60
        return if (h > 0) String.format(Locale.US, "%d:%02d:%02d", h, m, s)
        else String.format(Locale.US, "%02d:%02d", m, s)
    }

    private fun tvPage(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        gravity = Gravity.CENTER
        setBackgroundColor(Color.rgb(8, 10, 14))
        setPadding(72, 42, 72, 42)
        isFocusable = true
        isFocusableInTouchMode = true
    }

    private fun addTitle(root: LinearLayout, title: String, subtitle: String) {
        val t = TextView(this).apply {
            text = title
            textSize = 30f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
        }
        val s = TextView(this).apply {
            text = subtitle
            textSize = 15f
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
        }
        root.addView(t, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = 8 })
        root.addView(s, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = 24 })
    }

    private fun addButton(root: LinearLayout, text: String, accentIndex: Int, action: () -> Unit) {
        val button = tvButton(text, accentIndex, action)
        root.addView(button, LinearLayout.LayoutParams(-1, 58).apply {
            bottomMargin = 10
        })
    }

    private fun tvButton(text: String, accentIndex: Int, action: () -> Unit): Button = Button(this).apply {
        this.text = text
        textSize = 15f
        isAllCaps = false
        isFocusable = true
        isFocusableInTouchMode = true
        gravity = Gravity.CENTER
        setTextColor(Color.WHITE)
        setPadding(24, 0, 24, 0)
        applyTvButtonBackground(this, accentIndex)
        setOnFocusChangeListener { v, focused -> applyTvButtonBackground(v as Button, accentIndex, focused) }
        setOnClickListener { action() }
    }

    private fun tvSmallButton(text: String, accentIndex: Int, action: () -> Unit): Button = tvButton(text, accentIndex, action).apply {
        layoutParams = LinearLayout.LayoutParams(-2, 48)
        textSize = 13f
    }

    private fun applyTvButtonBackground(button: Button, accentIndex: Int, focused: Boolean = button.hasFocus()) {
        val accents = intArrayOf(Color.rgb(24, 105, 190), Color.rgb(0, 137, 123), Color.rgb(123, 72, 180), Color.rgb(190, 106, 24), Color.rgb(48, 120, 66), Color.rgb(150, 50, 70))
        val base = accents[accentIndex.coerceAtMost(accents.lastIndex)]
        val color = if (focused) Color.WHITE else Color.argb(235, Color.red(base), Color.green(base), Color.blue(base))
        val text = if (focused) Color.BLACK else Color.WHITE
        button.background = GradientDrawable().apply {
            cornerRadius = 14f
            setColor(color)
            if (focused) setStroke(4, base) else setStroke(1, Color.argb(180, 255, 255, 255))
        }
        button.setTextColor(text)
        button.scaleX = if (focused) 1.015f else 1f
        button.scaleY = if (focused) 1.015f else 1f
    }

    private fun requestFirstFocus(root: LinearLayout) {
        val first = root.childrenButtons().firstOrNull()
        first?.post { first.requestFocus() }
    }

    private fun LinearLayout.childrenButtons(): List<Button> = (0 until childCount).mapNotNull { getChildAt(it) as? Button }

    override fun onKeyDown(keyCode: Int, event: KeyEvent): Boolean {
        if (keyCode == KeyEvent.KEYCODE_BACK && player != null) {
            val now = System.currentTimeMillis()
            if (now - lastBackMs <= 1600) {
                lastBackMs = 0L
                showHome()
            } else {
                lastBackMs = now
                toast("Press BACK again to return to Home")
            }
            return true
        }
        return super.onKeyDown(keyCode, event)
    }

    private fun releasePlayer() {
        playerView?.player = null
        playerView = null
        player?.release()
        player = null
    }

    override fun onDestroy() {
        releasePlayer()
        super.onDestroy()
    }

    private fun toast(message: String) = Toast.makeText(this, message, Toast.LENGTH_LONG).show()
}
