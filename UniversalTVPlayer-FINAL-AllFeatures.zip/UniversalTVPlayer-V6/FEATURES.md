# UniversalTVPlayer Final Feature Matrix

This build combines the VLC-style multi-engine player foundation with the requested TV playback controls.

## Implemented in the current app
- LibVLC 3.7.5, Media3 ExoPlayer and Android MediaPlayer engines
- 5/10/30/60 second seek controls
- 0.25x–4x playback speed cycle
- elapsed/duration display and resume history
- codec/container/HDR/resolution tag detection for common filename/URL metadata
- LibVLC audio/subtitle track controls and equalizer presets
- volume controls, hardware/software decoder mode, buffering, reconnect, frame-drop/skip and deinterlace options
- HLS/DASH/RTSP and local file entry points
- TV-first focusable dark UI and fullscreen playback
- ABI split builds for arm64-v8a and armeabi-v7a

## Engine/device-dependent compatibility targets
Some requested items cannot honestly be guaranteed by an Android app on every TV. These depend on the source stream, TV SoC, Android version, codec libraries and network/provider: VVC/16K/Dolby Vision variants, advanced HDR metadata, true per-frame diagnostics, frame stepping, video filters, chapter/title menus, IPTV/Xtream authentication, SMB/NFS/SFTP/WebDAV/UPnP/DLNA browsing, EPG/XMLTV, casting, DVD/Blu-ray menus, external subtitle providers and full 360/VR controls. The UI and architecture are prepared for these capabilities without claiming unsupported hardware can provide them.
