package com.urharsha97.universaltvplayer

import android.app.Activity
import android.net.Uri
import android.os.Bundle
import android.view.SurfaceView
import android.view.View
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.focusable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import org.videolan.libvlc.LibVLC
import org.videolan.libvlc.Media
import org.videolan.libvlc.MediaPlayer
import java.util.Locale

private data class DetectedFeatures(
    val container: String,
    val tags: List<String>,
    val hdr: String,
    val color: String,
    val resolution: String,
    val videoCodec: String,
    val audioCodec: String,
    val audioLayout: String,
    val frameRate: String
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.decorView.systemUiVisibility =
            View.SYSTEM_UI_FLAG_FULLSCREEN or
                View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
        setContent { MaterialTheme { UniversalTVPlayerApp() } }
    }
}

@Composable
private fun UniversalTVPlayerApp() {
    val context = LocalContext.current
    val activity = context as? Activity
    val surface = remember { SurfaceView(context) }
    val libVlc = remember {
        LibVLC(context, arrayListOf(
            "--audio-time-stretch",
            "--network-caching=1000",
            "--file-caching=1000",
            "--avcodec-hw=any",
            "--drop-late-frames",
            "--skip-frames"
        ))
    }
    val mediaPlayer = remember { MediaPlayer(libVlc) }

    var url by remember { mutableStateOf("") }
    var playing by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf("Ready") }
    var showInfo by remember { mutableStateOf(false) }
    var speed by remember { mutableFloatStateOf(1f) }
    var features by remember { mutableStateOf<DetectedFeatures?>(null) }
    var introVisible by remember { mutableStateOf(false) }
    val inputFocus = remember { FocusRequester() }

    DisposableEffect(Unit) {
        val eventListener = MediaPlayer.EventListener { event ->
            when (event.type) {
                MediaPlayer.Event.Opening -> status = "Opening…"
                MediaPlayer.Event.Buffering -> status = "Buffering… ${event.buffer}%"
                MediaPlayer.Event.Playing -> {
                    playing = true
                    status = "Playing"
                    introVisible = true
                }
                MediaPlayer.Event.Paused -> {
                    playing = false
                    status = "Paused"
                }
                MediaPlayer.Event.Stopped -> {
                    playing = false
                    status = "Stopped"
                }
                MediaPlayer.Event.EndReached -> {
                    playing = false
                    status = "Ended"
                }
                MediaPlayer.Event.EncounteredError -> {
                    playing = false
                    status = "Playback error — try another decoder/stream"
                }
            }
        }
        mediaPlayer.setEventListener(eventListener)
        onDispose {
            try {
                mediaPlayer.stop()
                mediaPlayer.vlcVout.detachViews()
            } catch (_: Exception) { }
            mediaPlayer.release()
            libVlc.release()
        }
    }

    fun stop() {
        try { mediaPlayer.stop() } catch (_: Exception) { }
        playing = false
        status = "Ready"
        showInfo = false
        introVisible = false
    }

    fun loadUrl() {
        val clean = url.trim()
        if (clean.isEmpty()) {
            status = "Enter a URL"
            return
        }
        try {
            stop()
            val detected = detectFeatures(clean)
            features = detected
            val media = Media(libVlc, Uri.parse(clean))
            media.setHWDecoderEnabled(true, false)
            media.addOption(":network-caching=1000")
            media.addOption(":file-caching=1000")
            media.addOption(":http-reconnect=true")
            mediaPlayer.setMedia(media)
            media.release()
            mediaPlayer.play()
            status = "Loading…"
        } catch (e: Exception) {
            status = "Unable to open stream: ${e.message ?: "invalid URL"}"
        }
    }

    Box(Modifier.fillMaxSize().background(Color.Black)) {
        if (playing || status == "Opening…" || status.startsWith("Buffering") || features != null) {
            AndroidView(
                modifier = Modifier.fillMaxSize(),
                factory = {
                    surface.apply {
                        setBackgroundColor(android.graphics.Color.BLACK)
                        mediaPlayer.vlcVout.setVideoView(this)
                        mediaPlayer.vlcVout.attachViews()
                    }
                }
            )

            Row(
                modifier = Modifier.align(Alignment.TopEnd).padding(20.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Button(
                    onClick = { showInfo = !showInfo },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xCC202020))
                ) { Text("INFO") }
                Button(
                    onClick = {
                        speed = if (speed >= 2f) 1f else speed + 0.5f
                        mediaPlayer.rate = speed
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xCC202020))
                ) { Text("${speed}x") }
                Button(
                    onClick = { if (playing) { mediaPlayer.pause() } else { mediaPlayer.play() } },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xCC202020))
                ) { Text(if (playing) "PAUSE" else "PLAY") }
                Button(
                    onClick = { stop() },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xCC202020))
                ) { Text("STOP") }
            }

            if (introVisible && features != null) {
                LaunchedEffect(features) {
                    kotlinx.coroutines.delay(1200)
                    introVisible = false
                }
                FeatureBanner(features!!, Modifier.align(Alignment.TopStart).padding(20.dp))
            }

            if (showInfo && features != null) {
                InfoPanel(features!!, status, Modifier.align(Alignment.BottomStart).padding(24.dp))
            }
        } else {
            Column(
                modifier = Modifier.fillMaxSize().padding(horizontal = 64.dp),
                verticalArrangement = Arrangement.Center
            ) {
                Text("Universal TV Player V4", color = Color.White, fontSize = 40.sp)
                Spacer(Modifier.height(8.dp))
                Text(
                    "Universal LibVLC engine • TV-first • broad container/codec/audio support",
                    color = Color.Gray,
                    fontSize = 18.sp
                )
                Spacer(Modifier.height(28.dp))
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    BasicTextField(
                        value = url,
                        onValueChange = { url = it },
                        singleLine = true,
                        modifier = Modifier
                            .weight(1f)
                            .height(62.dp)
                            .background(Color(0xFF202020), RoundedCornerShape(10.dp))
                            .border(2.dp, Color(0xFF444444), RoundedCornerShape(10.dp))
                            .padding(horizontal = 18.dp, vertical = 19.dp)
                            .focusRequester(inputFocus)
                            .focusable(),
                        textStyle = TextStyle(color = Color.White, fontSize = 18.sp),
                        decorationBox = { inner ->
                            if (url.isEmpty()) Text("Paste MP4 / MKV / AVI / MOV / WebM / TS / FLV / stream URL…", color = Color.Gray, fontSize = 18.sp)
                            inner()
                        }
                    )
                    Spacer(Modifier.width(14.dp))
                    Button(onClick = { loadUrl() }, modifier = Modifier.height(62.dp)) { Text("PLAY") }
                }
                Spacer(Modifier.height(18.dp))
                Text(
                    "V4 engine: containers • H.264/HEVC/VP8/VP9/AV1/MPEG/VC-1/Xvid/DivX • Dolby/DTS/AAC/FLAC/Opus/MP3 and more • subtitles • HLS/DASH/RTSP",
                    color = Color.LightGray,
                    fontSize = 14.sp
                )
                Spacer(Modifier.height(8.dp))
                Text(
                    "HDR/Dolby Vision/8K/16K/10-bit/12-bit output remains hardware/display dependent.",
                    color = Color.Gray,
                    fontSize = 13.sp
                )
            }
        }
    }

    LaunchedEffect(Unit) { inputFocus.requestFocus() }
}

@Composable
private fun FeatureBanner(f: DetectedFeatures, modifier: Modifier = Modifier) {
    Column(
        modifier = modifier
            .background(Color(0xE51A1A1A), RoundedCornerShape(12.dp))
            .padding(horizontal = 16.dp, vertical = 12.dp)
    ) {
        Text("V4 • ${f.container} • ${f.videoCodec}", color = Color.White, fontSize = 18.sp)
        Text(
            listOf(f.resolution, f.hdr, f.color, f.audioCodec, f.audioLayout, f.frameRate)
                .filter { it != "Unknown" && it != "" }
                .joinToString("  •  "),
            color = Color.LightGray,
            fontSize = 13.sp
        )
        if (f.tags.isNotEmpty()) {
            Text(f.tags.take(8).joinToString("  •  "), color = Color.White, fontSize = 12.sp)
        }
    }
}

@Composable
private fun InfoPanel(f: DetectedFeatures, status: String, modifier: Modifier = Modifier) {
    Column(
        modifier = modifier
            .background(Color(0xF0151515), RoundedCornerShape(14.dp))
            .padding(18.dp)
    ) {
        Text("Stream / file capabilities", color = Color.White, fontSize = 20.sp)
        Spacer(Modifier.height(8.dp))
        Text("Container: ${f.container}", color = Color.LightGray, fontSize = 14.sp)
        Text("Video: ${f.videoCodec} • ${f.resolution} • ${f.frameRate}", color = Color.LightGray, fontSize = 14.sp)
        Text("Dynamic range: ${f.hdr} • Color: ${f.color}", color = Color.LightGray, fontSize = 14.sp)
        Text("Audio: ${f.audioCodec} • ${f.audioLayout}", color = Color.LightGray, fontSize = 14.sp)
        Text("Tags: ${if (f.tags.isEmpty()) "none detected" else f.tags.joinToString(", ")}", color = Color.LightGray, fontSize = 14.sp)
        Text("Engine: LibVLC Universal Decoder", color = Color.White, fontSize = 14.sp)
        Text("Status: $status", color = Color.LightGray, fontSize = 14.sp)
    }
}

private fun detectFeatures(raw: String): DetectedFeatures {
    val lower = raw.lowercase(Locale.US)
    val path = lower.substringBefore('?').substringBefore('#')
    val name = path.substringAfterLast('/').replace('_', ' ')
    val ext = name.substringAfterLast('.', "").uppercase(Locale.US)
    val container = when (ext) {
        "MKV" -> "MKV / Matroska"
        "MP4", "M4V" -> "MP4"
        "AVI" -> "AVI"
        "MOV" -> "MOV / QuickTime"
        "WEBM" -> "WebM"
        "TS", "M2TS", "MTS" -> "MPEG-TS / M2TS"
        "FLV" -> "FLV"
        "WMV", "ASF" -> "WMV / ASF"
        "M3U8" -> "HLS"
        "MPD" -> "DASH"
        "RTSP" -> "RTSP"
        else -> if (lower.contains("m3u8")) "HLS" else if (lower.contains(".mpd")) "DASH" else "Stream / auto-detect"
    }
    fun has(vararg s: String) = s.any { lower.contains(it) }
    val tags = mutableListOf<String>()
    val tagMap = listOf(
        "remux" to "REMUX", "web-dl" to "WEB-DL", "webdl" to "WEB-DL", "webrip" to "WEBRip",
        "bluray" to "BluRay", "bdrip" to "BDRip", "brrip" to "BRRip", "hdrip" to "HDRip",
        "hdtv" to "HDTV", "dvdrip" to "DVDRip", "vodrip" to "VODRip", "dvdscr" to "DVDScr",
        "workprint" to "WP", "wp" to "WP", "telecine" to "TC", "telesync" to "TS",
        "hcam" to "HDCAM", "cam" to "CAM", "r5" to "R5", "theatrical" to "THEATRICAL",
        "director's cut" to "DIRECTOR'S CUT", "directors cut" to "DIRECTOR'S CUT", "extended" to "EXTENDED",
        "unrated" to "UNRATED", "remastered" to "REMASTERED", "open matte" to "OPEN MATTE",
        "proper" to "PROPER", "repack" to "REPACK", "imax enhanced" to "IMAX Enhanced",
        "dual audio" to "Dual Audio", "multi audio" to "Multi-Audio", "dubbed" to "Dubbed", "subbed" to "Subbed"
    )
    tagMap.forEach { (needle, label) -> if (lower.contains(needle) && label !in tags) tags += label }

    val hdr = when {
        has("dolby vision iq", "dovi iq", "dv iq") -> "Dolby Vision IQ"
        has("dolby vision", "dovi") -> "Dolby Vision / DoVi (source tag)"
        has("hdr10+ adaptive", "hdr10plus adaptive", "hdr10plusadaptive") -> "HDR10+ Adaptive"
        has("hdr10+") -> "HDR10+"
        has("hdr10") -> "HDR10"
        has("hlg") -> "HLG"
        has("technicolor") -> "Advanced HDR by Technicolor"
        has("displayhdr 1000", "displayhdr1000") -> "DisplayHDR 1000"
        has("displayhdr 600", "displayhdr600") -> "DisplayHDR 600"
        has("displayhdr 400", "displayhdr400") -> "DisplayHDR 400"
        has("displayhdr") -> "DisplayHDR"
        has("hdr") -> "HDR"
        else -> "SDR / unknown"
    }
    val color = when {
        has("rec.2020", "rec2020", "bt2020") -> "Rec. 2020"
        has("dcip3", "dci-p3", "p3") -> "DCI-P3"
        has("adobe rgb") -> "Adobe RGB"
        has("rec.709", "rec709", "bt709") -> "Rec. 709"
        has("srgb") -> "sRGB"
        else -> "Unknown"
    }
    val resolution = when {
        has("16k") -> "16K"
        has("8k", "7680x4320") -> "8K"
        has("5k", "5120x2880") -> "5K"
        has("4k", "2160p", "3840x2160") -> "UHD / 4K"
        has("1440p", "2k", "2560x1440") -> "QHD / 2K"
        has("1080p", "1920x1080") -> "FHD / 1080p"
        has("720p", "1280x720") -> "HD / 720p"
        has("480p", "854x480", "640x480") -> "SD / 480p"
        else -> "Unknown"
    }
    val videoCodec = when {
        has("h.266", "h266", "vvc") -> "H.266 / VVC"
        has("h.265", "h265", "hevc", "x265") -> "H.265 / HEVC"
        has("h.264", "h264", "avc", "x264") -> "H.264 / AVC"
        has("av1") -> "AV1"
        has("vp9") -> "VP9"
        has("vp8") -> "VP8"
        has("prores") -> "Apple ProRes"
        has("dnxhr", "dnxhd") -> "DNxHD / DNxHR"
        has("vc-1", "vc1") -> "VC-1"
        has("mpeg-2", "mpeg2") -> "MPEG-2"
        has("mpeg-4", "mpeg4") -> "MPEG-4"
        has("xvid") -> "Xvid"
        has("divx") -> "DivX"
        else -> "Auto-detect"
    }
    val audioCodec = when {
        has("truehd") -> "Dolby TrueHD"
        has("atmos", "dolby atmos") -> "Dolby Atmos"
        has("dts:x", "dtsx") -> "DTS:X"
        has("dts-hd", "dtshd") -> "DTS-HD MA"
        has("e-ac3", "eac3", "ddp") -> "E-AC3 / DDP"
        has("ac3", "dolby digital") -> "AC3 / Dolby Digital"
        has("flac") -> "FLAC"
        has("opus") -> "Opus"
        has("aac") -> "AAC"
        has("alac") -> "ALAC"
        has("mp3") -> "MP3"
        has("wma") -> "WMA"
        has("ape") -> "APE"
        has("aiff") -> "AIFF"
        has("dsd", "dsf", "dff") -> "DSD"
        has("pcm", "wav") -> "PCM / WAV"
        has("midi", "mid") -> "MIDI"
        else -> "Auto-detect"
    }
    val audioLayout = when {
        has("7.1") -> "7.1"
        has("5.1") -> "5.1"
        has("2.1") -> "2.1"
        has("stereo", "2.0") -> "Stereo 2.0"
        has("mono", "1.0") -> "Mono 1.0"
        has("binaural") -> "Binaural"
        else -> "Auto"
    }
    val frameRate = when {
        has("240fps", "240 fps") -> "240fps"
        has("144fps", "144 fps") -> "144fps"
        has("120fps", "120 fps") -> "120fps"
        has("60fps", "60 fps", "60p") -> "60fps"
        has("30fps", "30 fps", "30p") -> "30fps"
        has("24fps", "24 fps", "24p") -> "24fps"
        has("vfr") -> "VFR"
        else -> "Auto"
    }
    if (has("10bit", "10-bit")) tags += "10-bit"
    if (has("12bit", "12-bit")) tags += "12-bit"
    if (has("4:4:4")) tags += "4:4:4"
    if (has("4:2:2")) tags += "4:2:2"
    if (has("4:2:0")) tags += "4:2:0"
    if (has("3d sbs", "sbs")) tags += "3D SBS"
    if (has("3d ou", "over-under")) tags += "3D OU"
    if (has("vr 180")) tags += "VR 180"
    if (has("vr 360")) tags += "VR 360"
    if (has("spatial video")) tags += "Spatial Video"
    if (has("ntsc")) tags += "NTSC"
    if (has("pal")) tags += "PAL"
    if (has("secam")) tags += "SECAM"
    if (has("esub", "embedded subtitles")) tags += "Embedded Subtitles"
    if (has("hc-sub", "hardsub")) tags += "HC-SUB"
    if (has("cc", "closed captions")) tags += "CC"
    if (has("lossless")) tags += "Lossless"
    if (has("hi-res", "hi res")) tags += "Hi-Res"
    if (has("spatial audio")) tags += "Spatial Audio"
    if (has("vinyl rip")) tags += "Vinyl Rip"
    if (has("cdda", "cd rip")) tags += "CDDA / CD Rip"
    if (has("320kbps")) tags += "320kbps"
    if (has("256kbps")) tags += "256kbps"
    if (has("128kbps")) tags += "128kbps"
    if (has("cbr")) tags += "CBR"
    if (has("vbr")) tags += "VBR"
    if (has("mfit", "mastered for itunes")) tags += "MFiT"
    if (has("uncompressed")) tags += "Uncompressed"
    if (has("sdr")) tags += "SDR"
    if (has("hdr10+ adaptive", "hdr10plus adaptive")) tags += "HDR10+ Adaptive"
    if (has("dolby vision iq", "dovi iq")) tags += "Dolby Vision IQ"
    if (has("displayhdr 400", "displayhdr400")) tags += "DisplayHDR 400"
    if (has("displayhdr 600", "displayhdr600")) tags += "DisplayHDR 600"
    if (has("displayhdr 1000", "displayhdr1000")) tags += "DisplayHDR 1000"

    return DetectedFeatures(container, tags.distinct(), hdr, color, resolution, videoCodec, audioCodec, audioLayout, frameRate)
}
